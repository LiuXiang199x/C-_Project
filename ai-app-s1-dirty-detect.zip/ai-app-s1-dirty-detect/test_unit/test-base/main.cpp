/* +---------------------------------------------------------------------------+
   |                     HANS Mobile Robot Programming                         |
   |                                                                           |
   | Copyright (c) 2014-2015, Group Contributors, HANS Robot Team              |
   | 						All rights reserved.                   			   |
   | File 	 : test_main.cpp    	                 						   |
   | By 	 : Kimbo													       |
   | Version : V1.00     													   |
   +---------------------------------------------------------------------------+ */

#include <gtest/gtest.h>
#include <iostream>

// main function
int main(int argc, char **argv)
{
    testing::InitGoogleTest(&argc,argv);
    return RUN_ALL_TESTS();
}




/* +---------------------------------------------------------------------------+
   |                     HANS Mobile Robot Programming                         |
   |                                                                           |
   | Copyright (c) 2014-2015, Group Contributors, HANS Robot Team              |
   | 						All rights reserved.                   			   |
   | File 	 : test_main.cpp    	                 						   |
   | By 	 : Kimbo													       |
   | Version : V1.5     													   |
   +---------------------------------------------------------------------------+ */

#include "everest/manager/CManagerAI.h"
#include "everest/manager/CManagerTCP.h"

#include <everest/base/CLogConfig.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>
#include <everest/base/DevicesLogConfig.protoc.pb.h>
#include <everest/base/CFilePath.h>
#include <everest/base/CFileSystem.h>
#include <everest/base/CEntityProtocol.h>
#include <iostream>
#include <signal.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/if.h>
#include <unistd.h>
#include <thread>
#include <google/protobuf/text_format.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <execinfo.h>

using namespace std;
using namespace mrpt;
using namespace everest;
using namespace everest::base;
using namespace everest::manager;
using namespace mrpt::utils;

#define DEBUG_FAULT     0

#if DEBUG_FAULT
    #include <execinfo.h>
#endif 

/***********************************************************************************
Function:     WidebrightSegvHandler
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
static void WidebrightSegvHandler(int signum)
{
    void *array[10];
    size_t size;
    char **strings;

    signal(signum, SIG_DFL); /* 还原默认的信号处理handler */

    size = backtrace (array, 10);
    strings = (char **)backtrace_symbols (array, size);

    fprintf(stderr, "widebright received SIGSEGV! Stack trace:\n");
    for (size_t i = 0; i < size; i++) {
        fprintf(stderr, "%u %s \n",i,strings[i]);
    }

    free (strings);
    exit(1);
}

/***********************************************************************************
Function:     logInit
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void logInit()
{
    std::string file_path = CFilePath::getLogConfigFilePath();

    #if 0
        if(!CFileSystem::fileExists(file_path))
        {
            CLogConfig log_config;
            log_config.add_to_logfile = true;
            log_config.log_file_name = "ai-server.temp";
            log_config.out_log_type = CLog::LogFile;
            log_config.out_log_level = LogNormal;
            log_config.log_cut_down_size = 5 * 1024;

            std::cout << "[AiServer] create log config file" << std::endl;
            DeviceLogConfig device_log_config;
            device_log_config.set_log_file_name(log_config.log_file_name);
            device_log_config.set_auto_build_directory(log_config.auto_build_directory);
            device_log_config.set_create_log_name_auto(log_config.create_log_name_auto);
            device_log_config.set_log_time_string(log_config.log_time_string);
            device_log_config.set_log_module_string(log_config.log_module_string);
            device_log_config.set_log_username_string(log_config.log_username_string);
            device_log_config.set_log_level_string(log_config.log_level_string);
            device_log_config.set_also_printf(log_config.also_printf);
            device_log_config.set_printf_this_call(log_config.printf_this_call);
            device_log_config.set_add_to_logfile(log_config.add_to_logfile);
            device_log_config.set_different_log(log_config.different_log);
            device_log_config.set_out_log_level(log_config.out_log_level);
            device_log_config.set_out_log_type(log_config.out_log_type);
            device_log_config.set_log_user_list(log_config.log_user_list);
            device_log_config.set_log_cut_down_size(log_config.log_cut_down_size);
            device_log_config.set_log_file_path(log_config.log_file_path);

            std::string p;
            google::protobuf::TextFormat::PrintToString(device_log_config, &p);
            CFileSystem::saveProtobufConfig(file_path, p);
        }
    #endif

    DeviceLogConfig device_log_config;
    CFileSystem::readProtobufConfig(file_path, &device_log_config);

    /* Log init */
    // CLogConfig log_config;
    // log_config.add_to_logfile = device_log_config.add_to_logfile();
    // log_config.log_file_name = device_log_config.log_file_name();
    // log_config.out_log_type = device_log_config.out_log_type();
    // log_config.out_log_level = device_log_config.out_log_level();
    // log_config.log_cut_down_size = device_log_config.log_cut_down_size();
    CLogConfig log_config;
    log_config.add_to_logfile = true;
    log_config.log_file_name = "ai-server.temp";
    log_config.out_log_type = CLog::LogFile;
    log_config.out_log_level = LogNormal;
    log_config.log_cut_down_size = 5 * 1024;
    CLog::init(log_config);
}

/***********************************************************************************
Function:     DebugBacktrace
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void DebugBacktrace(int) 
{
	#define SIZE 100
	void *array[SIZE];
	int size, i;
	char **strings;


    fprintf(stderr, "\n Segmentation fault \n");
    size = backtrace(array, SIZE);
    fprintf(stderr, "Backtrace (%d deef):\n", size);

    strings =backtrace_symbols(array, size);

    for(i =0; i < size; i++)
    	fprintf(stderr, "%d: %s\n", i, strings[i]);

 	free(strings);
 	exit(-1);
}

/***********************************************************************************
Function:     main
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int main(int argc, char **argv)
{
    signal(SIGSEGV, DebugBacktrace);

    #if DEBUG_FAULT
        signal(SIGSEGV, WidebrightSegvHandler); // SIGSEGV    11       Core Invalid memory reference
        signal(SIGABRT, WidebrightSegvHandler); // SIGABRT     6       Core Abort signal from
    #endif

    logInit();

    CMessageBroker message_broker;

    CManagerAI      manager_ai(EM_ENTITY_AI);
    CManagerTCP     manager_tcp(EM_ENTITY_TCP);

    printf("[Ai-server] init start!\n");


    manager_ai.setMessageBroker(message_broker);
    manager_tcp.setMessageBroker(message_broker);

    manager_tcp.initialize();
    manager_ai.initialize();

    while(1)
    {
        CLog::logControl();
        systemSleep(10 * 1000);
    }
    
    return 0;
}


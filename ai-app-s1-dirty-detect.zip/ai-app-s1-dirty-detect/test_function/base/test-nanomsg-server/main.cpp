
#include <iostream>
#include <string.h>
#include <nanomsg/nn.h>
#include <nanomsg/pair.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>
#include <thread>

#if 0
#define IPC_PATH_RECV "ipc:///tmp/aux-everest-path.ipc"
#define IPC_PATH "ipc:///tmp/aux-everest-path-recv.ipc"
#else
    #define IPC_PATH        "tcp://10.10.10.2:5002"
    #define IPC_PATH_RECV   "tcp://10.10.10.1:5001"
#endif

int                     g_socket = 0;
int                     g_socket_recv = 0;
static pthread_mutex_t s_send_socket_lock = PTHREAD_MUTEX_INITIALIZER;

using namespace std;

struct TSensor
{
    int x;
    int y;
};

int initSocketCommnuicate(void)
{
	if ((g_socket = nn_socket(AF_SP, NN_PAIR)) < 0)
    {
        printf("nn_socket fail %d\n", g_socket);
        return -1;
    }

	if (nn_connect(g_socket, IPC_PATH) < 0)
    {
        printf("nn_bind fail %d\n", g_socket);
        return -1;
    }

	if ((g_socket_recv = nn_socket(AF_SP, NN_PAIR)) < 0)
    {
        printf("nn_socket  g_socket_recv fail %d\n", g_socket_recv);
        return -1;
    }

	if (nn_bind(g_socket_recv, IPC_PATH_RECV) < 0)
    {
        printf("nn_bind g_socket_recv fail %d\n", g_socket_recv);
        return -1;
    }


    return 0;
}

int  sendSocketData(char *buf, int len)
{
    int ret=0;
    pthread_mutex_lock(&s_send_socket_lock);
    ret= nn_send(g_socket_recv, buf, len, NN_DONTWAIT);
    pthread_mutex_unlock(&s_send_socket_lock);
    return  ret;
}

void closeSocket(void)
{
	nn_shutdown(g_socket, 0);
	nn_shutdown(g_socket_recv, 0);
}

void sendTest()
{
    // char test[] = "hello world, i am server";
    string test = "hello world, i am server";

    while(1)
    {
        // sendSocketData(test, sizeof(test));
        sendSocketData(const_cast<char *>(test.c_str()), test.length());
        systemSleep(1000);
    }
}

int main()
{
    char ch[8];
    TSensor sensor = {20, 1};
    memcpy(ch, (char*)&sensor, 8);

    for(size_t i = 0; i < 8; i++)
    {
        cout << "i " << i << " " << (int) ch[i] <<endl;
    }
    int ret = initSocketCommnuicate();
    std::cout << "initSocketCommnuicate data " << ret << std::endl;

    std::thread thread(sendTest);

    while(1)
    {
        char *ptk = NULL;

        int recv_bytes = nn_recv(g_socket, &ptk, NN_MSG, 0);

        //CLog::log(LogKimbo, LogNormal, "[AuxCtrl] recv_bytes %d!\n", recv_bytes);
       //printf("[AuxCtrl] recv_bytes %d!\n", recv_bytes);
        if(recv_bytes > 0)
        {
            std::string str(ptk, recv_bytes);
            printf( "[main] test %s \n", str.c_str());
        }
    }
    return 0;
}



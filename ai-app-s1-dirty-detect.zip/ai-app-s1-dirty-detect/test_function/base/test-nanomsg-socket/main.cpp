
#include <iostream>
#include <string.h>
#include <nanomsg/nn.h>
#include <nanomsg/pair.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>
#include <everest/base/CNanomsgSocket.h>
#include <everest/base/CAIMessages.pb.h>

#include <thread>


#define IPC_PATH_SEND   "tcp://10.10.10.2:5002"
#define IPC_PATH_RECV   "tcp://10.10.10.1:5001"

using namespace everest::base;
using namespace std;

CNanomsgSocket g_socket;


TTimeStamp last_timestamp = CTime::getCpuTime();

void msgCallBack(CMsgHead *pmsg)
{
    if(pmsg)
    {
        TTimeStamp timstamp = CTime::getCpuTime();
        double time_diff = CTime::timeDifference(last_timestamp, timstamp);
        last_timestamp = timstamp;
        printf("cmd %d, len %d last_timestamp %f \n", pmsg->cmd, pmsg->len, time_diff *1000.0);
        if(pmsg->buf)
        {
            free(pmsg->buf);
        }
        free(pmsg);
    }
}

int main(int argc, char **argv)
{
    std::string ip_send_addr = IPC_PATH_SEND;
    std::string ip_recv_addr = IPC_PATH_RECV;
    int cmd = 1;
    int len = 1;
    if(argc > 1)
    {
        int type = atoi(argv[1]);
        if(type >1 )
        {
            ip_send_addr = IPC_PATH_RECV;
            ip_recv_addr = IPC_PATH_SEND;
            cmd = 2;
        }
    }

    if(argc >2)
    {
        len = atoi(argv[2]);
    }
    printf("main ip_send_addr %s! len %d\n", ip_send_addr.c_str(), len);
    printf("main ip_recv_addr %s!\n", ip_recv_addr.c_str());

    int ret = g_socket.Start(ip_send_addr, ip_recv_addr, msgCallBack);
    if(ret <0)
    {
        printf("[g_socket] create fail ret %d!\n", ret);
        return ret;
    }
    
    int mallco_len = len *1024;
    char *buffer;
    buffer = (char*) malloc(mallco_len);
    memset(buffer, 1, mallco_len);
    while(1)
    {
        systemSleep(1000);
    }
    return 0;
}



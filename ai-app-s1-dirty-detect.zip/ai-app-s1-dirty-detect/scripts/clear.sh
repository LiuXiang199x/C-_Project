rm -r ../build/*
rm -r ../build_x86/*

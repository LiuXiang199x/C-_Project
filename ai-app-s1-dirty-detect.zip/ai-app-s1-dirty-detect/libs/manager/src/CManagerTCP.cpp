/**********************************************************************************
File name:	  CCountDown.h
Author:       Shifeng
Version:      V1.6.2
Date:	 	  2016-10-10
Description:  File transfer protocol class
Others:       None

History:
	1. Date: 2016-10-27
	Author: Kimbo
	Modification: Change it from C language to C++ lanuage
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/manager/CManagerTCP.h>

/******************************* Current libs includes ****************************/
#include <everest/base/CTime.h>
#include <everest/base/CFilePath.h>
#include <everest/base/CFileSystem.h>
#include <everest/base/CLogUtitls.h>
#include <everest/base/CLog.h>
#include <everest/base/CAIMessages.pb.h>
#include <everest/ai/CAiParameters.h>
#include <everest/hwdrivers/CSerialConnection.h>

/******************************* System libs includes *****************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>

/******************************* Other libs includes ******************************/
#define  AI_ROBOT_SERVERPATH        "/tmp/AI_ROBOT_SERVER_APATH"

/*********************************** Name space ***********************************/
using namespace std;
using namespace mrpt;
using namespace everest;
using namespace everest::base;
using namespace everest::manager;
using namespace everest::hwdrivers;
using namespace mrpt::utils;


#define IPC_PATH_SEND   "tcp://10.10.10.2:5002"
#define IPC_PATH_RECV   "tcp://10.10.10.1:5001"

#ifdef CAP_IMAGE
  #define HEART_BERT_MODE 0
#else
   #define HEART_BERT_MODE 1
#endif

//#define HEART_BERT_MODE 0
/***********************************************************************************
Function:     CManagerTCP
Description:  The constructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CManagerTCP::CManagerTCP(int id):
             CBaseModule(id)
{
    ai::CAiParameters m_ai_parameter;
    m_ai_local_mode_num = (int)(m_ai_parameter.getLocalAIMode());
}

/***********************************************************************************
Function:     ~CManagerTCP
Description:  The destructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CManagerTCP::~CManagerTCP()
{
    m_thread.join();
    m_3326_thread.join();

    systemSleep(200);
}

/***********************************************************************************
Function:     initialize
Description:  init
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::initialize()
{
    // std::string ip_send_addr = IPC_PATH_RECV;
    // std::string ip_recv_addr = IPC_PATH_SEND;
    // auto callback = std::bind(&CManagerTCP::clientCallback, this, std::placeholders::_1);
    // m_robot_connect_client.Start(ip_send_addr, ip_recv_addr, callback);
    #if HEART_BERT_MODE
        m_last_receive_heartbeat_time = INVALID_TIMESTAMP;
    #else
        m_last_receive_heartbeat_time = CTime::getCpuTime();
    #endif

    auto fun_3326 = std::bind(&CManagerTCP::get3326Uartdata, this);
    m_3326_thread = std::thread(fun_3326);

    auto fun = std::bind(&CManagerTCP::updateThread, this);
    m_thread = std::thread(fun);

    CLog::log(LogKimbo, LogNormal, "[CManagerTCP] initialize sucessful!\n");

    return true;
}
/***********************************************************************************
Function:     get3326Uartdata
Description:  init
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::get3326Uartdata()
{
    string opt_com_path = "/dev/ttyS6";
	int    opt_com_baudrate = 115200;
	bool   readStatu = true;
    CSerialConnection *serial = NULL;

    readStatu = true;
    serial = new CSerialConnection();
    serial->setPort(opt_com_path.c_str());
    serial->setBaud(opt_com_baudrate);
    bool serial_open_state = serial->openSimple();

    int trycount = 0;
    while(serial_open_state == false)
    {
        sleep(2);
        if((serial_open_state = serial->openSimple()) == false)
        {
            trycount++;
            CLog::log(LogKimbo, LogNormal, "[AuxCtrl] >>>>>>>>>> serial  %s  open fail !\n",opt_com_path.c_str());
            if(trycount > 5)
            {
            }
        }
    }

    CLog::log(LogKimbo, LogNormal, "[CManagerTCP] init uart sucessful!\n");
    m_3326_receiver.setDeviceConnection(serial);
    m_3326_sender.setDeviceConnection(serial);

    send1806StartState();
    
    CRobotPacket packet;
    while(1)
    {
        if(m_3326_receiver.receivePacket(&packet, 5000))
        {
            switch (packet.getPacketID())
            {
                case CMD_AI_ROBOT_SENSOR:
                {
                    TRobotSensor robot_sensor;
                    packet.readPacket((char *)&robot_sensor, packet.getDataLength());
                    processCmdAiRobotSensorCmd((char *)&robot_sensor, packet.getDataLength()); 
                    break;
                }
                 
                case CMD_AI_SET_MODE: processCmdAiSetMode(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_HEARTBAEAT: processCmdAiHeartBreat(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_SYNC_TIME: 
                {
                    long long now_3326_time;
                    packet.readPacket((char *)&now_3326_time, packet.getDataLength());
                    processCmdAiSyncTime((char *)&now_3326_time, packet.getDataLength()); break;
                }
                case CMD_AI_CAMERA_CALIBRATION: processCmdCameraCalibration(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_CAMERA_STATUS: processCmdCameraStatus(packet.getBuf(), packet.getDataLength()); break;
                case CMD_USB_CONNECT_STATUS: processUsbConnectStatus(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_CAMERA_PARAM:
                {
                    char readbuf[128] = {0};
                    packet.readPacket(&readbuf[0], packet.getDataLength());
                    processCameraParams(&readbuf[0], packet.getDataLength()); break;
                }
                case CMD_AI_1806_TEMP: processGet1806Temp(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_NPU_DCDC: processGetNpuDCDC(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_1806_FREE: processGet1806Free(packet.getBuf(), packet.getDataLength()); break;
                case CMD_AI_SYNC_START_STATUS: process3326StartState(packet.getBuf(), packet.getDataLength()); break;
                default: break;
            }
        }
        int lost_count = m_3326_receiver.getLostCount();
        if(lost_count > 150)  // 30 * 200
        {
            m_3326_receiver.resetLostCount();
            CLog::log(LogKimbo, LogErro, "[CManagerTCP] lost count %d!\n", lost_count);
        }
        usleep(2000);
    }
}
/***********************************************************************************
Function:     send1806StartState
Description:  send1806StartState
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::send1806StartState()
{
    CLog::log(LogKimbo, LogNormal, "[CEntityAI] 3326 uart start, send state to 1806!\n");
    CRobotPacket packet = CRobotPacket(CMD_AI_SYNC_START_STATUS, NULL, 0);
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_SYNC_START_STATUS, 0, NULL, 0, 0);
}
/***********************************************************************************
Function:     close
Description:  close
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::close()
{

}

/***********************************************************************************
Function:     setMessageBroker
Description:  Set message borker
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::setMessageBroker(base::CMessageBroker &message_broker)
{
    m_message_broker_ptr = &message_broker;
    m_message_broker_ptr->registerEntity(this);
}

/***********************************************************************************
Function:     handleMessage
Description:  handleMessage
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::handleMessage(const CTelegram& telegram)
{
    TEverestProtocol protocol = (TEverestProtocol)telegram.getEvent();
   
    switch (protocol)
    {
        case EM_AI_DETECT_OBJECT: processAiDetectObject(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_CALIBRATION: processCameraCalibrationResult(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_STATUS: processCameraStatus(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_COVERED_STATUS: processCameraCoveredStatus(telegram.getExtraInformation()); break;
        case EM_AI_OUT_FAMILY_TEST: processOutFamalityTest(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_PARAM: processCameraParamRquest(telegram.getExtraInformation()); break;
        default: break;
    }

    return true;
}

/***********************************************************************************
Function:     processAiDetectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processAiDetectObject(const mrpt::utils::CMessage &message)
{   
    //USB协议发送
    // m_robot_connect_client.Send(CMD_AI_DETECT_OBJECT, message.content.size(), (char*)&message.content[0], 0, 0);
    // printf("send DETECT OBJECT status===================================>%d\n",message.content.size());
    CLog::log(LogKimbo, LogNormal, "send DETECT OBJECT status===================================>%d!\n");
    //串口协议发送
    std::deque<CRobotPacket>  packets = messageTransferObjectPacket(message);
    for(auto & packet : packets)
        m_3326_sender.sendPacket(&packet);
    return true;
}

/***********************************************************************************
Function:     processCameraStatus
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processCameraStatus(const mrpt::utils::CMessage &message)
{   
    uint8_t camera_status = 0; 
    memcpy(&camera_status, &message.content[0], sizeof(uint8_t));
    printf("send camera status===================================>%d\n",camera_status);
    // m_robot_connect_client.Send(CMD_AI_CAMERA_STATUS, message.content.size(), (char*)&message.content[0], 0, 0);

    CRobotPacket  packet = CRobotPacket(CMD_AI_CAMERA_STATUS, &camera_status, sizeof(camera_status));
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_CAMERA_STATUS, message.content.size(), (char*)&message.content[0], 0, 0);

    return true;
}

/***********************************************************************************
Function:     processCameraCoveredStatus
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processCameraCoveredStatus(const mrpt::utils::CMessage &message)
{   
    printf("send camera covered status===================================>\n");
    // m_robot_connect_client.Send(CMD_AI_CAMERA_COVERED_STATUS, 0, NULL, 0, 0);
    CRobotPacket  packet = CRobotPacket(CMD_AI_CAMERA_COVERED_STATUS, NULL, 0);
    m_3326_sender.sendPacket(&packet);
    return true;
}

/***********************************************************************************
Function:     processOutFamalityTest
Description:  None
Input:        None
Output:       None 
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processOutFamalityTest(const mrpt::utils::CMessage &message)
{   
    std::cout<<"send out family test result to robot....."<<message.content.size()<< std::endl;
    CLog::log(LogKimbo, LogNormal, "====send raw imgage data to server\n");
    int iret = m_robot_connect_client.Send(CMD_AI_OUT_FAMILY_TEST_DATA_COLLECTION, message.content.size(), (char*)&message.content[0], 0, 0);
    CLog::log(LogKimbo, LogNormal, "send out family test result .....%d!\n",iret);
    // std::cout<<"send no content datacollection cmd....."<< std::endl;
    // m_robot_connect_client.Send(CMD_AI_OUT_FAMILY_TEST_DATA_COLLECTION, 0, NULL, 0, 0);
    // std::cout<<"unvalid commd....."<< std::endl;
    // m_robot_connect_client.Send(133, 0, NULL, 0, 0);
    return true;
}

/***********************************************************************************
Function:     processCameraParamRquest
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processCameraParamRquest(const mrpt::utils::CMessage &message)
{   
    std::cout<<"start request camera params....."<< std::endl;
    u8 state = 0;
    // m_robot_connect_client.Send(CMD_AI_CAMERA_PARAM, 0, NULL, 0, 0);
    CRobotPacket  packet = CRobotPacket(CMD_AI_CAMERA_PARAM, &state, sizeof(state));
    bool sucess = m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_CAMERA_PARAM, message.content.size(), (char*)&message.content[0], 0, 0);
    std::cout<<"start request camera params..... " << sucess << std::endl;
    return true;
}
/***********************************************************************************
Function:     processCameraCalibrationResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerTCP::processCameraCalibrationResult(const mrpt::utils::CMessage &message)
{   
    std::cout<<"send calib result to robot....."<<message.content.size()<<std::endl;
    CLog::log(LogKimbo, LogNormal, "send calib result to robot.....!\n");
    m_is_in_calib_mode = false;
    m_robot_connect_client.Send(CMD_AI_CAMERA_CALIBRATION, message.content.size(), (char*)&message.content[0], 0, 0);
    return true;
}


/***********************************************************************************
Function:     Update
Description:  Update
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::update()
{
    /* Handle message list */
    std::deque<CTelegram> message_list = getPendingMessageList();

    for(size_t i = 0; i < message_list.size(); i++)
    {
        handleMessage(message_list[i]);
    }
    // CLog::log(LogKimbo, LogNormal, "[CManagerTCP] update!\n");
    // usleep(5*1000);
    updateHeartbeat();

    
}


/***********************************************************************************
Function:     updateHeartbeat
Description:  updateHeartbeat
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::updateHeartbeat()
{   
    if (m_is_in_calib_mode == true)
    {
        return;
    }
    
    #if HEART_BERT_MODE
        if(m_last_receive_heartbeat_time == INVALID_TIMESTAMP)
        {
            CMessage message;
            message.content.resize(sizeof(int));
            int mode = (int)(base::AI_MODE_IDLE);
            memcpy(&message.content[0], &mode, sizeof(int)); 
            m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_SET_AI_MODE, &message);
            return;
        }
        int time_diff_interval = 5;
    #else
        int time_diff_interval = 7200;
    #endif
    
    double time_diff = CTime::timeDifference(m_last_receive_heartbeat_time, CTime::getCpuTime());
    printf("time_diff----%.2f\n",time_diff);
    if(time_diff > time_diff_interval)
    {
        CMessage message;
        message.content.resize(sizeof(int));
        int mode = (int)(base::AI_MODE_IDLE);
        memcpy(&message.content[0], &mode, sizeof(int)); 
        // CLog::log(LogKimbo, LogNormal, "[CManagerTCP] setAI mode %d!\n",mode);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_SET_AI_MODE, &message);
    }
    else
    {
        CMessage message;
        message.content.resize(sizeof(int));
        int mode = m_ai_local_mode_num;
        memcpy(&message.content[0], &mode, sizeof(int)); 
        // CLog::log(LogKimbo, LogNormal, "[CManagerTCP] setAI mode %d!\n",mode);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_SET_AI_MODE, &message);
    }
    
    //debug calibrate
    // long long time_diff_last_debug_calibrate_time = CTime::timeDifference(m_last_debug_camera_calibrate_time, CTime::getCpuTime());
    // if (time_diff_last_debug_calibrate_time > 20)
    // {
    //     std::cout<<"calib debug....." <<std::endl;
    //     CMessage message;
    //     message.content.resize(sizeof(int));
    //     int mode = (int)(base::AI_MODE_CAMERA_CALIBRATION);
    //     memcpy(&message.content[0], &mode, sizeof(int)); 
    //     m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_SET_AI_MODE, &message);
    //     m_last_debug_camera_calibrate_time = CTime::getCpuTime();
    // }
    
}

/***********************************************************************************
Function:     processCmdAiRobotSensorCmd
Description:  processCmdAiRobotSensorCmd
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdAiRobotSensorCmd(char *buf, int len)
{
    //CLog::log(LogKimbo, LogNormal, "[CManagerTCP] processCmdAiRobotSensorCmd len %d!\n", len);
    if(len == sizeof(TRobotSensor))
    {
        TRobotSensor robot_sensor;
        memcpy(&robot_sensor, buf, len);
        CMessage message;
        message.content.resize(sizeof(TRobotSensor));
        memcpy(&message.content[0], &robot_sensor, sizeof(TRobotSensor));
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_AI_ROBOT_SENSOR, &message);
    }
}

/***********************************************************************************
Function:     processCmdAiSetModeReq
Description:  processCmdAiSetModeReq
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdAiSetMode(char *buf, int len)
{
    
}

/***********************************************************************************
Function:     processCmdAiGetCameraRsp
Description:  processCmdAiGetCameraRsp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdAiHeartBreat(char *buf, int len)
{
    printf("recieve 3326 heart beart------------------");
    long long receive_calibration_with_3326_time = 0;
    m_last_receive_heartbeat_time = CTime::getCpuTime();
    // CLog::log(LogKimbo, LogNormal, "[CManagerTCP] recieve heart beat..........!\n");
    // if(len == sizeof(long long))
    // {
    //     long long now_3326_time = 0;
    //     memcpy(&now_3326_time, buf, len);

    //     TTimeStamp timestamp = CTime::getCpuTime();
    //     double time_diff = CTime::timeDifference(timestamp, now_3326_time);
    //     receive_calibration_with_3326_time = now_3326_time - timestamp;
    //     //  CLog::log(LogKimbo, LogNormal, "[CManagerTCP] set time %lld - %lld, %f!\n", now_3326_time, timestamp, time_diff);
    // }
    // CMessage message;
    // message.content.resize(sizeof(long long));
    // memcpy(&message.content[0], &receive_calibration_with_3326_time, sizeof(long long)); 
    // m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_ROBOT_HEART_BEAT, &message);

}
/***********************************************************************************
Function:     processCmdAiSyncTime
Description:  processCmdAiSyncTime
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdAiSyncTime(char *buf, int len)
{
    long long receive_calibration_with_3326_time = 0;
    // m_last_receive_heartbeat_time = CTime::getCpuTime();
    CLog::log(LogKimbo, LogNormal, "[CManagerTCP] set time len %d!\n", len);
    if(len == sizeof(long long))
    {
        long long now_3326_time = 0;
        memcpy(&now_3326_time, buf, len);

        TTimeStamp timestamp = CTime::getCpuTime();
        double time_diff = CTime::timeDifference(timestamp, now_3326_time);
        receive_calibration_with_3326_time = now_3326_time - timestamp;
        CLog::log(LogKimbo, LogNormal, "[CManagerTCP] set time %lld - %lld, %f!\n", now_3326_time, timestamp, time_diff);
    }
    CMessage message;
    message.content.resize(sizeof(long long));
    memcpy(&message.content[0], &receive_calibration_with_3326_time, sizeof(long long)); 
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_ROBOT_HEART_BEAT, &message);

}

/***********************************************************************************
Function:     processCmdCameraCalibration
Description:  processCmdCameraCalibration
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdCameraCalibration(char *buf, int len)
{
    std::cout << "recieve calib cmd........." <<std::endl;
    CLog::log(LogKimbo, LogNormal, "[CManagerTCP] recieve calib cmd.!\n");
    m_is_in_calib_mode = true;
    CMessage message;
    message.content.resize(sizeof(int));
    int mode = (int)(base::AI_MODE_CAMERA_CALIBRATION);
    memcpy(&message.content[0], &mode, sizeof(int)); 
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_SET_AI_MODE, &message);
}


/***********************************************************************************
Function:     processCmdCameraCalibration
Description:  processCmdCameraCalibration
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdCameraStatus(char *buf, int len)
{
    std::cout << "recieve camera status cmd........." <<std::endl;
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_AI_CAMERA_STATUS, NULL);
}

/***********************************************************************************
Function:     processCmdCameraStatusRequest
Description:  processCmdCameraStatusRequest
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCmdCameraStatusRequest(char *buf, int len)
{
    std::cout << "recieve camera status request cmd........." <<std::endl;
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_AI_CAMERA_STATUS, NULL);
}

/***********************************************************************************
Function:     processCameraParams
Description:  processCameraParams
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processCameraParams(char *buf, int len)
{
    if (len > 0)
    {
        std::string camera_str = std::string((const char *)buf, len);
        std::cout << "recieve camera params "<<camera_str<<std::endl;

        CMessage message;
        message.content.resize(camera_str.length());
        memcpy(&message.content[0], &camera_str[0], camera_str.length());
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_TCP, EM_ENTITY_AI, 0, EM_AI_CAMERA_PARAM, &message);       
    }
}

/***********************************************************************************
Function:     processCameraParams
Description:  processCameraParams
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processUsbConnectStatus(char *buf, int len)
{
    if (m_has_recieve_usb_connect_status)
    {
        return;
    }
    
    CLog::log(LogKimbo, LogNormal, "-------------------recieve usb connect cmd-------------------!\n");
    CLog::log(LogKimbo, LogNormal, "-------------------open usb connect!\n");
    std::string ip_send_addr = IPC_PATH_RECV;
    std::string ip_recv_addr = IPC_PATH_SEND;
    auto m_callback = std::bind(&CManagerTCP::clientCallback, this, std::placeholders::_1);
    m_robot_connect_client.Start(ip_send_addr, ip_recv_addr, m_callback);
    m_has_recieve_usb_connect_status = true;
}

/***********************************************************************************
Function:     processGet1806Temp
Description:  processGet1806Temp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processGet1806Temp(char *buf, int len)
{
    int temp = getCpuTemp();

    CRobotPacket  packet = CRobotPacket(CMD_AI_1806_TEMP, &temp, sizeof(temp));
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_1806_TEMP, sizeof(temp), (char*)&temp, 0, 0);

    std::cout << "Current temp  "<< temp << std::endl;
}
/***********************************************************************************
Function:     processGet1806Free
Description:  processGet1806Free
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processGet1806Free(char *buf, int len)
{
    TFreeMemory free_memory = getFreeMemory();
    int free_total = free_memory.free_total;
    CRobotPacket  packet = CRobotPacket(CMD_AI_1806_FREE, &free_memory, sizeof(free_memory));
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_1806_FREE, sizeof(free_memory), (char*)&free_memory, 0, 0);

    std::cout << "Current free_total  "<< free_total << std::endl;
}

/***********************************************************************************
Function:     processGetNpuDCDC
Description:  processGetNpuDCDC
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::processGetNpuDCDC(char *buf, int len)
{
    std::string npu_dcdc = getNpuDCDC();
    char buff[10] = {0};
    memcpy(&buff[0], npu_dcdc.data(), npu_dcdc.length());

    CRobotPacket  packet = CRobotPacket(CMD_AI_NPU_DCDC, &buff, sizeof(buff));
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_NPU_DCDC, sizeof(buff), (char*)&buff, 0, 0);

    std::cout << "Current npu_dcdc  "<< npu_dcdc << std::endl;
}
/***********************************************************************************
Function:     process3326StartState
Description:  process3326StartState
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::process3326StartState(char *buf, int len)
{
    //收到3326启动命令，说明3326启动慢于1806，请求一下相机参数
    CRobotPacket  packet = CRobotPacket(CMD_AI_CAMERA_PARAM, NULL, 0);
    m_3326_sender.sendPacket(&packet);
    // m_robot_connect_client.Send(CMD_AI_CAMERA_PARAM, 0, NULL, 0, 0);
    std::cout << "send CMD_AI_CAMERA_PARAM 收到3326启动命令，说明3326启动慢于1806，请求一下相机参数" << std::endl;
}

/***********************************************************************************
Function:     clientCallback
Description:  clientCallback
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::clientCallback(CMsgHead *pmsg)
{
     if(pmsg)
     {   
        switch (pmsg->cmd)
        {
            case CMD_AI_ROBOT_SENSOR: processCmdAiRobotSensorCmd(pmsg->buf, pmsg->len); break;
            case CMD_AI_SET_MODE: processCmdAiSetMode(pmsg->buf, pmsg->len); break;
            case CMD_AI_HEARTBAEAT: processCmdAiHeartBreat(pmsg->buf, pmsg->len); break;
            case CMD_AI_SYNC_TIME: processCmdAiSyncTime(pmsg->buf, pmsg->len); break;
            case CMD_AI_CAMERA_CALIBRATION: processCmdCameraCalibration(pmsg->buf, pmsg->len); break;
            case CMD_AI_CAMERA_STATUS: processCmdCameraStatus(pmsg->buf, pmsg->len); break;
            case CMD_AI_CAMERA_PARAM: processCameraParams(pmsg->buf, pmsg->len); break;
            default: break;
        }

        if(pmsg->buf)
            free(pmsg->buf);

        free(pmsg);
     }
}

/***********************************************************************************
Function:     updateThread
Description:  updateThread
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerTCP::updateThread()
{
    while(1)
    {
        this->update();

        systemSleep(100);
    }
}
int CManagerTCP::getCpuTemp()
{
    // 1# 从vendor读取字符串
    // -------------------------------
    FILE *      fp           = NULL;
    char        buff[1024]   = {0};
    char        readbuf[512] = {0};
    int         temp = 0;
    std::string param_string("");
    if ((fp = popen("cat /sys/class/thermal/thermal_zone0/temp", "r")) == NULL)
        return temp;

    while (fgets(buff, sizeof(buff), fp))
    {
        // if (strstr(buff, "VENDOR_SN_ID") != NULL)
        // {
        //     sscanf(buff, "VENDOR_SN_ID: %s", readbuf);
        //     strncpy(buff, readbuf, strlen(readbuf) + 1);
        // }
    }
    if (pclose(fp) < 0)
        printf("pclose err\n");
    param_string = string(buff);
    temp = atoi(param_string.c_str());
    std::cout << "temp: " << temp << std::endl;
    return temp;
}
std::string CManagerTCP::getNpuDCDC()
{
    // 1# 从vendor读取字符串
    // -------------------------------
    FILE *      fp           = NULL;
    char        buff[1024]   = {0};
    char        readbuf[512] = {0};
    std::string param_string("");
    if ((fp = popen("i2cget  -f -y 0x0  0x1c 0x03", "r")) == NULL)
        return param_string;

    while (fgets(buff, sizeof(buff), fp))
    {

    }
    if (pclose(fp) < 0)
        printf("pclose err\n");
    param_string = string(buff);
    std::cout << "param_string: " << param_string << std::endl;
    return param_string;
}

std::deque<CRobotPacket> CManagerTCP::messageTransferObjectPacket(const mrpt::utils::CMessage &message)
{
    std::deque<CRobotPacket> packets;

    AIMessages::AiMessage ai_message;
    ai_message.ParseFromString(std::string((char *)&message.content[0], message.content.size()));

    for(const auto & object : ai_message.objects())
    {
        TAIDetectData detect_data;
        detect_data.time_stamp = (uint64_t)ai_message.time_stamp();
        detect_data.object_class = (uint16_t)object.class_();
        detect_data.object_score = (uint8_t)(object.score() * 100);
        detect_data.img_origin_x = (uint16_t)object.image().origin_x();
        detect_data.img_origin_y = (uint16_t)object.image().origin_y();
        detect_data.img_width = (uint16_t)object.image().width();
        detect_data.img_height = (uint16_t)object.image().height();
        detect_data.robot_sensor.time_stamp = object.robot_pose_time();
        detect_data.robot_sensor.robot_pose_x = object.robot_pose_x();
        detect_data.robot_sensor.robot_pose_y = object.robot_pose_y();
        detect_data.robot_sensor.robot_pose_phi = object.robot_pose_phi();

        CRobotPacket packet = CRobotPacket(CMD_AI_DETECT_OBJECT, &detect_data, sizeof(TAIDetectData));
        packets.push_back(packet);
    }
    return packets;
}

TFreeMemory CManagerTCP::getFreeMemory()
{
    std::string cmd = "free | grep \"Mem\" > /tmp/system_free.txt";
    ::system(cmd.c_str());
    std::string file_path = "/tmp/system_free.txt";
	FILE *f = ::fopen (file_path.c_str(), "r");
	if (!f)
    {
        std::cout << "open failed " << std::endl;
        return TFreeMemory();
    }

    TFreeMemory free_memory;
    char memory_process1[128];
    memset(memory_process1, 0, sizeof(memory_process1));
	// Note: some of these scanf specifiers would normally be 'long' versions if
	// not for the fact that we are using suppression (gcc warns).  see 'man
	// proc' for scanf specifiers and meanings.
    //total       used       free     shared    buffers     cached
	if (!::fscanf(f,"%s %d %d %d %d %d %d", &memory_process1, 
            &free_memory.free_total, &free_memory.free_used, &free_memory.free_free, 
            &free_memory.free_shared, &free_memory.free_buffers, &free_memory.free_cached))
	{
		// Error parsing:

	}

    #if 1
	std::cout << "memory_process1 " << memory_process1 << std::endl;
	std::cout << "free_memory.free_total " << free_memory.free_total << std::endl;
	std::cout << "free_memory.free_used " << free_memory.free_used << std::endl;
	std::cout << "free_memory.free_free " << free_memory.free_free << std::endl;
	std::cout << "free_memory.free_shared " << free_memory.free_shared << std::endl;
	std::cout << "free_memory.free_buffers " << free_memory.free_buffers << std::endl;
	std::cout << "free_memory.free_cached " << free_memory.free_cached << std::endl;
	#endif
	::fclose (f);

    return free_memory;
}
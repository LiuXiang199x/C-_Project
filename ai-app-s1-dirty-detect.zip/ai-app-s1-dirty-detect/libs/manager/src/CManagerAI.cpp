/**********************************************************************************
File name:	  CCountDown.h
Author:       Shifeng
Version:      V1.6.2
Date:	 	  2016-10-10
Description:  File transfer protocol class
Others:       None

History:
	1. Date: 2016-10-27
	Author: Kimbo
	Modification: Change it from C language to C++ lanuage
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/manager/CManagerAI.h>
#include "opencv2/opencv.hpp"
#include "opencv2/imgcodecs/legacy/constants_c.h"
/******************************* Current libs includes ****************************/
#include <everest/base/CTime.h>
#include <everest/base/CFilePath.h>
#include <everest/base/CFileSystem.h>
#include <everest/base/CEntityProtocol.h>
#include <everest/base/CLogUtitls.h>
#include <everest/base/CLog.h>
#include <everest/hwdrivers/CCameraSensor.h>
#include <everest/ai/CImageTransform.h>
#include <everest/ai/CTypeTransform.h>
#include <everest/hwdrivers/CGpioControl.h>
#include <everest/ai.h>
/******************************* System libs includes *****************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include<iostream>
#include<cstdio>
/******************************* Other libs includes ******************************/

/*********************************** Name space ***********************************/
using namespace std;
using namespace mrpt;
using namespace everest;
using namespace everest::base;
using namespace everest::ai;
using namespace everest::hwdrivers;

using namespace everest::manager;
using namespace mrpt::utils;

/***********************************************************************************
Function:     CManagerAI
Description:  The constructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CManagerAI::CManagerAI(int id):
                CBaseModule(id),
                m_is_camera_open(false),
                m_exit_camera_data_thread(false),
                m_exit_ai_thread(false)
{
    m_receive_calibration_with_3326_time = 0;
    m_last_ai_mode = base::TAiMode::AI_MODE_IDLE;
    m_last_send_detect_data_time = 0;
    m_last_send_detect_data_time = CTime::getCpuTime();
    m_last_set_image_time_stamp = INVALID_TIMESTAMP;
    m_last_set_server_raw_image_time_stamp = INVALID_TIMESTAMP;
    #if RAW_DATA_REAL_TIME_COLLECT
    m_exit_send_raw_img_to_server_thread = false;
    #endif
}

/***********************************************************************************
Function:     ~CManagerAI
Description:  The destructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CManagerAI::~CManagerAI()
{
    close();

    m_camera_data_thread.join();
    m_ai_thread.join();

    #if RAW_DATA_REAL_TIME_COLLECT
    m_send_raw_img_to_server_thread.join();
    #endif

    systemSleep(200);
}

/***********************************************************************************
Function:     init
Description:  init
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerAI::initialize()
{
    pthread_mutex_init(&m_lock_image_raw_data, NULL); 
    pthread_mutex_init(&m_lock_ai_image, NULL);   
    pthread_mutex_init(&m_lock_is_open_camera, NULL);   

    auto camera_data_call_back = std::bind(&CManagerAI::rgaDataProcess, this, std::placeholders::_1, std::placeholders::_2);
    m_camera_init_status = m_camera_sensor.initilize(camera_data_call_back);
    
    auto fun_ai = std::bind(&CManagerAI::updateAiThread, this);
    m_ai_thread = std::thread(fun_ai);

    auto fun_camera_data = std::bind(&CManagerAI::updateCameraDataThread, this);
    m_camera_data_thread = std::thread(fun_camera_data);

    #if RAW_DATA_REAL_TIME_COLLECT
    auto send_raw_img_to_server = std::bind(&CManagerAI::sendRawImageDataToServerThread, this);
    m_send_raw_img_to_server_thread = std::thread(send_raw_img_to_server);
    #endif

    CLog::log(LogKimbo, LogNormal, "[CManagerAI] init sucessful!\n");

    //关闭补光灯
    CGpioControl gpio;
    gpio.GpioInit(14, GPIO_TYPE_OUT, GPFIO_DISENABLE);

    systemSleep(100);

    sendCameraStatus();
    requestCameraParam();

    return true;
}


/***********************************************************************************
Function:     close
Description:  close
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::close()
{
    m_exit_camera_data_thread = true;
    m_exit_ai_thread = true;
    m_exit_send_raw_img_to_server_thread = true;
    systemSleep(2000);
}

/***********************************************************************************
Function:     setMessageBroker
Description:  Set message borker
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::setMessageBroker(base::CMessageBroker &message_broker)
{
    m_message_broker_ptr = &message_broker;
    m_message_broker_ptr->registerEntity(this);
}

/***********************************************************************************
Function:     Update
Description:  Update
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::update()
{
    /* Handle message */

    std::deque<CTelegram> message_list = getPendingMessageList();
    for(size_t i = 0; i < message_list.size(); i++)
    {
        handleMessage(message_list[i]);
    }

    ai::CImage current_image = getCurrentImage();
    m_robot_ai.update(current_image);

    sendAIModeProcessResult();
}

/***********************************************************************************
Function:     openCamera
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::openCamera()
{
    CLog::log(LogKimbo, LogNormal, "[CManagerAI] start openCamera!\n");
    if(!isCameraOpen())
    {
        m_camera_init_status = m_camera_sensor.start();
        
        if(m_camera_init_status)
        {
            sendCameraStatus();
            CLog::log(LogKimbo, LogNormal, "[CManagerAI] open camera sucessful!\n");
            pthread_mutex_lock(&m_lock_is_open_camera);
            m_is_camera_open = true;
            pthread_mutex_unlock(&m_lock_is_open_camera);
        }
        else
        {
            sendCameraStatus();
            CLog::log(LogKimbo, LogNormal, "[CManagerAI] open camera fail!\n");
        }
    }
}

/***********************************************************************************
Function:     closeCamera
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::closeCamera()
{
    CLog::log(LogKimbo, LogNormal, "[CManagerAI] start closeCamera!\n");
    if(isCameraOpen())
    {
        CLog::log(LogKimbo, LogNormal, "[CManagerAI] close camera sucessful!\n");
        pthread_mutex_lock(&m_lock_is_open_camera);
        m_is_camera_open = false;
        pthread_mutex_unlock(&m_lock_is_open_camera);
        m_camera_sensor.stop();
    }
}

/***********************************************************************************
Function:     handleMessage
Description:  handleMessage
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerAI::handleMessage(const CTelegram& telegram)
{
    TEverestProtocol protocol = (TEverestProtocol)telegram.getEvent();
    
    switch (protocol)
    {
        case EM_AI_ROBOT_SENSOR: processAIRobotSensor(telegram.getExtraInformation()); break;
        case EM_SET_AI_MODE: processSetAiMode(telegram.getExtraInformation()); break;
        case EM_ROBOT_HEART_BEAT: processRobotHeartBeat(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_STATUS: processCameraStatus(telegram.getExtraInformation()); break;
        case EM_AI_CAMERA_PARAM: processCameraParams(telegram.getExtraInformation()); break;
        default: break;
    }

    return true;
}

/***********************************************************************************
Function:     void
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::processSetAiMode(const CMessage &message)
{
    base::TAiMode ai_mode = base::TAiMode::AI_MODE_IDLE;     

    if(message.content.size() == sizeof(int))
    {
        memcpy(&ai_mode, &message.content[0], sizeof(int));
    }

    if(ai_mode != m_last_ai_mode)
    {
        m_last_ai_mode = ai_mode;
        setRobotAiMode(ai_mode);
        printf(" processSetAiMode %d %d\n", __LINE__, ai_mode);
        CLog::log(LogKimbo, LogNormal, "[CManagerAI] processSetAiMode %d!\n",ai_mode);

    }
}

/***********************************************************************************
Function:     processAIRobotSensor
Description:  processAIRobotSensor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::processAIRobotSensor(const CMessage &message)
{
    if(message.content.size() == sizeof(TRobotSensor))
    {
        pthread_mutex_lock(&m_lock_ai_image);

        memcpy(&m_sensor_data, &message.content[0], sizeof(TRobotSensor));

        pthread_mutex_unlock(&m_lock_ai_image);
    }
}
/***********************************************************************************
Function:     processRobotHeartBeat
Description:  processRobotHeartBeat
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::processRobotHeartBeat(const CMessage &message)
{
    if(message.content.size() == sizeof(long long))
    {
        memcpy(&m_receive_calibration_with_3326_time, &message.content[0], sizeof(long long));

        // CLog::log(LogKimbo, LogNormal, "[CManagerAI] processRobotHeartBeatset time %lld !\n", m_receive_calibration_with_3326_time);
    }
}

/***********************************************************************************
Function:     processCameraStatus
Description:  processCameraStatus
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::processCameraStatus(const CMessage &message)
{
    sendCameraStatus();
}

/***********************************************************************************
Function:     processCameraStatus
Description:  processCameraStatus
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::processCameraParams(const CMessage &message)
{
    if(message.content.size() > 0)
    {
        std::string camer_str = "";
        camer_str.resize(message.content.size());
        memcpy(&camer_str[0], &message.content[0], message.content.size());
        std::cout<< "recieve tcp camera param :" << camer_str << std::endl;
    }
}
/***********************************************************************************
Function:     setCurrentImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::updateCurrentImage()
{    

    // static TTimeStamp last_time = 0;
    ai::CImage raw_image = getCurrentImageRawData();
    TTimeStamp time = raw_image.getTimeStamp();
    if(time == m_last_set_image_time_stamp)
        return;
    m_last_set_image_time_stamp = time;

    // ai::CImage raw_image = getCurrentImageRawData();
    cv::Mat src_image = raw_image.getOriginImage();
    // TTimeStamp time = raw_image.getTimeStamp();

    if(src_image.empty() || src_image.cols == 0 || src_image.rows == 0)
        return;

#if CAMERA_200W 
    ai::CImageTransform image_transform;
    cv::Mat resize_image = image_transform.resizeImage(src_image);
    // cv::Mat remap_image = image_transform.fishRemap(resize_image);
    cv::Mat remap_image = resize_image;
#else //100W
    cv::Mat resize_image = src_image;
    cv::Mat remap_image = src_image;
#endif

    pthread_mutex_lock(&m_lock_ai_image);
    m_current_image.setImage(resize_image);
    m_current_image.setOriginImage(remap_image);
    m_current_image.setTimeStamp(time);

    //更新当前图片对应sensor数据
    m_current_image.setRobotSensor(m_sensor_data);
    pthread_mutex_unlock(&m_lock_ai_image);
}

/***********************************************************************************
Function:     getCurrentImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
ai::CImage CManagerAI::getCurrentImage()
{
    pthread_mutex_lock(&m_lock_ai_image);

    ai::CImage image = m_current_image;

    pthread_mutex_unlock(&m_lock_ai_image);

    return image;
}

/***********************************************************************************
Function:     getLocalAiMode
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
base::TAiMode CManagerAI::getLocalAiMode()
{
    ai::CAiParameters m_ai_parameter;
    return m_ai_parameter.getLocalAIMode();
}

/***********************************************************************************
Function:     rgaDataProcess
Description:  rgaDataProcess
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::rgaDataProcess(char *data, int length)
{
    // CLog::log(LogKimbo, LogNormal, "rgaDataProcess callback\n");
    static base::TTimeStamp last_rga_back_time;
    base::TTimeStamp start_cp_camera_img_time = CTime::getCpuTime();
    if (last_rga_back_time > 0)
    {
        // printf("time-statics===camera call back time interval===cost-time:%f ms\n",1000 * CTime::timeDifference(last_rga_back_time,  start_cp_camera_img_time));
    }
    last_rga_back_time = start_cp_camera_img_time;
    
    if(isCameraOpen())
    {
        cv::Mat image(SC_CAMERA_DESTH_HEIGHT, SC_CAMERA_DEST_WIDTH, CV_8UC3);
        memcpy(image.data, (uchar *)data, sizeof(uchar)*length);
        base::TTimeStamp end_cp_camera_img_time = CTime::getCpuTime();
        // printf("time-statics===cp_camera_img_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_cp_camera_img_time,  end_cp_camera_img_time));
        setCurrentImageRawData(image, CTime::getCpuTime());
    }
}
/***********************************************************************************
Function:     isCameraOpen
Description:  isCameraOpen
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CManagerAI::isCameraOpen() 
{
    bool open = false;
    pthread_mutex_lock(&m_lock_is_open_camera);
    open = m_is_camera_open;
 //   CLog::log(LogKimbo, LogNormal, "[CManagerAI] m_is_camera_open status is %d!\n",open);
    pthread_mutex_unlock(&m_lock_is_open_camera);
    return open;
}
/***********************************************************************************
Function:     setRobotAiMode
Description:  setRobotAiMode
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::setRobotAiMode(base::TAiMode ai_mode)
{
    if(ai_mode != base::TAiMode::AI_MODE_IDLE)
    {
        openCamera();
    }
    else 
    {
        closeCamera();
    }

    m_robot_ai.setRobotAIMode(ai_mode);
}


/***********************************************************************************
Function:     setCurrentImageRawData
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::setCurrentImageRawData(cv::Mat &image, base::TTimeStamp time)
{    
    pthread_mutex_lock(&m_lock_image_raw_data);
    m_current_image_raw_data.setOriginImage(image);
    m_current_image_raw_data.setTimeStamp(time);
    pthread_mutex_unlock(&m_lock_image_raw_data);
}

/***********************************************************************************
Function:     setMessageImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::setMessageImage(AIMessages::ImageROI *image_roi,cv::Mat img)
{
    image_roi->set_origin_x(0);
    image_roi->set_origin_y(0);
    int img_width = img.cols;
    int img_height = img.rows;
    image_roi->set_width(img_width);
    image_roi->set_height(img_height);
    uchar *rois=(uchar*)malloc(sizeof(uchar)*img_height*img_width*3);/*[img_width * img_height * 3]*/
    // for (int j = 0; j < img_width * img_height * 3; j++)
    // {
    //     rois[j] = (uchar)img.at<cv::Vec3b>(j / (img_width * 3), (j % (img_width * 3)) / 3)[j % 3];
    // }
    memcpy(rois, img.data, sizeof(uchar)*(img_height)*(img_width)*3);
    std::string str2 = std::string((const char *)rois, img_width * img_height * 3);
    std::string *roi_s = image_roi->mutable_image_data();
    *roi_s = str2;
    free(rois);
    
    //验证图片
    // char *p2 = const_cast<char*>(str2.c_str());   
	// cv::Mat img_transfer(cv::Size(img_width, img_height), CV_8UC3);
	// for (int i = 0; i < img_width * img_height * 3; i++)
	// {
	// 	img_transfer.at<cv::Vec3b>(i / (img_width * 3), (i % (img_width * 3)) / 3)[i % 3] = p2[i];//BGR格式
	// }
    // cv::imwrite("/tmp/tranfer.png", img_transfer);
    
}

/***********************************************************************************
Function:     getCurrentImageRawData
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
ai::CImage CManagerAI::getCurrentImageRawData()
{
    pthread_mutex_lock(&m_lock_image_raw_data);

    ai::CImage image = m_current_image_raw_data;

    pthread_mutex_unlock(&m_lock_image_raw_data);

    return image;
}

/***********************************************************************************
Function:     updateCameraDataThread
Description:  updateCameraDataThread
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::updateCameraDataThread()
{
    while(!m_exit_camera_data_thread)
    {
        this->updateCurrentImage();
        // CLog::log(LogKimbo, LogNormal, "====update camera image data.\n");
        systemSleep(200);
    }
}

/***********************************************************************************
Function:     updateAiThread
Description:  updateAiThread
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::updateAiThread()
{
    // DEBUG
    // openCamera();
    // m_robot_ai.setRobotAIMode(base::AI_MODE_CAMERA_CALIBRATION);
    // m_robot_ai.setRobotAIMode(getLocalAiMode());
    while(!m_exit_ai_thread)
    {
        this->update();
    //    systemSleep(40);
    }
}

/***********************************************************************************
Function:     sendRawDataToServerThread
Description:  sendRawDataToServerThread
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/

void CManagerAI::sendRawImageDataToServerThread()
{
#if RAW_DATA_REAL_TIME_COLLECT
    while(!m_exit_send_raw_img_to_server_thread)
    {
      systemSleep(5);
      ai::CImage raw_image = getCurrentImageRawData();
      TTimeStamp time = raw_image.getTimeStamp();
      if(time == m_last_set_server_raw_image_time_stamp)
        continue;
      m_last_set_server_raw_image_time_stamp = time;
    //   ai::CImage raw_image = getCurrentImageRawData();
      cv::Mat src_image = raw_image.getOriginImage();
    //   TTimeStamp time = raw_image.getTimeStamp();

    #if CAMERA_200W
        ai::CImageTransform image_transform;
        base::TTimeStamp start_crop_img_time = CTime::getCpuTime();
        cv::Mat resize_image = image_transform.resizeImage(src_image);
        // cv::Mat remap_image = image_transform.fishRemap(resize_image);
        base::TTimeStamp end_crop_img_time = CTime::getCpuTime();
        // printf("time-statics===crop_img_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_crop_img_time,  end_crop_img_time));
        cv::Mat remap_image = resize_image;
    #else //100W
        cv::Mat resize_image = src_image;
        cv::Mat remap_image = src_image;
    #endif
        ai::CImage send_image;
        std::string time_stamp = CTime::getTimeString();
        std::string save_image_path =  "/tmp/" + time_stamp + "send_raw_img.jpg";
        
        base::TTimeStamp start_img_io_time = CTime::getCpuTime();
        cv::imwrite(save_image_path, resize_image);
        // printf("time-statics===img_write_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_img_io_time,  CTime::getCpuTime()));
        cv::Mat resize_image_read = cv::imread(save_image_path);
        if(std::remove(save_image_path.c_str())==0)
        {
            std::cout<<"删除成功"<<save_image_path<<std::endl;        
        }
        else
        {
            std::cout<<"删除失败"<<save_image_path<<std::endl;        
        }
        base::TTimeStamp end_img_io_time = CTime::getCpuTime();
        // printf("time-statics===img_io_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_img_io_time,  end_img_io_time));

        // base::TTimeStamp start_img_ecode_time = CTime::getCpuTime();
        // cv::Mat src= resize_image; 
        // //(1) jpeg compression 
        // vector<uchar> buff;//buffer for coding 
        // vector<int> param= vector<int>(2); 
        // param[0]=CV_IMWRITE_JPEG_QUALITY; 
        // param[1]=95;//default(95) 0-100 

        // imencode(".jpg",src,buff,param); 
        // cout<<"coded file size(jpg)"<<buff.size()<<endl;//fit buff size automatically. 
        // Mat jpegimage= imdecode(Mat(buff),CV_LOAD_IMAGE_COLOR); 
        // base::TTimeStamp end_img_ecode_time = CTime::getCpuTime();
        // printf("time-statics===img_encode_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_img_ecode_time,  end_img_ecode_time));

        // send_image.setOriginImage(resize_image);
        send_image.setOriginImage(resize_image_read);
        send_image.setTimeStamp(time);

        CLog::log(LogKimbo, LogNormal, "[CManagerAI] begin send server raw image data.....!\n");

        //更新当前图片对应sensor数据
        sendServerDataCollectionResult(send_image);
    }
#endif
}


/***********************************************************************************
Function:     sendAIModeProcessResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendAIModeProcessResult()
{
    base::TAiMode current_ai_mode = m_robot_ai.getRobotAiMode();
    switch (current_ai_mode)
    {
    case base::AI_MODE_DETECTION:
    {
        sendCameraCoveredStatus(m_robot_ai.isCameraCovered());
        sendDetectResult(m_robot_ai.getDetectResult());
    }
        break;
    case base::AI_MODE_CAMERA_CALIBRATION:
        sendCalibResult(m_robot_ai.getCalibResult());
        break;
    case base::AI_MODE_OUT_FAMILY_TEST:
    {
        sendCameraCoveredStatus(m_robot_ai.isCameraCovered());

    #if FAMILY_DATA_COLLECT
        sendOutFamlityTestDetectResult(m_robot_ai.getDetectResult());
        // if (m_robot_ai.needUploadDetectImg())
        // {
        //     sendOutFamlityTestDetectResult(m_robot_ai.getDetectResult());
        // }
        ai::CImage upload_image = m_robot_ai.getUploadServerImage();
        sendServerDataCollectionResult(upload_image);
    #endif

        sendDetectResult(m_robot_ai.getDetectResult());        
    }
        break;
    case base::AI_MODE_SERVER_DATA_COLLECTION:
    {
        ai::CImage upload_image = m_robot_ai.getUploadServerImage();
        sendServerDataCollectionResult(upload_image);
    }
        break;
    default:
        break;
    }     
}

/***********************************************************************************
Function:     sendObjectDetectResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendDetectResult(const std::vector<ai::TAIObejectDetectData> &result_object)
{
  if(!result_object.empty())
    {
        base::TTimeStamp start_time = CTime::getCpuTime();
        // TODO
        AIMessages::AiMessage ai_message;
        for(size_t i = 0; i < result_object.size(); i++)
        {
            AIMessages::Object *object = ai_message.add_objects();
            ai_message.set_time_stamp(result_object[0].timestamp + m_receive_calibration_with_3326_time); 
            // object->set_class_((AIMessages::Object_ObjectClass)result_object[i].obj_class);
            // object->set_score(result_object[i].classify_score);

            TAIObjectClass obj_dest_class = result_object[i].obj_class;
            double obj_dest_score = result_object[i].classify_score;
            CTypeTransform::transferWeightData(obj_dest_class,obj_dest_score);
            std::string result_label = CTypeTransform::aiObjectClass2String(obj_dest_class);
            CLog::log(LogKimbo, LogNormal, "de %d class name is %s class score %.2f!\n",obj_dest_class,result_label.c_str(),obj_dest_score);
        
            object->set_class_((AIMessages::Object_ObjectClass)obj_dest_class);
            object->set_score(obj_dest_score);

            object->set_robot_pose_time(result_object[i].robot_sensor.time_stamp);
            object->set_robot_pose_x(result_object[i].robot_sensor.robot_pose_x);
            object->set_robot_pose_y(result_object[i].robot_sensor.robot_pose_y);
            object->set_robot_pose_phi(result_object[i].robot_sensor.robot_pose_phi);

            AIMessages::ImageROI *image_roi = object->mutable_image();
            image_roi->set_origin_x(result_object[i].tof_rgb_x1);
            image_roi->set_origin_y(result_object[i].tof_rgb_y1);
            int tof_rgb_width = result_object[i].tof_rgb_x2 - result_object[i].tof_rgb_x1;
            int tof_rgb_height = result_object[i].tof_rgb_y2 - result_object[i].tof_rgb_y1;
             //floor has class, no tof_rgb_width, tof_rgb_height
            CLog::log(LogKimbo, LogNormal, "tof_rgb_width-----%d tof_rgb_height-----%d !\n", 
                       tof_rgb_width,tof_rgb_height);
            if (tof_rgb_width < 2 || tof_rgb_height < 2)
            {
                continue;
            }
            
            image_roi->set_width(tof_rgb_width);
            image_roi->set_height(tof_rgb_height);
            int img_width = image_roi->width();
            int img_height = image_roi->height();
            //floor has class, no img_width, img_height
            CLog::log(LogKimbo, LogNormal, "img_width-----%d img_height-----%d !\n", 
                       img_width,img_height);
            // CLog::log(LogKimbo, LogNormal, "====detect class type is %d\n",result_object[i].obj_class);

            if (result_object[i].obj_class == AI_OBJECT_BLANKET)
            {
                CLog::log(LogKimbo, LogNormal, "blanket print====detect class type is %d send_detect_data_time %f ms\n",result_object[i].obj_class,1000 * CTime::timeDifference(m_last_send_detect_data_time, CTime::getCpuTime()));
                // printf("send_detect_data_time %f ms class_type %d\n",1000 * CTime::timeDifference(m_last_send_detect_data_time, CTime::getCpuTime()),result_object[i].obj_class);
                m_last_send_detect_data_time = CTime::getCpuTime();
                /* code */
            }
            
            if (img_width < 2 || img_height < 2)
            {
                continue;
            }
            cv::Mat tof_img;
            cv::resize(result_object[i].detect_img, tof_img, cv::Size(img_width, img_height));
            uchar *rois=(uchar*)malloc(sizeof(uchar)*img_height*img_width);/*[img_width * img_height * 3]*/
            cv::Mat gray_image;
            cv::cvtColor(tof_img ,gray_image,cv::COLOR_RGB2GRAY);
            std::vector<cv::Mat> split_mat(gray_image.channels());
            cv::split(gray_image,split_mat);
            for (int j = 0; j < img_width * img_height; j++)
            {
                rois[j] = split_mat[0].data[j];
            }
            std::string str2 = std::string((const char *)rois, img_width * img_height);
            std::string *roi_s = image_roi->mutable_image_data();
            *roi_s = str2;
            free(rois);
        }

        CLog::log(LogKimbo, LogNormal, "[CManagerAI] sendDetectResult time %f ms!\n", 
                        1000 * CTime::timeDifference(result_object[0].timestamp, CTime::getCpuTime()));

        m_robot_ai.clearDetectResult();

        std::string output;
        ai_message.SerializeToString(&output);
        // printf("time-statics===sendDetectResultTime===cost-time:%ld\n",1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));

        CMessage message;
        message.setContentFromString(output);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_DETECT_OBJECT, &message);
    }
}

/***********************************************************************************
Function:     sendCameraStatus
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendCameraStatus()
{
    uint8_t camera_status = (m_camera_init_status == true ? 1 : 0);
    CLog::log(LogKimbo, LogNormal, "[CManagerAI] camera status is %d !\n",camera_status);
    CMessage message;
    message.content.resize(sizeof(uint8_t));
    memcpy(&message.content[0], &camera_status, sizeof(uint8_t));
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_CAMERA_STATUS, &message);
}

/***********************************************************************************
Function:     sendCameraCoveredStatus
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendCameraCoveredStatus(bool is_camera_covered)
{
    if (is_camera_covered)
    {
        std::cout<<"send camera covered status----------------->"<<std::endl;
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_CAMERA_COVERED_STATUS, NULL);
        m_robot_ai.clearCameraCoveredStatus();
    }
}

/***********************************************************************************
Function:     requestCameraParam
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::requestCameraParam()
{
    m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_CAMERA_PARAM, NULL);
}


/***********************************************************************************
Function:     sendOutFamlityTestDetectResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendOutFamlityTestDetectResult(const std::vector<ai::TAIObejectDetectData> &result_object)
{
  //  printf("send small image ------------------size %d\n",result_object.size());
    if(!result_object.empty())
    {
        if (result_object.size() == 0)
        {
            return;
        }
        base::TTimeStamp start_time = CTime::getCpuTime();
        // TODO
        AIMessages::ImageDataCollect ai_out_family_test_message;
    
        #if CAMERA_200W 
        ai_out_family_test_message.set_data_type(2);
        #else //100W
        ai_out_family_test_message.set_data_type(1);
        #endif
        CLog::log(LogKimbo, LogNormal, " send outFamlily obj size is %d!\n", result_object.size());
        int send_detect_data_count = 1;
        // send_detect_data_count = result_object.size();
        for(size_t i = 0; i < send_detect_data_count; i++)
        {
            AIMessages::Object *object = ai_out_family_test_message.add_objects();
            ai_out_family_test_message.set_time_stamp(result_object[0].timestamp + m_receive_calibration_with_3326_time); 
            CLog::log(LogKimbo, LogNormal, "[CManagerAI] upload detect image time stamp is %lld ms!\n",result_object[0].timestamp + m_receive_calibration_with_3326_time);

            object->set_class_((AIMessages::Object_ObjectClass)result_object[i].dirty_class);
            object->set_score(result_object[i].classify_score);
            AIMessages::ImageROI *image_roi = object->mutable_image();
            image_roi->set_origin_x(0);
            image_roi->set_origin_y(0);
            int img_width = result_object[i].detect_img.cols;
            int img_height = result_object[i].detect_img.rows;
            image_roi->set_width(img_width);
            image_roi->set_height(img_height);
              
            CLog::log(LogKimbo, LogNormal, "img_width-----%d img_height-----%d !\n", 
                       img_width,img_height);
            CLog::log(LogKimbo, LogNormal, "====data clt class type is %d\n",result_object[i].obj_class);
            uchar *rois=(uchar*)malloc(sizeof(uchar)*img_height*img_width*3);/*[img_width * img_height * 3]*/
            for (int j = 0; j < img_width * img_height * 3; j++)
            {
                rois[j] = (uchar)result_object[i].detect_img.at<cv::Vec3b>(j / (img_width * 3), (j % (img_width * 3)) / 3)[j % 3];
            }

            std::string str2 = std::string((const char *)rois, img_width * img_height * 3);
            std::string *roi_s = image_roi->mutable_image_data();
            *roi_s = str2;
            free(rois);
        }

        CLog::log(LogKimbo, LogNormal, "[CManagerAI] sendOutFamilyDetectResult time %f ms!\n", 
                        1000 * CTime::timeDifference(result_object[0].timestamp, CTime::getCpuTime()));

        // m_robot_ai.clearDetectResult();

        std::string output;
        ai_out_family_test_message.SerializeToString(&output);
        // printf("time-statics===sendOutFamlityTestDetectResultTime===cost-time:%ld\n",1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));

        CMessage message;
        message.setContentFromString(output);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_OUT_FAMILY_TEST, &message);
    }
}


/***********************************************************************************
Function:     sendServerDataCollectionResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendServerDataCollectionResult(ai::CImage &upload_server_image)
{
    cv::Mat upload_image = upload_server_image.getOriginImage();
    // cv::Mat upload_image;
    if(!upload_image.empty())
    {
        // TODO
        AIMessages::ImageDataCollect upload_server_image_message;

        #if CAMERA_200W 
        upload_server_image_message.set_data_type(2);
        #else //100W
        upload_server_image_message.set_data_type(1);
        #endif
        upload_server_image_message.set_time_stamp(upload_server_image.getTimeStamp() + m_receive_calibration_with_3326_time); 
        AIMessages::ImageROI *image_src = upload_server_image_message.mutable_image_src();
        base::TTimeStamp start_set_img_time = CTime::getCpuTime();
        setMessageImage(image_src,upload_image);
        base::TTimeStamp end_set_img_time = CTime::getCpuTime();
        // printf("time-statics===set_dataclt_img_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_set_img_time,  end_set_img_time));
        CLog::log(LogKimbo, LogNormal, "[CManagerAI] upload ori image time stamp is %lld ms!\n",upload_server_image.getTimeStamp() + m_receive_calibration_with_3326_time);
        CLog::log(LogKimbo, LogNormal, "[CManagerAI] sendServerDataCollectionResult time %f ms!\n");

        m_robot_ai.clearUploadServerImage();
        std::string output;
        upload_server_image_message.SerializeToString(&output);
        
        CMessage message;
        message.setContentFromString(output);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_OUT_FAMILY_TEST, &message);
    }
}


/***********************************************************************************
Function:     sendCalibResult
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CManagerAI::sendCalibResult(const ai::TCameraCalibresult &calib_result)
{
    if (calib_result.calib_flag == 1)
    {
        std::cout<<"begin send calib resutl ....."<< std::endl;
        std::cout<<"calib result>>>>>"<<calib_result.camera_param_str<<std::endl;
        AIMessages::ImageCalibration calib_result_message;
        calib_result_message.set_calibration_code(calib_result.result_code);
        // calib_result_message.set_calibration_result(calib_result.camera_param_str);
        calib_result_message.set_calibration_result(calib_result.camera_param_str);
        AIMessages::ImageROI *image_src = calib_result_message.mutable_image_src();
        setMessageImage(image_src,calib_result.src_img);
        AIMessages::ImageROI *image_res = calib_result_message.mutable_image_res();
        setMessageImage(image_res,calib_result.res_img);
       
        std::string output;
        calib_result_message.SerializeToString(&output);
        CMessage message;
        message.setContentFromString(output);
        m_message_broker_ptr->dispatchMessage(EM_ENTITY_AI, EM_ENTITY_TCP, 0, EM_AI_CAMERA_CALIBRATION, &message);
        m_robot_ai.clearCalibResult();
        // setRobotAiMode(base::TAiMode::AI_MODE_IDLE);
        setRobotAiMode(getLocalAiMode());
        std::cout<<"end send calib resutl ....."<< std::endl;
    }
}



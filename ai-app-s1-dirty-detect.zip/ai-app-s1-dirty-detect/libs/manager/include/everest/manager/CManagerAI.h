/**********************************************************************************
File name:	  CManagerAI.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/
#ifndef EVEREST_MANAGER_CMANAGERAI_H_
#define EVEREST_MANAGER_CMANAGERAI_H_

/******************************* Current libs includes ****************************/
#include <everest/base/CMessageBroker.h>
#include <everest/base/CBaseModule.h>
#include <everest/base/CEntityProtocol.h>

#include <everest/hwdrivers/CCameraSensor.h>
#include <everest/base/CAIMessages.pb.h>
#include <everest/ai/CImage.h>
#include <everest/ai/CRobotAi.h>
#include <everest/ai/CAiParameters.h>

/********************************** System includes *******************************/
#include <string>
#include <vector>
#include <thread>

/********************************** Other libs includes ***************************/
#include "opencv2/opencv.hpp"

namespace everest
{
    namespace manager
    {
        class CManagerAI : public base::CBaseModule
        {
            public:
                /* Constructor */
                CManagerAI(int id);

                /* Destructor */
                ~CManagerAI();

                /* Set message borker */
                void setMessageBroker(base::CMessageBroker &message_broker);

                /* Everest ftp init */
                virtual bool initialize();

                /* All entities must implement an close information */
                virtual void close();

                /* All entities must implement an update information */
                virtual void update();

                /* All entities can communicate using messages They are sent using */
                virtual bool handleMessage(const base::CTelegram& telegram);

                /* Update ai thread */
                void updateAiThread();

                /* Update camera data thread */
                void updateCameraDataThread();

            private:                
                void rgaDataProcess(char *data,int length); 
                void open_camera(bool open_camera);

                void processAIRobotSensor(const mrpt::utils::CMessage &message);
                void processSetAiMode(const mrpt::utils::CMessage &message);
                void processRobotHeartBeat(const mrpt::utils::CMessage &message);
                void processCameraStatus(const mrpt::utils::CMessage &message);
                void processCameraParams(const mrpt::utils::CMessage &message);
            
                void sendAIModeProcessResult();
                void sendDetectResult(const std::vector<ai::TAIObejectDetectData> &result_object);
                void sendOutFamlityTestDetectResult(const std::vector<ai::TAIObejectDetectData> &result_object);
                void sendCalibResult(const ai::TCameraCalibresult &calib_result);
                void sendCameraStatus();
                void sendCameraCoveredStatus(bool is_camera_covered);
                void requestCameraParam();
                void sendServerDataCollectionResult(ai::CImage &upload_server_image);
                void sendRawImageDataToServerThread();
            private:
                void openCamera();
                void closeCamera();
                bool isCameraOpen();

                void updateCurrentImage();
                ai::CImage getCurrentImage();
                void setRobotAiMode(base::TAiMode ai_mode);
                void setCurrentImageRawData(cv::Mat &image, base::TTimeStamp time);
                void setMessageImage(AIMessages::ImageROI *image_roi,cv::Mat img);
                ai::CImage getCurrentImageRawData();
                base::TAiMode getLocalAiMode();

                base::TRobotSensor getCurrentTimeRobotSensor(base::TTimeStamp &time);
                void pushCurrentTimeRobotSensor(base::TRobotSensor &robot_sensor);
            
            private:
                bool                        m_is_camera_open;
                ai::CImage                  m_current_image;
                ai::CImage                  m_current_image_raw_data;

                hwdrivers::CCameraSensor    m_camera_sensor;

                std::thread                 m_ai_thread;
                std::thread                 m_camera_data_thread;
                std::thread                 m_send_raw_img_to_server_thread;

                bool                        m_exit_camera_data_thread;
                bool                        m_exit_ai_thread;
                bool                        m_exit_send_raw_img_to_server_thread;
                bool                        m_camera_init_status;

                base::CMessageBroker       *m_message_broker_ptr;
                pthread_mutex_t             m_lock_is_open_camera;
                pthread_mutex_t             m_lock_image_raw_data;
                pthread_mutex_t             m_lock_ai_image;

                ai::CRobotAi                m_robot_ai;
                base::TRobotSensor          m_sensor_data;

                long long                   m_receive_calibration_with_3326_time;
            
                base::TAiMode               m_last_ai_mode;
                base::TTimeStamp            m_last_send_detect_data_time;
                base::TTimeStamp            m_last_set_image_time_stamp;
                base::TTimeStamp            m_last_set_server_raw_image_time_stamp;
                
        };
    }
}

#endif




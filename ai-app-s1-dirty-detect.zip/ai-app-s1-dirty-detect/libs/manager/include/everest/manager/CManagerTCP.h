/**********************************************************************************
File name:	  CEverestTtp.h
Author:       Kimbo
Version:      V1.0.0
Date:	 	  2020-6-1
Description:  File transfer protocol class
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/
#ifndef EVEREST_MANAGER_TCP_H_
#define EVEREST_MANAGER_TCP_H_

/******************************* Current libs includes ****************************/
#include "everest/base/CMessageBroker.h"
#include "everest/base/CBaseModule.h"
#include "everest/base/CMsgClient.h"
#include <everest/base/CTime.h>
#include <everest/base/CNanomsgSocket.h>
#include <everest/hwdrivers/CRobotPacketReceiver.h>
#include <everest/hwdrivers/CRobotPacketSender.h>
#include <everest/base/CEntityProtocol.h>

/********************************** System includes *******************************/
#include <string>
#include <vector>
#include <thread>
#include <iostream>
/********************************** Other libs includes ***************************/

namespace everest
{
    namespace manager
    {
        class CManagerTCP : public base::CBaseModule
        {
            public:
                /* Constructor */
                CManagerTCP(int id);

                /* Destructor */
                ~CManagerTCP();

                /* Set message borker */
                void setMessageBroker(base::CMessageBroker &message_broker);

                /* Everest ftp init */
                virtual bool initialize();

                /* All entities must implement an close information */
                virtual void close();

                /* All entities must implement an update information */
                virtual void update();

                /**/
                virtual void updateThread();
                
                void updateHeartbeat();

                virtual void get3326Uartdata();

                /* All entities can communicate using messages They are sent using */
                virtual bool handleMessage(const base::CTelegram& telegram);
                            
            private:
                void clientCallback(CMsgHead *pmsg);

                

                /* Manager communication */
                bool processAiDetectObject(const mrpt::utils::CMessage &message);
                bool processCameraCalibrationResult(const mrpt::utils::CMessage &message);
                bool processCameraStatus(const mrpt::utils::CMessage &message);
                bool processCameraCoveredStatus(const mrpt::utils::CMessage &message);
                bool processCameraParamRquest(const mrpt::utils::CMessage &message);
                

                /* RK3326 communication */
                void processCmdAiRobotSensorCmd(char* buf, int len);
                void processCmdAiSetMode(char* buf, int len);
                void processCmdAiHeartBreat(char* buf, int len);
                void processCmdAiSyncTime(char* buf, int len);
                void processCmdCameraCalibration(char *buf, int len);
                void processCmdCameraStatus(char *buf, int len);
                void processCameraParams(char *buf, int len);
                void processGet1806Temp(char *buf, int len);
                void processGetNpuDCDC(char *buf, int len);
                void process3326StartState(char *buf, int len);
                void processCmdCameraStatusRequest(char *buf, int len);
                void processGet1806Free(char *buf, int len);
                bool processOutFamalityTest(const mrpt::utils::CMessage &message);
                void processUsbConnectStatus(char *buf, int len);
                int getCpuTemp();

                std::string getNpuDCDC();

                void send1806StartState();

                std::deque<hwdrivers::CRobotPacket> messageTransferObjectPacket(const mrpt::utils::CMessage &message);

                everest::base::TFreeMemory getFreeMemory();
            private:
                base::CMessageBroker         *m_message_broker_ptr;
                std::thread                   m_thread;
                std::thread                   m_3326_thread;
                base::CNanomsgSocket          m_robot_connect_client;
                
                base::TTimeStamp              m_last_receive_heartbeat_time;
                long long                     m_receive_calibration_with_3326_time;
                long long                     m_last_debug_camera_calibrate_time = 1;
                bool                          m_has_recieve_calib_cmd = false;
                bool                          m_is_in_calib_mode  = false;
                int                           m_ai_local_mode_num = 2;

                hwdrivers::CRobotPacketReceiver          m_3326_receiver;
                hwdrivers::CRobotPacketSender            m_3326_sender;
                // auto                                     m_callback;
                bool                                     m_has_recieve_usb_connect_status = false;
        };
    }
}

#endif




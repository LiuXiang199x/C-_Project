/*************************************************************************
	> File Name: CGpioControl.h
	> Author:
	> Mail:
	> Created Time: 2017年07月21日 星期五 19时12分58秒
 ************************************************************************/

#ifndef _CGPIOCONTROL_H
#define _CGPIOCONTROL_H

#define GPFIO_DISENABLE  0
#define GPIO_ENABLE      1

#define GPIO_TYPE_OUT    1
#define GPIO_TYPE_IN     0

class CGpioControl
{
public:
    CGpioControl();
    CGpioControl(int pin, int type,int value);
    ~CGpioControl();
    bool GpioInit(int pin, int type,int value);
    bool GpioWrite(int value);

private:
    bool GpioSetDirection(int pin, int dir);
    bool GpioUnexport(int pin);
    bool GpioExport(int pin);
    int m_pin;
};

#endif

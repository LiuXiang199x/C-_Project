/*************************************************************************
	> File Name: CThread.h
	> Author:
	> Mail:
	> Created Time: 2016年03月05日 星期六 09时47分58秒
 ************************************************************************/

#ifndef _CRSTHREAD_H
#define _CRSTHREAD_H

#include <pthread.h>


class CRSThread
{
    public:
       CRSThread();
        virtual ~CRSThread();

    protected:

private:
    pthread_t pid;
private:

   static void * start_thread(void *arg);
public:
    int start();
    void stop();
    virtual void run() = 0;
    bool m_bool;
    int ThreadGetID(void);
};

#endif

/*************************************************************************
	> File Name: CThread.h
	> Author:
	> Mail:
	> Created Time: 2016年03月05日 星期六 09时47分58秒
 ************************************************************************/

#ifndef _CTHREAD_H
#define _CTHREAD_H

#include <pthread.h>


class CThread
{
    public:
       CThread();
        virtual ~CThread();

    protected:
        int ThreadGetID(void);

    private:
        static void * start_thread(void *arg);

    public:
        int start();
        void stop();

        virtual void run() = 0;

    public:
        bool m_bool;

    private:
        pthread_t pid;

};

#endif

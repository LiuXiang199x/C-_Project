/**********************************************************************************
File name:	  CFileSystem.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-29
Description:  File system class
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

#ifndef EVEREST_BASE_CFILESYSTEM_H_
#define EVEREST_BASE_CFILESYSTEM_H_

/********************************** System includes *******************************/
#include <string>
#include <vector>

/******************************* Other libs includes ******************************/
#include <google/protobuf/text_format.h>

namespace everest
{
    namespace base
    {
    	typedef std::vector<std::string> vector_string;	//!<  A type for passing a vector of strings.

        class CFileSystem
        {
            public:
                /* Read files list in directory , if recursion is true, it will read all files in sub directory */
                static bool readDirFileList(const char *directory, vector_string &files_list, bool recursion);

                /* Extract file name */
                static std::string extractFileName(std::string file_path);

                static int saveProtobufConfig(std::string &file_path, std::string &context);

                static int readProtobufConfig(std::string &file_path, google::protobuf::Message *message);

                static bool fileExists(std::string &file_path);

                /* Extract file path */
                static std::string renameFileExtension(std::string &file_path, std::string new_extension);

                /* Create directory */
                static bool createDirectory(std::string file_path);

                /* Get fs size */
                static int getFsSize(const char *path, int64_t *freeSize, int64_t *totalSize);

                /* Create directory by index */
                static bool createDirectoryByIndex(std::string directory_prefix, std::string &output_dir);

                /* Change to string to vector<char>, and to char* (&cstr[0])*/
                static std::vector<char> string2Vector(std::string &str);

                /* Detect occupany space */
                static uint32_t detectOccupacySpace(vector_string &files_list, std::vector<uint32_t> &files_size_list);
        };
    }
}

#endif



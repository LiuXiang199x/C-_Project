/***********************************************************************************
File name:	  CLogConfig.h
Author:       kibmo
Version:      V1.5
Date:	 	  2016-4-7
Description:  Log system config
Others:       None

History:
 1. Date:
	Author:
	Modification:
************************************************************************************/
#ifndef EVEREST_BASE_CLOGCONFIG_H_
#define EVEREST_BASE_CLOGCONFIG_H_

/********************************** System libs includes ****************************/
#include <string>


/* Parameters config */
struct CLogConfig
{
    /* Constructor */
    CLogConfig();

    std::string log_file_name;
    bool        auto_build_directory;
    bool        create_log_name_auto;
    bool        log_time_string;
    bool        log_module_string;
    bool        log_username_string;
    bool        log_level_string;
    bool        also_printf;
    bool        printf_this_call;
    bool        add_to_logfile;
    bool        different_log;          // Different output between logfile and print, logfile output all information.
    int         out_log_level;
    int         out_log_type;
    int         log_user_list;
    int         log_cut_down_size;
    std::string log_file_path;
};


#endif

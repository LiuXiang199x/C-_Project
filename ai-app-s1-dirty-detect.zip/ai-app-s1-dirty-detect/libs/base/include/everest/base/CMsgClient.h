#ifndef __MSGCLIENT_H__
#define __MSGCLIENT_H__

#include <pthread.h>
#include <sys/select.h>
#include <unistd.h>
#include <inttypes.h>

#include "everest/base/CRSThread.h"
#include "CommonClient.h"

class CMsgClient:public CommonClient, public CRSThread
{
public:
	CMsgClient( );
	~CMsgClient( );
    void Start(MsgCallBack callback, const char * path);
    int Send(int cmd, int len,char *buf,int did=0, uint64_t serialno=0);
    void run();
    void Stop();

private:
	int Connect( char *path);

private:
	char m_path[32];
	pthread_mutex_t m_lock;
};

#endif

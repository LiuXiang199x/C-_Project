#ifndef CRL200S_PROTOCOL_H_
#define CRL200S_PROTOCOL_H_

#include <everest/base/typedef.h>
namespace everest
{
	namespace CRL200S
	{
		struct TMotorVelocity
		{
		    s32 vel1;
		    s32 vel2;
		};

		struct TBlowerSpeed
		{
		    s16 speed;
		};

		typedef struct
		{
			s8	speed;
		}TBrushSpeed;

		struct TSensorVersion
		{
			u8  version;
		};

		struct TCommonSensor
		{
			u8	bumper;
			u8	wheel_up;
			u8	cliff_ir;
			u8 	box;
			u8  virtual_wall;
			u8  dock_ir;
		};

		struct TBatterySensor
		{
			u8	charge_state;
			u8	voltage;
			s8	temperature;
		};

		struct TRemoteTime
		{
		    u16 plan_minutes;
		    u16 clock_minutes;
		};

		struct TMotorSensor
		{
			s64 encoder_left;
			s64	encoder_right;
			s32	wheel_liner_speed;
			s32	wheel_angular_speed;
		};

		struct TIMUSensor
		{
			s16	yaw_vel;
			s16	yaw;
			s16 pitch_vel;
			s16	pitch;
			s16	roll_vel;
			s16	roll;
			s16	acc_x;
			s16	acc_y;
			s16 acc_z;
		};

		struct TKeySensor
		{
			u16 key_global;
			u16 key_point;
			u16 key_dock;
		};

		struct TControlState
		{
			u8	peripheral_state;
			u8	button_led_state;
			u8  motor_control_type;
			s8	brush_speed;
			u8  rolling_brush_speed;
			u8	blower_speed;
			u8  water_pump_speed;
		};


		struct TMotorCurrent
		{
			u16 caster_wheel_holzer;
			u16	walk_motor_left_current;
			u16	walk_motor_right_current;
			u16	brush_current;
			u16	rolling_brush_current;
			u16	blower_current;
			u16	water_pump_current;
		};

		typedef struct
		{
			s32 cliff_liner_velocity;
			s32 cliff_angular_velocity;
			s32 geomagnetic_liner_velocity;
			s32 geomagnetic_angular_velocity;
			s32 bumper_liner_velocity;
			s32 bumper_angular_velocity;
		}TSelfControlParams;

		struct TMaskSensorMotion
		{
		    TMaskSensorMotion()
		    {
			mask_virtual_wall = -1;
			mask_cliff_ir = -1;
			mask_bumper = -1;
		    }
			s8	mask_virtual_wall;
			s8  mask_cliff_ir;
			s8  mask_bumper;
		};

		struct TIMURawData
		{
		    s16 raw_data_valid;
			s16 yaw_vel;
			s16 pitch_vel;
			s16 roll_vel;
		};

		struct TSensorMessageOld
		{
			TSensorVersion	sensor_version;
			TCommonSensor	common_sensor;
			TBatterySensor	battery_sensor;
			TMotorSensor 	motor_sensor;
			TIMUSensor	  	imu_sensor;
			TKeySensor	  	key_sensor;
			TControlState 	control_state;
			TMotorCurrent 	motor_current;
		};

		struct TSensorMessageAppend
		{
		    TIMURawData     imu_raw_data;
		};

		struct TSensorMessage
		{
			TSensorVersion	sensor_version;
			TCommonSensor	common_sensor;
			TBatterySensor	battery_sensor;
			TMotorSensor 	motor_sensor;
			TIMUSensor	  	imu_sensor;
			TKeySensor	  	key_sensor;
			TControlState 	control_state;
			TMotorCurrent 	motor_current;
		    TIMURawData     imu_raw_data;
		};

		enum TButtonLEDState
		{
		    LED_DARK				    = 0,
		    LED_BLUE_BRIGHT  			= 1,
		    LED_GREEN_BRIGHT  			= 2,
		    LED_YELLOW_BRIGHT  			= 3,
		    LED_YELLOW_BREATH  			= 4,
		    LED_YELLOW_DOUBLE_FLASH 	= 5,
		    LED_YELLOW_FLASH 			= 6,
		    LED_RED_BRIGHT  			= 7,
		    LED_RED_FLASH	  			= 8,
		    LED_R_G_Y_FLASH			    = 9,
		    LED_R_Y_FLASH			    = 10,
		    LED_BLUE_FLASH		        = 11,
			LED_BLUE_BREATH             = 12,
			LED_YELLOW_THREE_FLASH      = 13,
			LED_BLUE_THREE_FLASH        = 14,
			LED_RED_QUICK_FLASH         = 15,
			LED_RED_SLOW_FLASH          = 16,
		    LED_STATE_NUM               = 17
		};

		enum TWeakUpType
		{
		    WEAKUP_NONE = 0,
		    WEAKUP_BUTTON,
		    WEAKUP_REMOTE,
		    WEAKUP_RTC,
		    WEAKUP_NETWORK
		};

		enum TKey
		{
			KEY_NONE = 0,
			KEY_TASK_STOP,
			KEY_TASK_START,
			KEY_TASK_CHARGE,
		    KEY_TASK_GLOBAL,
		    KEY_TASK_POINT,
		    KEY_TASK_MOPPING,
		    KEY_NETWORK_CONFIG,
			KEY_POWER_OFF,
			KEY_PRESS_LONG,
			KEY_HAREWARE_UNBOND
		};

		enum TRemote
		{
		    REMOTE_PAUSE        = -1,
			REMOTE_NONE         = 0,
			REMOTE_CLRAN        = 1,
			REMOTE_LEFT         = 2,
			REMOTE_RIGHT        = 3,
			REMOTE_FORWADE      = 4,
			REMOTE_CLEAN_LEVEL  = 5,
			REMOTE_HOME         = 6,
			REMOTE_WALLFOLLOW   = 7,
			REMOTE_SPIRAL       = 8,
			REMOTE_MOPPING      = 9,
			REMOTE_LOCATION     = 10,
			REMOTE_POWER_ECO    = 11,
			REMOTE_POWER_NORMAL = 12,
			REMOTE_POWER_DEEP   = 13,
			REMOTE_BACKWARD     = 14
		};

		typedef enum
		{
		    MOTOR_CONTROL_TYPE_UNKNOW = -1,
			MOTOR_CONTROL_TYPE_FREE,
			MOTOR_CONTROL_TYPE_SPEED,
			MOTOR_CONTROL_TYPE_VELOCITY
		}TMotorControlType;

		typedef enum
		{
			ERRO_CODE_NONE = 0,
			ERRO_CODE_IMU,
			ERRO_CODE_MOTOR_OVER_CURRENT
		}TErrorCode;

		typedef struct
		{
			u32	sensor_version;
			u32 function_list;
		}TMachineFunctionList;
	}
}



#endif

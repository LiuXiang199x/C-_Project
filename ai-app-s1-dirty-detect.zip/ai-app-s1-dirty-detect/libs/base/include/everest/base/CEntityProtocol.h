/*********************************************************************************
File name:    CEntityProtocol.h
Author:       Kimbo
Version:      V1.5.0
Date:	      2016-5-5
Description:  This is protcol to everest system
Others:       None

History:
    Date:
    Author:
    Modification:
***********************************************************************************/

#ifndef EVEREST_BASE_CENTITYPROTOCOL_H_
#define EVEREST_BASE_CENTITYPROTOCOL_H_

#define FAMILY_DATA_COLLECT 1
#define RAW_DATA_REAL_TIME_COLLECT 0
namespace everest
{
    namespace base
    {
        enum TEverestEntityName
        {
            EM_ENTITY_AI = 0,
            EM_ENTITY_TCP,
            EM_ENTITY_NUM
        };

        enum TAiMode
        {
            AI_MODE_IDLE = 0,
            AI_MODE_DETECTION,
            AI_MODE_OUT_FAMILY_TEST,
            AI_MODE_LOCAL_DATA_COLLECTION,
            AI_MODE_SERVER_DATA_COLLECTION,
            AI_MODE_CAMERA_CALIBRATION,
            AI_MODE_NUM
        };

        enum TEverestProtocol
        {
            EM_SYSTEM = 0,
            EM_ROBOT_HEART_BEAT,
            
            EM_AI_ROBOT_SENSOR = 100,

            EM_SET_AI_MODE  = 200,
            EM_AI_DETECT_OBJECT,
            EM_AI_OUT_FAMILY_TEST,
            EM_AI_CAMERA_CALIBRATION,
            EM_AI_CAMERA_STATUS,
            EM_AI_CAMERA_COVERED_STATUS,
            EM_AI_CAMERA_PARAM,
        };

        enum TAiProtocol
        {
            CMD_AI_START                                = 0,
            CMD_AI_CAMERA_STATUS                        = 10,
            CMD_AI_CAMERA_STATUS_RQUEST                 = 11,
            CMD_AI_SET_MODE                             = 12,
            CMD_AI_HEARTBAEAT                           = 13,
            CMD_AI_SYNC_TIME                            = 14,
            CMD_AI_CAMERA_COVERED_STATUS                = 15,
            CMD_AI_SYNC_START_STATUS                    = 16,
            CMD_USB_CONNECT_STATUS                      = 18,

            CMD_AI_SYSTEM_CHANNEL		                = 100,

            CMD_AI_DETECT_OBJECT                        = 101,
            CMD_AI_CAMERA_CALIBRATION                   = 102,
            CMD_AI_OUT_FAMILY_TEST_DATA_COLLECTION      = 103,
            CMD_AI_ROBOT_SENSOR                         = 104,
            CMD_AI_CAMERA_PARAM                         = 105,
            CMD_AI_1806_TEMP                            = 106,
            CMD_AI_NPU_DCDC                             = 107,
            CMD_AI_1806_FREE                            = 108,

            CMD_NUM                                     = 255
        };
        
        struct TRobotSensor
        {
            TRobotSensor()
            {
                time_stamp = 0;
            };
            uint64_t    time_stamp;
            float pitch;
            float roll;
            float yaw;
            float odo_lin_vel;
            float odo_ang_vel;
            float robot_pose_x;
            float robot_pose_y;
            float robot_pose_phi;
        };

        struct TAIDetectData
        {
            uint64_t    time_stamp;
            uint16_t    object_class;
            uint16_t    img_origin_x;
            uint16_t    img_origin_y;
            uint16_t    img_width;
            uint16_t    img_height;
            uint8_t     object_score;

            TRobotSensor  robot_sensor;
        };

        struct TFreeMemory
        {
            uint32_t free_total;
            uint32_t free_used;
            uint32_t free_free;
            uint32_t free_shared;
            uint32_t free_buffers;
            uint32_t free_cached;
        };
    }
}


#endif



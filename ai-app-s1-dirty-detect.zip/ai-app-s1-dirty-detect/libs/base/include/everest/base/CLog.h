/***********************************************************************************
File name:	  CLog.h
Author:       Kimbo
Version:      V1.5
Date:	 	  2016-2-26
Description:  Log system
Others:       None

History:
 1. Date:
	Author:
	Modification:
************************************************************************************/

#ifndef EVEREST_BASE_CLOG_H
#define EVEREST_BASE_CLOG_H

/******************************* System libs includes ******************************/
#include <string>
#include <pthread.h>

/******************************* Current libs includes *****************************/
#include "CLogConfig.h"
#include "CThreadSafeQueue.h"

/******************************* Other libs includes *******************************/

#define LOG_DIRECTORY           "/tmp/"

        #define BIT_0 int(1 << 0)
        #define BIT_1 int(1 << 1)
        #define BIT_2 int(1 << 2)
        #define BIT_3 int(1 << 3)
        #define BIT_4 int(1 << 4)
        #define BIT_5 int(1 << 5)
        #define BIT_6 int(1 << 6)
        #define BIT_7 int(1 << 7)
        #define BIT_8 int(1 << 8)
        #define BIT_9 int(1 << 9)
        #define BIT_10 int(1 < 10)
        #define BIT_11 int(1 < 10)
        #define BIT_ALL int(BIT_0|BIT_1|BIT_2|BIT_3|BIT_4|BIT_5|BIT_6|BIT_7|BIT_8|BIT_9|BIT_10|BIT_11)

        typedef enum
        {
            LogErro = 0,
            LogWarn,
            LogNormal
        }LogLevel;

        typedef enum
        {
            LogSpencer  = BIT_0,
            LogFandy    = BIT_1,
            LogYyang    = BIT_2,
            LogKimbo    = BIT_3,
            LogXia      = BIT_4,
            LogKlaus    = BIT_5,
            LogGareth   = BIT_6,
            LogMeng     = BIT_7,
            LogShizhe   = BIT_8,
            LogSara     = BIT_9,
            LogEden     = BIT_10,
            logMu       = BIT_11,
            LogAll      = BIT_ALL
        }LogUser;

        #define MAX_LOG_SIZE                2048

        struct TLogMessage
        {
            int         user;
            std::string msg;
        };

        class CLog
        {
            public:
                typedef enum
                {
                    LogStdOut = 0,      /* Use stdout for logging */
                    LogFile,        /* Use a file for logging */
                    LogNone         /* Disable logging */
                }LogType;

                /* Init log info */
                static bool init(LogType type, LogLevel level,
                                 int user, std::string file_name,
                                 bool log_time = false,
                                 bool log_user = false,
                                 bool log_level = false,
                                 bool also_print = false,
                                 bool add_to_file = false,
                                 bool diff_log = false,
                                 bool print_this_call = true);

                /* Set perfix number */
                static void setPerfixNumber(int perfix_number) {m_perfix_number = perfix_number;}

                /* Init log system */
                static bool init();

                /* Init log file */
                static bool init(std::string config_file_path);

                /* Init log config */
                static bool init(CLogConfig &log_config);

                /* Log info,input loguser & logLevel & log info*/
                static void log(LogUser user, LogLevel level, const char *str, ...);

                /* Close log file */
                static void close();

                /* Reset Config */
                static void resetConfig();

                /* Build additional string */
                static bool buildAdditionalString(std::string &str, LogUser user, LogLevel level);

                /* Get log file path */
                static std::string getLogFilePath();

                /* log cut control */
                static void logControl();

                /* Read log system perfix */
                static int readLogSystemPerfix();

                /* Cut down current log file, cut down current log file, and copy it to dest file path */
                static void cutDownLogFile(std::string &dest_file_path);

            private:
                /* Printf User Config */
                static void printfUserConfig();

                /* Init unlock */
                static bool initUnlock();

                /* Build string according to config */
                static void buildNowTimeString(std::string &str);
                static void buildUserNameString(std::string &str, LogUser user);
                static void buildLogLevelSting(std::string &str, LogLevel level);
                static void *asyncLogThread(void *arg);

            public:
                static CLogConfig   m_option;
            private:
                static pthread_mutex_t m_cs;                   /* Log cs */
                static FILE         *m_out_FP;                  /* Log File handle */
                static std::string  m_log_level_string[3];      /* Log level string */
                static std::string  m_log_user_string[13];      /* Log user string */
                static int          m_perfix_number;
                static bool         m_create_thread_flag;
                static pthread_t    m_log_thread;
                static CThreadSafeQueue<TLogMessage> m_queue;
        };


#endif


#ifndef EVEREST_CCONFIGFILE_H
#define EVEREST_CCONFIGFILE_H

#include <string>
#include <vector>
#include <stdlib.h>
#include <fstream>
#include <iostream>
namespace everest
{
    namespace base
    {
        class CConfigFile
        {
            public:
                CConfigFile()
                {
                    m_config_item_list.clear();
                }

                ~CConfigFile()
                {

                }
                struct TConfigItem
                {
                    TConfigItem()
                    {
                        item1.clear();
                        item2.clear();
                    }
                    TConfigItem(std::string &iitem1, std::string &iitem2)
                    {
                        item1 = iitem1;
                        item2 = iitem2;
                    }
                    std::string item1;
                    std::string item2;
                };

                enum TLoadType
                {
                    LOAD_TYPE_INT = 0,
                    LOAD_TYPE_STRING,
                };

                void trim(std::string &s)
                {
                    int index = 0;
                    if( !s.empty())
                    {
                        while( (index = s.find(' ',index)) != std::string::npos)
                        {
                            s.erase(index,1);
                        }
                    }
                }
            template<class T>
                bool loadConfigValueInt(T &value, std::string context)
                {
                    if(m_config_item_list.empty())
                    {
                        return false;
                    }
                    bool find_value = false;
                    for(size_t i = 0; i < m_config_item_list.size(); i++)
                    {
                        if(m_config_item_list[i].item1 == context)
                        {
                            value = atoi(m_config_item_list[i].item2.c_str());
                            find_value = true;
                            break;
                        }
                    }
                    return find_value;
                }

                template<class T>
                bool loadConfigValueString(T &value, std::string context)
                {
                    if(m_config_item_list.empty())
                    {
                        return false;
                    }
                    bool find_value = false;
                    for(size_t i = 0; i < m_config_item_list.size(); i++)
                    {
                        if(m_config_item_list[i].item1 == context)
                        {
                            value = std::string(m_config_item_list[i].item2);
                            find_value = true;
                            break;
                        }
                    }
                    return find_value;
                }

            template<class T>
                bool loadConfigValueDouble(T &value, std::string context)
                {
                    if(m_config_item_list.empty())
                    {
                        return false;
                    }
                    bool find_value = false;
                    for(size_t i = 0; i < m_config_item_list.size(); i++)
                    {
                        if(m_config_item_list[i].item1 == context)
                        {
                            value = atof(m_config_item_list[i].item2.c_str());
                            find_value = true;
                            break;
                        }
                    }
                    return find_value;
                }

                bool readFileContext(const std::string &file_path)
                {
                    std::ifstream file;
                    file.open(file_path.c_str());
                    if(!file)
                    {
                        std::cout << " open  " << file_path << " fail!!" << std::endl;
                        return false;
                    }
                    m_config_item_list.clear();
                    while(file)
                    {
                        std::string line;
                        getline(file, line);
                        int pos = line.find("=") ;
                        if(pos != std::string::npos)
                        {
                            std::string str1 = std::string(line.begin(), line.begin() + pos);
                            std::string str2 = std::string(line.begin() + pos + 1, line.begin() + line.size());
                            trim(str1);
                            trim(str2);
                            m_config_item_list.push_back(TConfigItem(str1, str2));
                        }
                    }
                    return true;
                }
                bool saveFileContext(const std::string &file_path)
                {
                    std::ofstream file;
                    file.open(file_path.c_str(), std::ios::app);
                    if(!file)
                    {
                        std::cout << " open  " << file_path << " fail!!" << std::endl;
                        return false;
                    }
                    for(size_t i = 0; i < m_config_item_list.size(); i++)
                    {
                        std::string str1 = m_config_item_list[i].item1;
                        std::string str2 = m_config_item_list[i].item2;
                        std::string line = str1 + "=" + str2;
                        file  << line << std::endl;
                    }
                    file.close();
                    return true;
                }
            template<class T>
                void addContext(const T &a, const std::string &str1)
                {
                    TConfigItem item;
                    item.item1 = str1;
                    std::ostringstream ss;
                    ss << a;
                    item.item2 = ss.str();
                    m_config_item_list.push_back(item);
                }

        private:
            std::vector<TConfigItem>    m_config_item_list;
        };
    }
}

#endif

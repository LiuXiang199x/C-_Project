#ifndef EVEREST_BASE_CTHREADSAFEQUEUE_H
#define EVEREST_BASE_CTHREADSAFEQUEUE_H

#include <queue>
#include <unistd.h>

template<typename T>
class CThreadSafeQueue
{
  private:
     pthread_mutex_t         m_cs;
     std::queue<T>           data_queue;
  public:
     CThreadSafeQueue(){}

     void push(T new_value)//入队操作
     {
         pthread_mutex_lock(&m_cs);

         data_queue.push(new_value);

         pthread_mutex_unlock(&m_cs);
     }

     void wait_and_pop(T& value)//直到有元素可以删除为止
     {
         while(1)
         {
              pthread_mutex_lock(&m_cs);

              if(data_queue.empty())
              {
                  pthread_mutex_unlock(&m_cs);

                  usleep(100);
              }
              else
              {
                 value=data_queue.front();
                 data_queue.pop();
                 pthread_mutex_unlock(&m_cs);
                 break;
              }
         }
     }
};

#endif

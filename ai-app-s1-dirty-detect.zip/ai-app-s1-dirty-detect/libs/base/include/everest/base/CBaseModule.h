/**********************************************************************************
File name:	  CBaseModule.h
Author:       Kimbo
Version:      V1.5
Date:	 	  2016-2-22
Description:  Entiy base class
Others:       None
History:
    1. Date:2015-9-9
    Author:Kimbo
    Modification: (1).Change CBaseModule name to CBaseModule
                  (2).Remove the function which judge the ID must greater than next ID,
                      because there is have entity ID table to manger it
    2. Date:2016-2-22
    Author:Kimbo
    Modification: Refactoring it
 **********************************************************************************/

#ifndef EVEREST_BASE_CBASEMODULE_H_
#define EVEREST_BASE_CBASEMODULE_H_

/******************************* Current libs includes *****************************/
#include <everest/base/CTelegram.h>

/******************************* System libs includes ******************************/
#include <deque>
#include <mutex>

/******************************* Other libs includes *******************************/

namespace everest
{
    namespace base
    {
		class CBaseModule
		{
            public:
                /* Constructor */
                CBaseModule(int id);

                /* Destructor */
                virtual ~CBaseModule();

            public:
                /* All entities must implement an initialize information */
                virtual bool initialize();

                /* All entities must implement an close information */
                virtual void close();

                /* All entities must implement an update information */
                virtual void update();

                /* All entities can communicate using messages They are sent using */
                virtual bool handleMessage(const CTelegram& telegram);

                /* Get entity ID */
                int getID() const;

                /* Push message to pending list */
                void pushMessageToPendingList(const CTelegram& telegram);

                /* Get pending message list size */
                unsigned int getPendingMessageListSize();

                /* Get Pending message list */
                std::deque<CTelegram> getPendingMessageList();

            private:
                /* Set entity ID */
                void setID(const int value);

            private:
                int		                        m_ID;                            /* Every entity must have a unique identifying number*/
                unsigned int                    m_pending_messsage_max_size;     /* Pending message list max size */
                std::mutex                      m_pending_message_cs;            /* Pending message lock */

            protected:
                std::deque<CTelegram>           m_pending_message_list;          /* Pending message list*/

		};
    }
}

#endif


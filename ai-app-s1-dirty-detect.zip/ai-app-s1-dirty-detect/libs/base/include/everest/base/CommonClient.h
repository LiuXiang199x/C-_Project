#ifndef __COMMONCLIENT_H__
#define __COMMONCLIENT_H__

#include <sys/select.h>
#include <unistd.h>
#include <inttypes.h>
#include "CMsgHead.h"
#include <functional>



//typedef void (*MsgCallBack)(CMsgHead *pmsg);

class CommonClient
{
public:
	CommonClient( );
	CommonClient(int fd, MsgCallBack callback);
	~CommonClient( );

public:
	int SetNonblocking(int fd);
	int ReceiveLocalData();
	int SendLocalData(CMsgHead *msg);
	void SetCallback(MsgCallBack callback);

	void Close();
	int GetFD();

private:
	int SendMaxData(char *buffer, int length);
	int SendData(char *buffer,int length);


protected:
    int m_stat;
    int m_fd;

private:
	MsgCallBack 	m_dataCallback;
	char 			m_recvBuf[MAX_MSG_LEN];
	int 			m_recvLen;
	CMsgHead 		m_msgHead;
};

#endif

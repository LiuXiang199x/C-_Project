/*********************************************************************************
File name:	 CFilePath.h
Author:		 Spencer Wu
Version: 	 V1.0.0
Date:		 2017-03-02
Description: File path manager, include config file path, log file path eg
Others:		 None
History:
	1.Date:
	Author:
	Modification:

*********************************************************************************/

#ifndef EVEREST_BASE_CFILEPATH_H_
#define EVEREST_BASE_CFILEPATH_H_

/********************************** System includes *******************************/
#include <string>

namespace everest
{
	namespace base
	{
		class CFilePath
		{
			public:
				/* Constructor */
				CFilePath();

				/* Destructor */
				~CFilePath();

			public:
				static std::string getLogConfigFilePath(void) {return m_log_config_file_path;}
				static std::string getCameraParametersConfigFilePath(void) {return m_camera_parameters_config_file_path;}
				static std::string getClassMinScoreConfigFilePath(void) {return m_class_min_score_config_file_path;}
				static std::string getLogPathPrefix() {return m_log_path_prefix;}
				static std::string getAiImagePathPrefix() {return m_ai_image_path_prefix;} 

			private:
				static std::string  	m_log_path_prefix;
				static std::string		m_log_config_file_path;
				static std::string		m_camera_parameters_config_file_path;
				static std::string		m_ai_image_path_prefix;
				static std::string 		m_class_min_score_config_file_path;
		};
	}
}

#endif

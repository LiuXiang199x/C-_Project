/**********************************************************************************
File name:	  CNanomsgSocket.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is the robot packet
Others:       None

History:
	1. Date: 2015-09-20
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/
#ifndef EVEREST_HWDRIVERS_CNanomsgSocket_H_
#define EVEREST_HWDRIVERS_CNanomsgSocket_H_

/********************************** File includes *********************************/

/********************************** Current libs includes *************************/
#include <everest/base/ferrari_protocol.h>
#include <everest/base/CRSThread.h>
#include <everest/base/CMsgHead.h>

/********************************** System includes *******************************/
#include <string>
#include <stdbool.h>
#include <pthread.h>
#include <sys/select.h>
#include <unistd.h>

/******************************* Other libs includes ******************************/

namespace everest
{
	namespace base
	{
		class CNanomsgSocket : CRSThread
		{
			public:

				/* Constructor */
				CNanomsgSocket();

				/* Destrcutor */
				~CNanomsgSocket();

                int Start(std::string ip_send, std::string ip_receive, MsgCallBack call_back);
                int Send(int cmd, int len, char *buf, int did = 0, uint64_t serialno = 0);
                void run();
                void Stop();

                int ReceiveLocalData(char *buf, int recv_len);
            private:
            	void SetCallback(MsgCallBack callback) {m_dataCallback = callback;}

            public:
                std::string     m_ip_send_path;
                std::string     m_ip_recv_path;
	            pthread_mutex_t m_lock;
	            MsgCallBack 	m_dataCallback;

                int             m_socket_send;
                int             m_socket_recv;

                char 		    m_recvBuf[MAX_MSG_LEN];
                int             m_stat;
	            int 			m_recvLen;
	            CMsgHead 		m_msgHead;
		};
	}
}

#endif

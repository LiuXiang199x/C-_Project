/*********************************************************************************
File name:	 CDeviceR16.h
Author:		 Spencer Wu
Version: 	 V1.0.0
Date:		 2017-03-02
Description: RK 3188 drivers, for getting CPU information such as ip, sn eg
Others:		 None
History:
	1.Date:
	Author:
	Modification:

*********************************************************************************/

#ifndef EVEREST_HWDRIVERS_CDEVICER16_H_
#define EVEREST_HWDRIVERS_CDEVICER16_H_

/********************************** System includes *******************************/
#include <string>

/********************************** Otherlibs includes ***************************/

namespace everest
{
	namespace base
	{
		class CDeviceR16
		{
			public:
				enum TStorageReadType
				{
					STORAGE_SN = 0,
					STORAGE_MAC
				};

				struct TNandFlashSystemStorage
				{
					unsigned long tag;
					unsigned long length;
					unsigned char data[512];
				};

				/* Constructor */
				CDeviceR16();

				/* Destructor */
				~CDeviceR16();

				/* Get mac address */
				std::string getMacAddress(int length);
				int getMacAddress(char *buf, int length);

				/* Get rk3188 sn */
				static std::string getSN(int length);
				static int getSN(char *buf, int length);
				static std::string getTestWifiSsid(int length);

				/* Get local mac */
				std::string getLocalMac(const char *name, int length);

				/* Get rk3188 wlan ssid */
				int getWlanSSID(char *buf, int length);

				/* Get rk3188 local ip */
				static int getLocalIP(const char *name, char *ip_address, int length);

				/* Generate ID */
				int generateID(char *buf, int length);

                /* Read machine id */
                static bool readMachineID(std::string &machine_id);

			private:
				/* Read system storage data */
				int readSystemStorage(TStorageReadType type, char *buf, int size);

				/* Get storage read length of type SN */
				int getSnStorageReadLength(const TNandFlashSystemStorage &system_data);

				/* Get storage read length of type MAC */
				int getMacStorageReadLength(const TNandFlashSystemStorage &system_data);


			private:
				const int m_sn_length_offset;
				const int m_mac_length_offset;
				const unsigned long m_sn_sector_op_tag;
				const int m_storage_data_length;
		};
	}
}


#endif




#ifndef _PROTOCOL_H_
#define _PROTOCOL_H_

#include <everest/base/typedef.h>
#include <string.h>

typedef enum
{
	CMD_START 				        = 0,
	CMD_ERRO_CODE 			        = 1,
	CMD_OPEN				        = 2,
	CMD_CLOSE				        = 3,
	CMD_SYSTEM_SLEEP		        = 4,
	CMD_SYSTEM_WEAKUP		        = 5,
	CMD_HEART_BEAT			        = 6,
	CMD_VERSION				        = 7,
	CMD_IMU_SET_ZERO                = 8,
	CMD_STARTINGUP_STATE            = 9,
	CMD_RESET_HWDRIVER_ERROR        = 10,
	CMD_SYSTEM_POWER_OFF            = 11,
    CMD_TINAHALTED_DETECT_ONCE		= 12,			// It will reset when stm32 restart
	CMD_TINAHALTED_HEART_BEAT		= 13,

	CMD_SYSTEM_CHANNEL		        = 20,

	CMD_SENSOR				        = 21,
	CMD_SENSOR_CHANNEL		        = 100,

	CMD_MOTOR_CONTROL_TYPE          = 101,
	CMD_MOTOR_VELOCITY		        = 102,
	CMD_MOTOR_SPEED			        = 103,
	CMD_BLOWER_SPEED		        = 104,
	CMD_BRUSH_SPEED 		        = 105,
	CMD_ROLLING_BRUSH_SPEED         = 106,

    CMD_BLOWER_PWM					= 110,
	CMD_SIDE_BRUSH_PWM				= 111,
	CMD_ROLL_BRUSH_PWM			    = 112,
    CMD_LIDAR_PWM                   = 113,

    CMD_CLIFFIR_CONTROL             = 120,
    CMD_CLIFFIR_DIRECTION           = 121,
	CMD_MOTOR_CHANNEL		        = 140,

	CMD_BUTTON_LED			        = 141,
	CMD_DISPLAY_CHANNEL	            = 150,

	CMD_LIDAR_POWER			        = 151,
	CMD_PERIPHERAL_POWER	        = 152,
    CMD_R16_POWER			        = 153,
    CMD_RESTART_R16_SYSTEM          = 154,
    CMD_CHARGER_POWER               = 155,
	CMD_POWER_CHANNEL		        = 160,

	CMD_IMU_CALIBRATION				= 161,
	CMD_IMU_CALIBRATION_STATE 		= 162,
	CMD_VIRWALL_CALIBRATION     	= 163,
	CMD_VIRWALL_CALIBRATION_STATE 	= 164,
    CMD_R16_INTOTEST             	= 165,

	CMD_CALIBRATION_CHANNEL 		= 170,

	CMD_DEBUG_1				        = 171,
	CMD_DEBUG_2				        = 172,
	CMD_DEBUG_3				        = 173,
	CMD_DEBUG_CHANNEL		        = 180,
    CMD_MACHINE_ID                  = 181,

	CMD_FACTORY_START               = 220,
    CMD_FACTORY_ADB_STATE           = 221,
    CMD_FACTORY_ADB_CONTROL         = 222,
    CMD_FACTORY_LIDAR_DATA          = 223,
    CMD_FACTORY_LIDAR_CONTROL       = 224,
    CMD_FACTORY_LIDAR_SPEED         = 225,
    CMD_FACTORY_WIFI_SSID           = 226,
    CMD_FACTORY_ROBOT_INFO1_REQ     = 227,
    CMD_FACTORY_ROBOT_INFO2_REQ     = 228,
    CMD_FACTORY_AGING_TIME     = 229,

	CMD_FACTROY_END                 = 240,

	CMD_END					        = 255	// Command end
}TCommandID;

struct TRobotVersion
{
    TRobotVersion()
    {
        memset(softversion, 0, sizeof(softversion));
        memset(hardversion, 0, sizeof(hardversion));
        memset(everest_version, 0, sizeof(everest_version));
        memset(stm32_version, 0, sizeof(stm32_version));
    }
    char     softversion[25];
    char     hardversion[10];
    char     everest_version[25];
    char     stm32_version[25];
};

struct TNetInfo
{
    TNetInfo()
    {
        memset(devsn, 0, sizeof(devsn));
        memset(ipaddr, 0, sizeof(ipaddr));
        memset(mac, 0, sizeof(mac));
        memset(lidar_version, 0, sizeof(lidar_version));

    }
    char     devsn[32];
    char     ipaddr[16];
    char     mac[20];
    char     lidar_version[10];
};

struct TMotorVelocity
{
    s32 vel1;
    s32 vel2;
};

struct TBlowerSpeed
{
    s16 speed;
};

typedef struct
{
	s8	speed;
}TBrushSpeed;

struct TSensorVersion
{
	u8  version;
};

struct TCommonSensor
{
	u8	bumper;
	u8	wheel_up;
	u8	cliff_ir;
	u8 	dust_box;
	u8  virtual_wall;
	u8  dock_ir;
};

struct TBatterySensor
{
	u8	charge_state;
	u8	voltage;
	s8	temperature;
};

struct TMotorSensor
{
	s64 encoder_left;
	s64	encoder_right;
	s32	wheel_liner_speed;
	s32	wheel_angular_speed;
};

struct TIMUSensor
{
	s16	yaw_vel;
	s16	yaw;
	s16 pitch_vel;
	s16	pitch;
	s16	roll_vel;
	s16	roll;
	s16	acc_x;
	s16	acc_y;
	s16 acc_z;
};

struct TKeySensor
{
	u16 key_global;
	u16 key_point;
	u16 key_dock;
};

struct TControlState
{
	u8	peripheral_state;
	u8	button_led_state;
	u8  motor_control_type;
	u8	brush_speed;
	u8  rolling_brush_speed;
	u8	blower_speed;
};


struct TMotorCurrent
{
	u16 caster_wheel_holzer;
	u16	walk_motor_left_current;
	u16	walk_motor_right_current;
	u16	brush_current;
	u16	rolling_brush_current;
	u16	blower_current;
};

struct TSensorMessage
{
	TSensorVersion	sensor_version;
	TCommonSensor	common_sensor;
	TBatterySensor	battery_sensor;
	TMotorSensor 	motor_sensor;
	TIMUSensor	  	imu_sensor;
	TKeySensor	  	key_sensor;
	TControlState 	control_state;
	TMotorCurrent 	motor_current;
};

enum TButtonLEDState
{
    LED_DARK				    = 0,
    LED_BLUE_BRIGHT  			= 1,
    LED_GREEN_BRIGHT  			= 2,
    LED_YELLOW_BRIGHT  			= 3,
    LED_YELLOW_BREATH  			= 4,
    LED_YELLOW_DOUBLE_FLASH 	= 5,
    LED_YELLOW_FLASH 			= 6,
    LED_RED_BRIGHT  			= 7,
    LED_RED_FLASH	  			= 8,
    LED_R_G_Y_FLASH			    = 9,
    LED_R_Y_FLASH			    = 10,
    LED_BLUE_FLASH		        = 11,
	LED_BLUE_BREATH             = 12,
	LED_YELLOW_THREE_FLASH      = 13,
	LED_BLUE_THREE_FLASH        = 14,
	LED_RED_QUICK_FLASH         = 15,
	LED_RED_SLOW_FLASH          = 16,
    LED_STATE_NUM               = 17
};

enum TWeakUpType
{
    WEAKUP_NONE = 0,
    WEAKUP_BUTTON,
    WEAKUP_REMOTE,
    WEAKUP_RTC,
    WEAKUP_NETWORK
};

enum TKey
{
	KEY_NONE = 0,
	KEY_TASK_STOP,
	KEY_TASK_START,
	KEY_TASK_CHARGE,
    KEY_TASK_GLOBAL,
    KEY_TASK_POINT,
    KEY_NETWORK_CONFIG,
	KEY_POWER_OFF,
	KEY_PRESS_LONG,
	KEY_HAREWARE_UNBOND
};

enum TRemote
{
	REMOTE_NONE = 0,
	REMOTE_UP,
	REMOTE_DOWN,
	REMOTE_LEFT,
	REMOTE_RIGHT,
	REMOTER_MIDDLE
};

typedef enum
{
    MOTOR_CONTROL_TYPE_UNKNOW = -1,
	MOTOR_CONTROL_TYPE_FREE,
	MOTOR_CONTROL_TYPE_SPEED,
	MOTOR_CONTROL_TYPE_VELOCITY
}TMotorControlType;

typedef enum
{
	ERRO_CODE_NONE = 0,
	ERRO_CODE_IMU,
	ERRO_CODE_MOTOR_OVER_CURRENT
}TErrorCode;

struct TMachineID
{
	TMachineID()
	{
		memset(machine_id, 0, sizeof(machine_id));
		memset(machine_mac, 0, sizeof(machine_mac));
	}
	char machine_id[32];
	char machine_mac[20];
};

#endif

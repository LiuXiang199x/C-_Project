/*********************************************************************************
File name:	  CMessageDeque.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-08
Description:  This class is data struct for App messsage list
Others:       None

History:
    Date:
    Author:
    Modification:
***********************************************************************************/
#ifndef EVEREST_BASE_TPROTOLBUFMSG_H_
#define EVEREST_BASE_TPROTOLBUFMSG_H_

/******************************* Current libs includes ****************************/
#include <stddef.h>
#include <stdint.h>
#include <iostream>
#include <string.h>
#include <functional>



struct CMsgHead
{
    CMsgHead()
    {
        head_mark = 0;
        cmd = 0;
        len = 0;
        did = 0;
        serialno = 0;
        buf = NULL;
    }
	int       head_mark;
	int       cmd;
	int       len;
	int       did;
	uint64_t  serialno;
	char      *buf;

	void copyHead(const CMsgHead &msg)
	{
        this->head_mark = msg.head_mark;
        this->cmd = msg.cmd;
        this->did = msg.did;
        this->serialno = msg.serialno;
	}

    void deepCopy(const CMsgHead &msg)
    {
        if(this->buf == NULL)
        {
            copyHead(msg);
            if(msg.len != 0)
            {
                this->buf = (char* )malloc(msg.len);
                memcpy(this->buf, msg.buf, msg.len);
                this->len = msg.len;
            }
        }
        else
        {
            std::cout << "[CMsgHead] copyBuf failed buf is not nullptr " << std::endl;
        }
    }

	void setValue(int command, int length, char *buffer)
	{
        this->cmd = command;
        this->len = length;
        this->buf = buffer;
	}
};

struct TiiiNetWorkInfo
{
    TiiiNetWorkInfo()
    {
        head_mark = 0;
        cmd = 0;
        len = 0;
        did = 0;
        cid = 0;
        serialno = 0;
    }
    int       head_mark;
    int       cmd;
    int       len;
    int       did;
    int       cid;
    uint64_t  serialno;
};
#define IS_MSG_HEAD (0x5867a9b0)
#define MAX_FD(x,y) (((x) > (y)?(x):(y)))
enum MSG_TYPE{
    MSG_HEAD=1,
    MSG_BODY,
    MSG_ERR
};

#define MAX_MSG_LEN  (4*1000*2000)
#define MSG_HEAD_LEN  (sizeof(CMsgHead))

typedef std::function<void (CMsgHead *pmsg)>  MsgCallBack; 

#endif




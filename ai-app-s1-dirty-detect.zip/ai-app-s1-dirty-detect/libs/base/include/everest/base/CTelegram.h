/*********************************************************************************
File name:	  CTelegram.h
Author:       Kimbo
Version:      V1.5.0
Date:	 	  2016-5-5
Description:  This defines a telegram. A telegram is a data structure that
              records information required to dispatch messages. Messages
              are used by game agents to communicate with each other.
Others:       None

History:
1.  Date:
    Author:
    Modification:
***********************************************************************************/

#ifndef EVEREST_BASE_CTELEGRAM_H_
#define EVEREST_BASE_CTELEGRAM_H_

/******************************* System libs includes ******************************/
#include <math.h>
#include <iostream>

/******************************* Other libs includes *******************************/
#include <everest/base/CMessage.h>

namespace everest
{
    namespace base
    {
        class CTelegram
        {
            public:
                /* Constructor */
                CTelegram();

                /* Constructor */
                CTelegram(const int sender, const int receiver,
                          const int channel, const int event,
                          const mrpt::utils::CMessage &info,
                          const double time = 0.0);

                /* Constructor */
                CTelegram(const int sender, const int receiver,
                          const int channel, const int event,
                          const double time = 0.0);

                /* Destructor */
                ~CTelegram();

                /* Set/Get sender */
                void setSender(const int sender) {m_sender = sender;}
                int getSender() const {return m_sender;}

                /* Set/Get receiver */
                void setReceiver(const int receiver) {m_receiver = receiver;}
                int getReceiver() const {return m_receiver;}

                /* Set/Get channel */
                void setChannel(const int channel) {m_channel = channel;}
                int getChannel() const {return m_channel;}

                /* Set/Get event*/
                void setEvent(const int event) {m_event = event;}
                int getEvent() const {return m_event;}

                /* Set/Get extra information */
                void setExtraInforamtion(const mrpt::utils::CMessage& extra_info) { m_extra_information = extra_info;}
                const mrpt::utils::CMessage& getExtraInformation() const {return m_extra_information;}

                /* Return true if telegram is same, but not compare extra information */
                bool isEqual(const CTelegram &telegram) const;

                /* Override operate << */
                friend std::ofstream& operator << (std::ofstream &os, const CTelegram &telegram);

           private:
                int                         m_sender;                      /* The entity that sent this telegram */
                int                         m_receiver;                    /* The entity that is to receive this telegram */
                int                         m_channel;                     /* The entity message channel */
                int                         m_event;                       /* The entity message event */
                mrpt::utils::CMessage       m_extra_information;           /* Information that may accompany the message */
        };
    }
}

#endif

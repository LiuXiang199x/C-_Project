#ifndef __MSGSERVER_H__
#define __MSGSERVER_H__

#include <pthread.h>
#include <sys/select.h>
#include <unistd.h>
#include <inttypes.h>

#include "CRSThread.h"
#include "CommonClient.h"

class CMsgServer:public CRSThread
{
public:

	CMsgServer();
	~CMsgServer();

	void Start(MsgCallBack callback, const char *path);
	int Send(int cmd, int len, char *buf, int did = 0, uint64_t serialno = 0);
	void run();
	void Stop();

private:
    int Accept();
    int Init(char * path);
    void SetMaxFd();
    void ScheduleConnect();
    void AddClient(int fd);
    void RemoveClient();
    int RecvData( CommonClient * pCurClient);

private:
	int m_Svrfd;
	char m_path[32];
	int m_maxfd;
	fd_set m_Rset;
	CommonClient *m_client;
	MsgCallBack m_recv;
	pthread_mutex_t m_List_lock;
};

#endif

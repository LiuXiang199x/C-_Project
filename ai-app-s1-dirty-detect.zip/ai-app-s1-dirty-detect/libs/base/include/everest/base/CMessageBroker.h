/**********************************************************************************
File name:	  CEverestTtp.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  File transfer protocol class
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/
#ifndef EVEREST_BASE_CMESSAGEBROKER_H_
#define EVEREST_BASE_CMESSAGEBROKER_H_

/******************************* Current libs includes ****************************/
#include "CBaseModule.h"
#include <everest/base/CTelegram.h>

/********************************** System includes *******************************/
#include <string>
#include <vector>
#include <map>

/********************************** Other libs includes ***************************/
#include <everest/base/CMessage.h>

namespace everest
{
    namespace base
    {

        class CMessageBroker
        {
            public:
                /* Constructor */
                CMessageBroker();

                /* Destructor */
                ~CMessageBroker();

            public:
                /* register entity ID */
                void registerEntity(everest::base::CBaseModule* newEntity);

                /* return a pointer to the entity with the ID given as a parameter */
                everest::base::CBaseModule* getEntityFromID(int id);

                /* send a message to another agent. It will accord to msg find it receive agent */
                void dispatchMessage(int     sender,
                                     int     receiver,
                                     int     channel,
                                     int     event,
                                     mrpt::utils::CMessage *extra_info = NULL,
                                     double  delay = 0.0);
            private:
                /* Send out messages. and handle message right now.*/
                void discharge(everest::base::CBaseModule* pReceiver, const everest::base::CTelegram& msg);

            private:
                /* entity map include (entity's ID and entity) */
                typedef std::map<int, everest::base::CBaseModule*>  TEntityMap;

                TEntityMap	                                        m_entityMap;    /* Entity map */

        };
    }
}

#endif




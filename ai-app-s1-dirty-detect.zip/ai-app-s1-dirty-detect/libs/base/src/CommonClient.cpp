
#include <sys/time.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/socket.h>


#include <sys/un.h>
#include <netinet/in.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <stdbool.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>


#include "everest/base/CommonClient.h"



#define MAX_SEND_LEN   80*1024


CommonClient::CommonClient( )
{
    m_dataCallback = NULL;
    m_fd = -1;
    memset(m_recvBuf,0x0,sizeof(m_recvBuf));
    m_recvLen =0;
    m_stat=MSG_HEAD;
}

CommonClient::~CommonClient( )
{
}

CommonClient::CommonClient(int fd,MsgCallBack callback):m_fd(fd),m_dataCallback(callback)
{
    SetNonblocking(fd);
    memset(m_recvBuf,0x0,sizeof(m_recvBuf));
    m_recvLen =0;
    m_stat=MSG_HEAD;
}

void CommonClient::SetCallback(MsgCallBack callback)
{
    m_dataCallback = callback;
}

int CommonClient::SetNonblocking(int fd)
{
  if (fd < 0)
    return -1;

  int opts;
  if ((opts = fcntl(fd, F_GETFL)) != -1)
  {
    opts = opts | O_NONBLOCK;
    if(fcntl(fd, F_SETFL, opts) != -1)
	{
      return 0;
    }
  }
  return -1;
}

void CommonClient::Close()
{
    if(-1 != m_fd)
        close(m_fd);

    m_fd = -1;
    memset(m_recvBuf,0x0,sizeof(m_recvBuf));
    m_recvLen =0;
    m_stat=MSG_HEAD;
}

int CommonClient::GetFD()
{
    return m_fd;
}


/*************************************************
  Function: ReceiveLocalData
  Description: Receive data from Local Net
  Input:
  Output:
  Return:
*************************************************/
int CommonClient::ReceiveLocalData()
{
    int len = 0;

	len = recv(m_fd,m_recvBuf+m_recvLen,sizeof(m_recvBuf)-m_recvLen,0);

    if (len < 0)
	{
	    printf("[CommonClient]recv err %s\n", strerror(errno));
        if(errno != EINTR || errno != EAGAIN )
        {
            return -1;
        }
    }

	if (len == 0)
    {
	    if(errno != EINTR || errno != EAGAIN )
		{
            printf("[CommonClient]closed by server! err %s\n", strerror(errno));
            return -1;
		}
	}
    else
    {
        m_recvLen += len;
        len = m_recvLen - MSG_HEAD_LEN;

        while( ( m_stat==MSG_HEAD && len>=0 )  || ( m_stat==MSG_BODY  &&  len >= m_msgHead.len ))
        {
            if (m_stat==MSG_HEAD && len>=0)
            {
                memset(&m_msgHead,0x0,MSG_HEAD_LEN);
                memcpy(&m_msgHead,m_recvBuf,MSG_HEAD_LEN);

                if (m_msgHead.len > len)
                {
                    return 0;
                }
                else if(m_msgHead.len  > MAX_MSG_LEN)
                {
                    printf("[CommonClient]m_msgHead ----len(%d) is over max len\n", m_msgHead.len);
                    m_stat = MSG_ERR;
                    return -1;
                }

				if(m_msgHead.head_mark != IS_MSG_HEAD)
                {
                    m_stat = MSG_ERR;
                    printf("[CommonClient] m_msgHead ----head_mark(%x) is err,socet will close\n",m_msgHead.head_mark);
                    return -1;
                }
                m_stat = MSG_BODY;
            }

            if (m_stat==MSG_BODY && len>= m_msgHead.len )
            {
                CMsgHead * m_head;
                m_head = (CMsgHead *)malloc(sizeof(CMsgHead));
                if(m_head == NULL)
                {
                    return 0;
                }
                memset(m_head,0x0,sizeof(CMsgHead));
                memcpy(m_head,m_recvBuf,sizeof(CMsgHead));

                char *buf =NULL;
                buf = (char *)malloc(m_msgHead.len * sizeof(char)+1);
                if(buf==NULL)
                    return 0;

                memset(buf,0x0,m_msgHead.len +1);
                memcpy(buf,m_recvBuf + sizeof(CMsgHead),m_msgHead.len );
                m_head->buf = buf;
                m_head->len = m_msgHead.len;

                if(m_dataCallback)
                {
                    m_dataCallback(m_head);
                }

                int pkglen = m_msgHead.len+MSG_HEAD_LEN;
                memset(m_recvBuf, 0x0, pkglen);
                memset(&m_msgHead,0x0,MSG_HEAD_LEN);
                memcpy(m_recvBuf, m_recvBuf+pkglen, m_recvLen-pkglen);
                m_recvLen -= pkglen;
                len = m_recvLen - MSG_HEAD_LEN;
                m_stat = MSG_HEAD;

            }
        }
	}
	return 0;
}

/*************************************************
  Function: SendLocalData
  Description:
  Input: Message head Pointer
  Output:
  Return:
*************************************************/
int CommonClient::SendLocalData(CMsgHead *pmsg)
{
	int nbyte = 0;
	int send_byte = 0;
	if(m_fd < 0 || NULL == pmsg)
	{
        printf("[CommonClient] m_fd <0 || NULL == pmsg\n");
		return -1;
	}
    // printf( "aaaaa3333---\n");
	nbyte = SendMaxData((char *)pmsg,sizeof(CMsgHead));

    // printf( "aaaaa4444---\n");
	if(nbyte < 0)
	{
        printf("[CommonClient] SendMsg msg head error\n");
		return -1;
	}

	send_byte += nbyte;

	if((pmsg->len > 0) && (NULL != pmsg->buf))
	{
		nbyte = SendMaxData(pmsg->buf,pmsg->len);
        // printf( "aaaaa5555---\n");
		if(nbyte < 0)
		{
            printf("[CommonClient] send msg body err\n");
            return -1;
		}
		send_byte += nbyte;
	}
	return send_byte;
}

/*************************************************
  Function: SendmaxData
  Description: send buffer data
  Input:   buffer - data buffer, length - data buffer
           length
  Output:
  Return: buffer length that is sent
 *************************************************/
int CommonClient::SendMaxData(char *buffer,int length)
{
    int sendByte= 0;
    int nbyte = 0;
    int curSend =0;

    sendByte = length;

    while(sendByte>0)
    {
        if(sendByte >= MAX_SEND_LEN)
        {
            nbyte = SendData(buffer+curSend, MAX_SEND_LEN);
            if(nbyte<0)
            {
                curSend=-1;
                break;
            }

            curSend += nbyte;
            sendByte -= nbyte;
            usleep(10*1000);
        }
        else
        {
            nbyte = SendData(buffer+curSend,sendByte);
            if(nbyte<0)
            {
                curSend=-1;
                break;
            }

            curSend += nbyte;
            sendByte -= nbyte;
          }
    }

    return curSend;
}


/*************************************************
  Function: SendData
  Description:
  Input:
  Output:
  Return:
*************************************************/
int CommonClient::SendData(char *buffer,int length)
{
    int sendByte= 0;
    int nbyte = 0;
    int sendCout =0;
    if(NULL == buffer || length == 0 || m_fd <0)
	{
        printf("[CommonClient] buffer or length err\n");
		return -1;
	}

    while(sendByte< length)
	{
        // printf("send begin\n");
		nbyte = send(m_fd,buffer+sendByte,length-sendByte,MSG_NOSIGNAL);
        // printf("send end");
		if(nbyte <=0)
		{
			if(errno != EINTR && errno != EAGAIN )
			{
                printf( "[CommonClient] LocalSendData::errno != EINTR  %d ::%s\n ",errno,strerror(errno));
				sendByte = -1;
				break;
			}
			sendCout++;
			usleep(10*1000);
			if(sendCout > 5)
			{
                printf("[CommonClient]LocalSendData::send over times\n");
				sendByte = -1;
				break;
			}
		}
		else
		   sendByte += nbyte;
	}
    return sendByte;
}





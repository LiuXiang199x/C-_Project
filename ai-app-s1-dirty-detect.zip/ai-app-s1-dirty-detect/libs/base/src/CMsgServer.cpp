#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <iostream>
#include "everest/base/CMsgServer.h"

// #include <everest/hwdrivers/MsgServer.h>
// #include <everest/hwdrivers/CLog.h>


#define MAX_SEND_LEN   64*1024


CMsgServer::CMsgServer( )
{
	m_maxfd = 0;
	m_client = NULL;
	memset(m_path,0x0,sizeof(m_path));
	FD_ZERO(&m_Rset);
	pthread_mutex_init(&m_List_lock,NULL);
}

CMsgServer::~CMsgServer( )
{
    pthread_mutex_destroy(&m_List_lock);
}


/*************************************************
  Function: Start
  Description:
  Input:
  Output:
  Return:
*************************************************/
void CMsgServer::Start(MsgCallBack callback, const char * path)
{
	memcpy(m_path,path,strlen(path));
	m_recv = callback;
	start();

}

/*************************************************
  Function: Stop
  Description:
  Input:
  Output:
  Return:
*************************************************/
void CMsgServer::Stop()
{
    stop();
}

/*************************************************
  Function: Send
  Description:
  Input:
  Output:
  Return:
*************************************************/
int CMsgServer::Send(int cmd, int len, char *buf, int did, uint64_t serialno)
{
    pthread_mutex_lock(&m_List_lock);

	if (((0 == len) && (NULL != buf)) ||
		((NULL == buf) && (0 != len)))
	{
		// CLog::log(LogKimbo, LogErro, "------Error to Send when len does not match with buf ---\n");
		pthread_mutex_unlock(&m_List_lock);
		return -1;
	}

   	int ret = 0;
	CMsgHead msg;
	msg.head_mark = IS_MSG_HEAD;
	msg.cmd = cmd;
	msg.len = len;
	msg.did = did;
	msg.serialno = serialno;
	msg.buf = buf;
	if(m_client != NULL)
	{
		ret = m_client->SendLocalData(&msg);
		if(ret <= 0)
		{
		    m_client->Close();
		    RemoveClient();
			// CLog::log(LogKimbo, LogErro, "MsgServer Send Data Failed and delete client\n");
		}
	}
	pthread_mutex_unlock(&m_List_lock);
    return 0;
}


/*************************************************
  Function: run
  Description: ����˼����̼߳����ͻ�������
  Input:
  Output:
  Return:
*************************************************/
void CMsgServer::run()
{
	int nready = -1;
	struct timeval wait_time;

	int thread_id = ThreadGetID();
	// CLog::log(LogKimbo, LogNormal, "Thread_ID = (%d)\n", thread_id);

	Init(m_path);
	m_maxfd = m_Svrfd;

	while(m_bool)
	{

		wait_time.tv_sec =	0;
		wait_time.tv_usec = 1000 * 300;

		if(m_Svrfd < 0)
        {
            nready = Init(m_path);
            if(nready < 0)
            {
                sleep(5);
                continue;
            }
        }

		m_maxfd = m_Svrfd;
		FD_ZERO(&m_Rset);
		FD_SET(m_maxfd,&m_Rset);
		SetMaxFd();
		nready = select(m_maxfd + 1, &m_Rset, NULL, NULL, &wait_time);
		if(nready < 0)
		{
			if(errno != EINTR)
			{
				// CLog::log(LogKimbo, LogErro,"select failed, err=%s\n", strerror(errno));
				break;
			}
			else
			{
				usleep(1000);
				continue;
			}
		}
		else if(nready == 0)
		{
			usleep(1000);
			continue;
		}
		else
		{
			if (FD_ISSET(m_Svrfd, &m_Rset))
			{
				int clientSock =-1;
				clientSock = Accept();
				if(clientSock == -1)
				{
					// CLog::log(LogKimbo,LogNormal,"accept err m_path = %s \n ",m_path);
					continue;
				}
                printf("accept AddClient  clientSock= %d \n ",clientSock);
                AddClient(clientSock);
			}
			else
			{
				ScheduleConnect();
			}
		}

	}
	close(m_Svrfd);
}



/*************************************************
  Function: Init
  Description:
  Input:
  Output:
  Return:
*************************************************/
int CMsgServer::Init(char * path)
{
	int ret = -1;
	struct sockaddr_un ser_addr;

	m_Svrfd = socket(AF_LOCAL, SOCK_STREAM, 0);
	if(-1 == m_Svrfd)
	{
		// CLog::log(LogKimbo, LogErro,"socket::errno =	%d ::%s\n ",errno,strerror(errno));
		return -1;
	}

	// CLog::log(LogKimbo, LogErro,"CMsgServer::Init socket::m_Svrfd =	%d \n ",m_Svrfd);
    unlink(path);
	bzero(&ser_addr,sizeof(ser_addr));
	ser_addr.sun_family=AF_LOCAL;
	strcpy(ser_addr.sun_path,path);

	if (-1 == bind(m_Svrfd,(struct sockaddr *)&ser_addr,sizeof(ser_addr)))
	{
		// CLog::log(LogKimbo, LogErro,"bind::errno =%d ::%s\n  ",errno,strerror(errno));
		if(m_Svrfd > 0)
		{
			close(m_Svrfd);
			m_Svrfd = -1;
		}
		return -1;
	}

	if (-1 == listen(m_Svrfd,10))
	{
		// CLog::log(LogKimbo, LogErro,"lisen error:%s\n",path);
		if(m_Svrfd > 0)
		{
			close(m_Svrfd);
			m_Svrfd = -1;
		}
		return -1;
	}

	return 0;
}

/*************************************************
  Function: Accept
  Description:
  Input:
  Output:
  Return:
 *************************************************/
int CMsgServer::Accept()
{
	struct sockaddr_in client_sockaddr;
	int len ;
	len= sizeof(client_sockaddr);
	int clientSock =-1;
	if ((clientSock = accept(m_Svrfd, (struct sockaddr *)&client_sockaddr, (socklen_t*)&len)) < 0)
	{
		// CLog::log(LogKimbo, LogErro,"Accept::errno =%d ::%s \n",errno,strerror(errno));
		return -1;
	}

	int nLen = 1024*1024;
	if (setsockopt(clientSock, SOL_SOCKET, SO_RCVBUF, (const char *)&nLen, sizeof(int)) == -1)
	{
		// CLog::log(LogKimbo, LogErro,"setsockopt::SO_RCVBUF errno =%d ::%s \n",errno,strerror(errno));
		close(clientSock);
		return -1;
	}

    int reuseaddr = 1;
    if (setsockopt(clientSock, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(reuseaddr)) == -1)
    {
        close(clientSock);
        clientSock  =-1;
        return -1;
    }

	if (setsockopt(clientSock, SOL_SOCKET, SO_SNDBUF, (const char *)&nLen, sizeof(int)) == -1)
	{
		// CLog::log(LogKimbo, LogErro,"setsockopt SO_SNDBUF failed, error=%s\n", strerror(errno));
		close(clientSock);
		return -1;
	}

	return clientSock;
}

/*************************************************
  Function: SetMaxFd
  Description:

*************************************************/
void CMsgServer::SetMaxFd()
{
	pthread_mutex_lock(&m_List_lock);
	if(m_client == NULL)
	{
		pthread_mutex_unlock(&m_List_lock);
		return;
	}

    FD_SET(m_client->GetFD(),&m_Rset);
	m_maxfd = MAX_FD(m_maxfd ,m_client->GetFD());

	pthread_mutex_unlock(&m_List_lock);
}


void CMsgServer::AddClient(int fd)
{
    pthread_mutex_lock(&m_List_lock);

	if (NULL != m_client)
	{
		delete m_client;
		m_client = NULL;
	}

	m_client = new CommonClient(fd, m_recv);

	if (NULL == m_client)
	{
	    // CLog::log(LogKimbo, LogErro, "MsgServer recv one client link err\n");
		return;
	}
    pthread_mutex_unlock(&m_List_lock);

	// CLog::log(LogKimbo, LogNormal, "MsgServer Recv one clinet Link\n");
}

void CMsgServer::RemoveClient()
{
	if (NULL != m_client)
	{
		delete m_client;
		m_client = NULL;
		// CLog::log(LogKimbo, LogNormal, "MsgServer Delete on Client \n");
	}

}

int CMsgServer::RecvData(CommonClient * pCurClient)
{
    if(-1 == pCurClient->ReceiveLocalData())
    {
        // CLog::log(LogKimbo, LogNormal,"MsgServer::RecvData is err\n");
        pCurClient->Close();
        return -1;
    }

    return 0;
}

/*************************************************
  Function: ScheduleConnect
  Description:
  Input:
  Output:
  Return:
*************************************************/
void CMsgServer::ScheduleConnect()
{
    pthread_mutex_lock(&m_List_lock);

	if (NULL != m_client)
	{
        if(FD_ISSET(m_client->GetFD(), &m_Rset))
		{
            if(RecvData(m_client)==-1)
			{
				m_client->Close();
				RemoveClient();
				// CLog::log(LogKimbo, LogNormal, "MsgServer Recv Data Error\n");
			}
		}
	}
	pthread_mutex_unlock(&m_List_lock);
}


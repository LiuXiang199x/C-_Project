/**********************************************************************************
File name:	  CFileSystem.cpp
Author:       Kimbo
Version:      V1.5.0
Date:	 	  2016-4-25
Description:  Time class
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/base/CFileSystem.h>

/******************************* Current libs includes ****************************/
#include <everest/base/CTime.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>

/******************************* System libs includes *****************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/vfs.h>
#include <fstream>
#include <fcntl.h>
#include <cstdio>

/********************************** Other libs includes ***************************/
#include <google/protobuf/io/zero_copy_stream_impl.h>

/*********************************** Name space ***********************************/
using namespace std;
using namespace everest;
using namespace everest::base;

/***********************************************************************************
Function:     readDirFileList
Description:  Read files list in directory , if recursion is true,
              it will read all files in sub directory
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CFileSystem::readDirFileList(const char *directory, vector_string &files_list, bool recursion)
{
    DIR *dir;
    struct dirent *ptr;
    char base[1000];
    const char *base_path = directory;

    if ((dir=opendir(base_path)) == NULL)
    {
        CLog::log(LogKimbo, LogWarn, "[CFileSystem]Can not open directory!\n");
        return false;
    }

    while ((ptr=readdir(dir)) != NULL)
    {
        if(strcmp(ptr->d_name,".")==0 || strcmp(ptr->d_name,"..")==0)
        {
            /* Current dir OR parrent dir */
            continue;
        }
        else if(ptr->d_type == 8)
        {
            /* File */
            std::string str = evformat("%s/%s", base_path, ptr->d_name);
            files_list.push_back(str);
        }
        else if(ptr->d_type == 10)
        {
            /* Link file */
        }
        else if(ptr->d_type == 4)
        {
            /* Directory */
            if(recursion)
            {
                memset(base,'\0',sizeof(base));
                strcpy(base, base_path);
                strcat(base,"/");
                strcat(base, ptr->d_name);
                readDirFileList(base, files_list, true);
            }
        }
    }
    closedir(dir);
    return true;
}

/***********************************************************************************
Function:     getFsSize
Description:  获取挂载目录 剩余大小，总大小，单位KB
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CFileSystem::getFsSize(const char *path, int64_t*freeSize, int64_t *totalSize)
{
    struct statfs myStatfs;
    if (statfs(path, &myStatfs) == -1)
    {
        return -1;
    }
    //注明int64_t，避免数据溢出
    *freeSize = (((int64_t)myStatfs.f_bsize * (int64_t)myStatfs.f_bfree) / (int64_t) 1024) ;
    *totalSize = (((int64_t)myStatfs.f_bsize * (int64_t)myStatfs.f_blocks) / (int64_t) 1024) ;

    return 0;
}
#if 0
/***********************************************************************************
Function:     detectOccupacySpace
Description:  Detect occupancy space
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
uint32_t CFileSystem::detectOccupacySpace(vector_string &files_list, std::vector<uint32_t> &files_size_list)
{
    files_size_list.resize(files_list.size());
    int total_file_kb_size = 0;

    for(size_t i = 0; i < files_list.size(); i++)
    {
        uint64_t file_bytes = mrpt::system::getFileSize(files_list[i]);
        uint64_t file_kb = file_bytes / 1024;

        if(file_bytes > 1e+10 || file_bytes < 0)
        {
            CLog::log(LogKimbo, LogNormal, "[CFileSystem] file bytes less then file_bytes!\n");

            file_bytes = 0;
            file_kb = 0;
        }

        files_size_list[i] = file_kb;
        total_file_kb_size += file_kb;

//        CLog::log(LogKimbo, LogNormal, "[CFileSystem] %s, file size %lld B, %lld KB! file, total file %d\n",
//                  files_list[i].c_str(), file_bytes, file_kb, total_file_kb_size);
    }

//    int file_size_m = total_file_kb_size / 1024;
//    int file_size_g = file_size_m / 1024;
//
//    CLog::log(LogKimbo, LogNormal, "[CFileSystem] file_size_kbytes %d, file_size_m %d, file_size_g %d!\n",
//              total_file_kb_size, file_size_m, file_size_g);

    return total_file_kb_size;
}

/***********************************************************************************
Function:     extractFileName
Description:  Extract file name
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CFileSystem::extractFileName(std::string file_path)
{
    std::string file_name, file_type;

    file_name = mrpt::system::extractFileName(file_path);
    file_type = mrpt::system::extractFileExtension(file_path);

    return (file_name + "." + file_type);
}
#endif // 0

/***********************************************************************************
Function:     renameFileExtension
Description:  Rename file extension
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CFileSystem::renameFileExtension(std::string &file_path, std::string new_extension)
{
    if (file_path.size()<2) return (file_path + "." + new_extension);

	size_t i_end = file_path.size()-1;

	int	i= (int)(i_end);
	while (i>0)
	{
		if (file_path[i]=='.')
		{
			string the_ext = file_path.substr(0, i) + "." + new_extension;
            return the_ext;
		}
		else
            i--;
	}
	return (file_path + "." + new_extension);
}
#if 0
/***********************************************************************************
Function:     createDirectory
Description:  Create directory if it not exist
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CFileSystem::createDirectory(std::string file_path)
{
    if(mrpt::system::directoryExists(file_path))
    {
        return true;
    }
    else
    {
        mrpt::system::createDirectory(file_path);
    }

    if(mrpt::system::directoryExists(file_path))
    {
        return true;
    }
    else
    {
        cout << "[CFileSystem] can not create directory!" << endl;
        return false;
    }
}
/***********************************************************************************
Function:     createDirectoryByIndex
Description:  Create directory by index
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CFileSystem::createDirectoryByIndex(std::string directory_prefix, std::string &output_dir)
{
    std::vector<size_t> index_list;
    for(size_t i = 0; i < 100; i++)
    {
        std::string file_path = directory_prefix + mrpt::format("%d", (int)i);
        if(mrpt::system::directoryExists(file_path))
        {
            index_list.push_back(i);
            cout << "[CFileSystem] Directory " << file_path << " is exist!" << endl;
        }
    }

    std::string file_path;
    if(index_list.empty())
    {
        file_path = directory_prefix + mrpt::format("%d", (int)0);
    }
    else
    {
        file_path = directory_prefix + mrpt::format("%d", int(index_list.at(index_list.size() - 1) + 1));
    }
    file_path = file_path + "/";

    output_dir = file_path;

    return createDirectory(file_path);
}

#endif // 0

/***********************************************************************************
Function:     string2Vector
Description:  Change to string to vector<char>, and to char* (&cstr[0])
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::vector<char> CFileSystem::string2Vector(std::string &str)
{
    std::vector<char> vector_char(str.c_str(), str.c_str() + str.size() + 1);
    return vector_char;
}

/***********************************************************************************
Function:     fileExists
Description:  fileExists
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CFileSystem::fileExists(std::string &file_path)
{
	return 0 == access(file_path.c_str(), 0x00 ); // 0x00 = Check for existence only!
}

/***********************************************************************************
Function:     saveProtobufConfig
Description:  saveProtobufConfig
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CFileSystem::saveProtobufConfig(std::string &file_path, std::string &context)
{
    ofstream  fout;
    fout.open(file_path, ios::out | ios_base::ate);
    if(!fout.is_open())
    {
        std::cout << "[CFileSystem] open fail "  << file_path << std::endl;
        return -1;
    }
    fout << context << std::endl;
    fout.flush();
    fout.close();
    return 0;
}

/***********************************************************************************
Function:
Description:  readProtobufConfig
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CFileSystem::readProtobufConfig(std::string &file_path, google::protobuf::Message *message)
{
    int fd = open(file_path.c_str(), O_RDONLY);
    if(fd < -1)
    {
        std::cout << "[CFileSystem] open fail "  << file_path << std::endl;
        return -1;
    }
    google::protobuf::io::FileInputStream file_input(fd);
    file_input.SetCloseOnDelete(true);
    if(!google::protobuf::TextFormat::Parse(&file_input, message))
    {
        return -2;
    }

    return 0;
}


#include <everest/base/CRSThread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

CRSThread::CRSThread()
{
     m_bool = true;

}

CRSThread::~CRSThread()
{
        //dtor
    //
}

int CRSThread::start()
{
    if(pthread_create(&pid, NULL, start_thread, (void *)this) != 0)
    {
        return -1;
    }

    return 0;
}

void CRSThread::stop()
{
    m_bool = false;
    pthread_join(pid,NULL);
}

void *CRSThread::start_thread(void *arg)
{
        CRSThread *ptr = (CRSThread *)arg;
        ptr->run();
        return NULL;
}
int CRSThread::ThreadGetID(void)
{
	//return pthread_self();
	return syscall(__NR_gettid);
}



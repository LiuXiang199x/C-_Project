/*************************************************************************
	> File Name: CGpioControl.cpp
	> Author:
	> Mail:
	> Created Time: 2017年07月21日 星期五 19时12分33秒
 ************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <everest/base/CGpioControl.h>
#include <everest/base/CLog.h>

/*
PA 0*32
PB 1*32
PC 2*32
PD 3*32
PE 4*32
PF 5*32
PG 6*32
PH 7*32

PH09 233
*/


CGpioControl::CGpioControl()
{
    m_pin = -1;
}

CGpioControl::CGpioControl(int pin, int type,int value)
{
    m_pin = pin;
    GpioExport(pin);
    GpioSetDirection(pin,type);
    GpioWrite(value);
}

CGpioControl::~CGpioControl()
{
    if(m_pin)
        GpioUnexport(m_pin);
}

bool CGpioControl::GpioExport(int pin)
{
    char buffer[64];
    int len;
    int fd;
    fd = open("/sys/class/gpio/export", O_WRONLY);
    if (fd < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to open export for writing!\n");
        return false;
    }

    len = snprintf(buffer, sizeof(buffer), "%d", pin);
    if (write(fd, buffer, len) < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to export gpio!");
        return false;
    }
    close(fd);
    return true;
}

bool CGpioControl::GpioUnexport(int pin)
{
    char buffer[64];
    int len;
    int fd;

    fd = open("/sys/class/gpio/unexport", O_WRONLY);
    if (fd < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to open unexport for writing!\n");
        return false;
    }

    len = snprintf(buffer, sizeof(buffer), "%d", pin);
    if (write(fd, buffer, len) < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to unexport gpio!");
        return false;
    }
    close(fd);
    return true;
}

//dir: 0-->IN, 1-->OUT

bool CGpioControl::GpioSetDirection(int pin, int dir)
{
    static const char dir_str[] = "in\0out";
    char path[64];
    int fd;
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", pin);
    fd = open(path, O_WRONLY);
    if (fd < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to open gpio direction for writing!\n");
        return false;
	}

    if (write(fd, &dir_str[dir == 0 ? 0 : 3], dir == 0 ? 2 : 3) < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to set direction!\n");
        return false;
    }
    close(fd);
    return true;
}


//value: 0-->LOW, 1-->HIGH
bool CGpioControl::GpioWrite(int value)
{
    static const char values_str[] = "01";
    char path[64];
    int fd;
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", m_pin);
    fd = open(path, O_WRONLY);
    if (fd < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to open gpio value for writing!\n");
        return false;
   }

    if (write(fd, &values_str[value == 0 ? 0 : 1], 1) < 0) {
        CLog::log(LogGareth, LogNormal,"Failed to write value!\n");
        return false;
    }
    close(fd);
    return true;
}

bool CGpioControl::GpioInit(int pin, int type,int value)
{
    bool sucess = false;
    m_pin = pin;
    sucess = GpioExport(m_pin);
    sucess = GpioSetDirection(m_pin,type);
    sucess = GpioWrite(value);
    return sucess;
}



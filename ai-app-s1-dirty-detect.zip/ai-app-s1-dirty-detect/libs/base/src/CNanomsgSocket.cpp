/**********************************************************************************
File name:	  CNanomsgSocket.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is the robot packet
Others:       None

History:
	1. Date: 2015-09-20
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/

/********************************** File includes *******************((************/
#include <everest/base/CNanomsgSocket.h>

/********************************** Current libs includes *************************/
#include <everest/base/CLog.h>

/********************************** System includes *******************************/
#include <string.h>
#include <stdio.h>
#include <iostream>
#include <nanomsg/nn.h>
#include <nanomsg/pair.h>

/********************************** Name space ************************************/
using namespace std;
using namespace everest;
using namespace everest::base;

/***********************************************************************************
Function:     CNanomsgSocket
Description:  The constructor of CNanomsgSocket
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CNanomsgSocket::CNanomsgSocket()
{
    m_socket_send = 0;
    m_socket_recv = 0;
    m_ip_send_path.clear();
    m_ip_recv_path.clear();
    m_dataCallback = NULL;
    memset(m_recvBuf,0x0,sizeof(m_recvBuf));
    m_recvLen =0;
    m_stat = MSG_HEAD;
}


/***********************************************************************************
Function:     CNanomsgSocket
Description:  The destructor of CNanomsgSocket
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CNanomsgSocket::~CNanomsgSocket()
{
    
}

/***********************************************************************************
Function:     Start
Description:  Start
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CNanomsgSocket::Start(std::string ip_send, std::string ip_receive, MsgCallBack call_back)
{
	SetCallback(call_back);
    m_ip_send_path = ip_send;
    m_ip_recv_path = ip_receive;

    if ((m_socket_send = nn_socket(AF_SP, NN_PAIR)) < 0)
    {
        printf("nn_socket fail %d\n", m_socket_send);
        return -1;
    }
    CLog::log(LogKimbo, LogNormal, "[CNanomsgSocket] start connect ip successful %s!\n", ip_send.c_str());
	if (nn_connect(m_socket_send, ip_send.c_str()) < 0)
    {
        printf("nn_bind fail %d\n", m_socket_send);
        return -1;
    }

	if ((m_socket_recv = nn_socket(AF_SP, NN_PAIR)) < 0)
    {
        printf("nn_socket  g_socket_recv fail %d\n", m_socket_recv);
        return -1;
    }

	if (nn_bind(m_socket_recv, ip_receive.c_str()) < 0)
    {
        printf("nn_bind m_socket_recv fail %d\n", m_socket_recv);
        return -1;
    }
    CLog::log(LogKimbo, LogNormal, "[CNanomsgSocket] start build ip successful %s!\n", ip_receive.c_str());

	start();

    return 0;
}

/***********************************************************************************
Function:     send
Description:  send
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CNanomsgSocket::Send(int cmd, int len, char *buf, int did, uint64_t serialno)
{
    if(m_socket_send < 0)
    {
        printf("m_socket_send is 0");
        return -1;
    }

	if (((0 == len) && (NULL != buf)) ||  ((NULL == buf) && (0 != len)))
	{
        printf("len is 0 or buf is NULL");
        return -1;   
    }

    CMsgHead msg;
    msg.head_mark = IS_MSG_HEAD;
    msg.cmd = cmd;
    msg.len = len;
    msg.did = did;
    msg.serialno = serialno;
    msg.buf = NULL;

    /* Copy msg to buffer */
    std::vector<char> send_buffer;
    send_buffer.resize(sizeof(msg) + len);

    int index = 0;
    memcpy(&send_buffer[index], &msg, sizeof(msg)); 
    index += sizeof(msg);
    memcpy(&send_buffer[index], buf,  len); 
    index += len;

    /* send buffer */
    int ret = nn_send(m_socket_send, &send_buffer[0], send_buffer.size(), NN_DONTWAIT);

    return ret;
}

/***********************************************************************************
Function:     Send
Description:  Send
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CNanomsgSocket::run()
{
    while(m_bool)
    {
        char *ptk = NULL;

        int recv_bytes = nn_recv(m_socket_recv, &ptk, NN_MSG, 0);
        if(recv_bytes > 0)
        {
            ReceiveLocalData(ptk, recv_bytes);
            nn_freemsg(ptk);
        }
        usleep(100);
    }
}


/*************************************************
  Function: ReceiveLocalData
  Description: Receive data from Local Net
  Input:
  Output:
  Return:
*************************************************/
int CNanomsgSocket::ReceiveLocalData(char *buf, int recv_len)
{
    int len = recv_len;
    memcpy(m_recvBuf + m_recvLen, buf, recv_len);
    {
        m_recvLen += len;
        len = m_recvLen - MSG_HEAD_LEN;

        while( ( m_stat==MSG_HEAD && len>=0 )  || ( m_stat==MSG_BODY  &&  len >= m_msgHead.len ))
        {
            if (m_stat==MSG_HEAD && len>=0)
            {
                memset(&m_msgHead,0x0,MSG_HEAD_LEN);
                memcpy(&m_msgHead,m_recvBuf,MSG_HEAD_LEN);

                if (m_msgHead.len > len)
                {
                    return 0;
                }
                else if(m_msgHead.len  > MAX_MSG_LEN)
                {
                    printf("[CommonClient]m_msgHead ----len(%d) is over max len\n", m_msgHead.len);
                    m_stat = MSG_ERR;
                    return -1;
                }

				if(m_msgHead.head_mark != IS_MSG_HEAD)
                {
                    m_stat = MSG_ERR;
                    printf("[CommonClient] m_msgHead ----head_mark(%x) is err,socet will close\n",m_msgHead.head_mark);
                    return -1;
                }
                m_stat = MSG_BODY;
            }

            if (m_stat==MSG_BODY && len>= m_msgHead.len )
            {
                CMsgHead * m_head;
                m_head = (CMsgHead *)malloc(sizeof(CMsgHead));
                if(m_head == NULL)
                {
                    return 0;
                }
                memset(m_head,0x0,sizeof(CMsgHead));
                memcpy(m_head,m_recvBuf,sizeof(CMsgHead));

                char *buf =NULL;
                buf = (char *)malloc(m_msgHead.len * sizeof(char)+1);
                if(buf==NULL)
                    return 0;

                memset(buf,0x0,m_msgHead.len +1);
                memcpy(buf,m_recvBuf + sizeof(CMsgHead),m_msgHead.len );
                m_head->buf = buf;
                m_head->len = m_msgHead.len;

                if(m_dataCallback)
                {
                    m_dataCallback(m_head);
                }

                int pkglen = m_msgHead.len+MSG_HEAD_LEN;
                memset(m_recvBuf, 0x0, pkglen);
                memset(&m_msgHead,0x0,MSG_HEAD_LEN);
                memcpy(m_recvBuf, m_recvBuf+pkglen, m_recvLen-pkglen);
                m_recvLen -= pkglen;
                len = m_recvLen - MSG_HEAD_LEN;
                m_stat = MSG_HEAD;
            }
        }
	}
	return 0;
}


/***********************************************************************************
Function:     Send
Description:  Send
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CNanomsgSocket::Stop()
{
    stop();
    nn_shutdown(m_socket_send, 0);
	nn_shutdown(m_socket_recv, 0);
}
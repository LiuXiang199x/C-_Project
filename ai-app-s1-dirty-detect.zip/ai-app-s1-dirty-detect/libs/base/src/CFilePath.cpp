/*********************************************************************************
File name:	 CFilePath.cpp
Author:		 Spencer Wu
Version: 	 V1.0.0
Date:		 2017-03-02
Description: File path manager, include config file path, log file path eg
Others:		 None
History:
	1.Date:
	Author:
	Modification:

*********************************************************************************/

/********************************** File includes *******************************/
#include <everest/base/CFilePath.h>
#include <everest/base/CFileSystem.h>


#include <fstream>

/*********************************** Name space *********************************/
using namespace std;
using namespace everest;
using namespace everest::base;

/********************************** Private macro *******************************/

/************************** Static variables initialize ***************************/
string CFilePath::m_log_config_file_path = "/userdata/config/log_config.ini";
string CFilePath::m_camera_parameters_config_file_path = "/tmp/config/camera_parameters_config.ini";
string CFilePath::m_class_min_score_config_file_path = "/tmp/config/class_min_score_config.ini";
string CFilePath::m_log_path_prefix = "/userdata/AI/";
string CFilePath::m_ai_image_path_prefix = "/tmp/AI/ai_collection_data/";

/*********************************************************************************
Function:	 CFilePath
Description: The constructor of file path class
Input:		 None
Output:		 None
Return:		 None
Others:		 None
*********************************************************************************/
CFilePath::CFilePath()
{

}

/*********************************************************************************
Function:	 ~CFilePath
Description: The destructor of file path class
Input:		 None
Output:		 None
Return:		 None
Others:		 None
*********************************************************************************/
CFilePath::~CFilePath()
{

}

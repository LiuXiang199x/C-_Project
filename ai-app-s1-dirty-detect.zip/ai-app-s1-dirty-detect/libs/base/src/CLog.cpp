/***********************************************************************************
File name:	  CLog.cpp
Author:       Kimbo
Version:      V1.5
Date:	 	  2016-4-8
Description:  Log system
Others:       None

History:
 1. Date:2016-2-23
	Author:Kimbo
	Modification: Add information and user name in log according to user choice
 1. Date:2016-4-8
	Author:Kimbo
	Modification: fix some bug
            (1).init() set level to class member
            (2).init() use 'printf' function to print infro, since log system
                do not finish init
 **********************************************************************************/

/********************************** File includes *********************************/
#include "everest/base/CLog.h"

/********************************** Current libs includes *************************/
#include "everest/base/CLogUtitls.h"
#include "everest/base/CTime.h"

/******************************* System libs includes *****************************/
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#include <fstream>
#include <iostream>
#include <stdlib.h>

/******************************* Other libs includes *****************************/

/************************************ Defines *************************************/
#define SYSTEM_PERFIX_PATH          "/mnt/UDISK/config/system_perfix_number"

/************************* Static varible init*************************************/
FILE*           CLog::m_out_FP = NULL;
CLogConfig      CLog::m_option;
int             CLog::m_perfix_number = -1;
bool            CLog::m_create_thread_flag  = false;
pthread_t       CLog::m_log_thread;
CThreadSafeQueue<TLogMessage> CLog::m_queue;
std::string     CLog::m_log_level_string[3] = {"[LogErro]", "[LogWarn]", "[LogNormal]"};
std::string     CLog::m_log_user_string[13]  = {"[LogSpencer]", "[LogFandy]", "[LogYyang]",  "[LogKimbo]",
                                                "[logXia]",     "[LogKlaus]", "[LogGareth]", "[LogMeng]",
                                                "[LogShizhe]" , "[LogSara]",  "[LogEden]",   "[logMu]",
                                                "[LogAll]"};
pthread_mutex_t   CLog::m_cs;

/***********************************************************************************
Function:     init
Description:  Init log system
Input:        type: log type
              level: log level
              user: log user
              file_name: log save file name
              log_time: choice of log current time in log
              log_user: choice of log infromation user name in log
              log_level: choice of log infromation level in log
              also_print: also print information
              print_this_call: print configure information
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CLog::init(LogType type, LogLevel level,
                int user, std::string file_name,
                bool log_time,  bool log_user,
                bool log_level, bool also_print,
                bool add_to_file, bool diff_log,
                bool print_this_call)
{
    m_option.out_log_type = type;
    m_option.out_log_level = level;
    m_option.log_user_list = user;
    m_option.log_file_path = file_name;
    m_option.log_time_string = log_time;
    m_option.log_username_string = log_user;
    m_option.log_level_string = log_level;
    m_option.also_printf = also_print;
    m_option.add_to_logfile = add_to_file;
    m_option.different_log = diff_log;
    m_option.printf_this_call = print_this_call;

    init();

    return true;
}

/***********************************************************************************
Function:     init
Description:  Init log system
Input:        Log config
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CLog::init(CLogConfig &log_config)
{
    m_option = log_config;
    init();
    return true;
}

/***********************************************************************************
Function:     log
Description:  Log information
Input:        user: log user name
              level: log level
              str: log info(printf format)
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CLog::init()
{
    bool init_flag = false;
    {
        pthread_mutex_lock(&m_cs);

        init_flag = initUnlock();

        pthread_mutex_unlock(&m_cs);
    }
    return init_flag;
}

/***********************************************************************************
Function:     log
Description:  Log information
Input:        user: log user name
              level: log level
              str: log info(printf format)
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::log(LogUser user,LogLevel level, const char *str, ...)
{
    /* Judge if log it according to log level */
    if(level > m_option.out_log_level || m_option.out_log_type == LogNone)
    {
        return;
    }

    char buf[MAX_LOG_SIZE];
    int size = MAX_LOG_SIZE;

    char *bufPtr;
    std::string additional_string = "";
    {
        pthread_mutex_lock(&m_cs);

        /* Add time to log according to log time choice */
        if (buildAdditionalString(additional_string,user,level))
        {
            size -= additional_string.length();
            if (size <= 0)
            {
                std::cout << "[CLog] Critical Error: the additional string size overflow: " << additional_string.length() << std::endl;
                pthread_mutex_unlock(&m_cs);
		return;
            }
            strncpy(buf, additional_string.c_str(), additional_string.length());
            bufPtr = &buf[additional_string.length()];
        }
        else
        {
            bufPtr = buf;
        }

        /* Build buffer to log */
        va_list ptr;
        va_start(ptr, str);
        int cnt = vsnprintf(bufPtr, size, str, ptr);
        va_end(ptr);

        if(cnt < 0 || cnt >= size)
        {
            std::cout << "[CLog] Warning the input log size is out of range! " << additional_string << std::endl;
        }
        /* Log information according to out type */
        if(m_option.out_log_type == LogFile)
        {
            if(m_option.different_log)
            {
                fprintf(m_out_FP, "%s", buf);
                fflush(m_out_FP);
            }
            else
            {
                if(m_option.log_user_list & user)
                {
                    fprintf(m_out_FP, "%s", buf);
                    fflush(m_out_FP);
                }
            }
        }
        else if(m_option.out_log_type == LogStdOut)
        {
            printf("%s", buf);
            fflush(stdout);
        }
        else if (m_option.out_log_type == LogNone)
        {
            /* Do not log out anything */
        }

        /* Also printf according to user choice, user can log infomation to file and consle as the same time */
        if(m_option.out_log_type != LogStdOut && m_option.also_printf &&
           (m_option.log_user_list & user))
        {
            printf("%s", buf);
            fflush(stdout);
        }

        pthread_mutex_unlock(&m_cs);
    }
}



/***********************************************************************************
Function:     resetConfig
Description:  Reset log system config
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::resetConfig()
{
    close();

    CLogConfig option;
    m_option = option;
}

/***********************************************************************************
Function:     buildAdditionalString
Description:  Build additional string
Input:        str: additional string
              user: log user
              level: log level
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CLog::buildAdditionalString(std::string &str, LogUser user, LogLevel level)
{
    bool additional_flag = false;

    /* Add now time string in log according to user choice */
    if(m_option.log_time_string)
    {
        additional_flag = true;
        buildNowTimeString(str);
    }

    /* Add information user name in log according to user choice */
    if(m_option.log_username_string)
    {
        additional_flag = true;
        buildUserNameString(str,user);
    }

    /* Add information level in log according to user choice */
    if(m_option.log_level_string)
    {
        additional_flag = true;
        buildLogLevelSting(str,level);
    }

    return additional_flag;
}

/***********************************************************************************
Function:     close
Description:  Close log file system
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::close()
{
    if((m_out_FP != NULL) && (m_option.out_log_type == LogFile))
    {
        fclose(m_out_FP);
        m_out_FP = NULL;
    }
}

/***********************************************************************************
Function:     printfUserConfig
Description:  Printf user config
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::printfUserConfig()
{
    printf("CLog::init: ");

    /* Log out type */
    printf(" m_out_type: ");

    CLog::LogType out_type = (CLog::LogType)m_option.out_log_type;
    switch(out_type)
    {
        case LogStdOut: printf(" StdOut\t"); break;
        case LogFile: printf(" File(%s)\t", m_option.log_file_path.c_str()); break;
        case LogNone: printf(" None\t"); break;
        default: printf(" BadType\t"); break;
    }

    /* Log level */
    printf(" m_out_level: ");
    LogLevel out_level = (LogLevel)m_option.out_log_level;
    switch(out_level)
    {
        case LogWarn: printf(" LogWarn\t"); break;
        case LogErro: printf(" LogErro\t"); break;
        case LogNormal: printf(" LogNormal\t"); break;
        default: printf(" BadLevel\t"); break;
    }

    /* Log user name choice */
    if (m_option.log_username_string)
    {
        printf(" Logging User\t");
    }
    else
    {
        printf(" Not logging user\t");
    }

    /* Log time choice */
    if (m_option.log_time_string)
    {
        printf(" Logging Time\t");
    }
    else
    {
        printf(" Not logging time\t");
    }

    /* Also print choice */
    if (m_option.also_printf)
    {
        printf(" Also printing\n");
    }
    else
    {
        printf(" Not also printing\n");
    }
}

/***********************************************************************************
Function:     buildNowTimeString
Description:  Build now time string
Input:        str: now time string
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::buildNowTimeString(std::string &str)
{
    everest::base::TTimeStamp timestamp = everest::base::CTime::getRealTime();
    str = dateTimeLocalToString(timestamp);
}

/***********************************************************************************
Function:     buildUserNameString
Description:  Build user name string
Input:        str: user name string
              user: log user
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::buildUserNameString(std::string &str, LogUser user)
{
    int index = 0;
    switch(user)
    {
        case LogSpencer: index = 0; break;
        case LogFandy: index = 1; break;
        case LogYyang: index = 2; break;
        case LogKimbo: index = 3; break;
        case LogXia: index = 4; break;
        case LogKlaus: index = 5; break;
        case LogGareth: index = 6; break;
        case LogMeng: index = 7; break;
        case LogShizhe: index = 8; break;
        default: index = 9; break;
    }

    str += m_log_user_string[index];
}

/***********************************************************************************
Function:     buildLogLevelSting
Description:  Build log level sting
Input:        str: log level string
              lovel: enum type level
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::buildLogLevelSting(std::string &str, LogLevel level)
{
     str += m_log_level_string[level];
}

/***********************************************************************************
Function:     getLogFilePath
Description:  Get log file path
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CLog::getLogFilePath()
{
    return m_option.log_file_path;
}

/***********************************************************************************
Function:     cutDownLogFile
Description:  Cut down current log file, cut down current log file, and copy it to dest file path
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::cutDownLogFile(std::string &dest_file_path)
{
    pthread_mutex_lock(&m_cs);

    if((m_out_FP != NULL) && (m_option.out_log_type == LogFile))
    {
        /* Close file */
        fclose(m_out_FP);
        m_out_FP = NULL;

        /* Rename file */
        renameFile(m_option.log_file_path, dest_file_path);

        std::cout << "[CLog] Init unlock " << std::endl;
        /* Init file */
        initUnlock();
    }
    else
    {
        std::cout << "[CLog] You should open log file " << std::endl;
    }

    pthread_mutex_unlock(&m_cs);
}

/***********************************************************************************
Function:     logControl
Description:  Log control
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CLog::logControl()
{
    uint64_t file_size = getFileSize(m_option.log_file_path) / (uint64_t)1024;
    std::cout << "file_size " << file_size << " log_cut_down_size " << m_option.log_cut_down_size << std::endl;
    if(file_size > m_option.log_cut_down_size)
    {
        std::string file_name = renameFileExtension(m_option.log_file_name, "txt");
        int perfix = readLogSystemPerfix();
        file_name = evformat("%d_%s_%s", perfix, everest::base::CTime::getTimeString().c_str(), file_name.c_str());
        std::string file_path = std::string(LOG_DIRECTORY) + file_name;

        CLog::log(LogKimbo, LogNormal, "[CLog] Rename file log %s!\n", file_path.c_str());
        CLog::cutDownLogFile(file_path);
        CLog::log(LogKimbo, LogNormal, "[CLog] logControl has cut down!\n");
    }
}

/***********************************************************************************
Function:     initUnlock
Description:  Init unlock
Input:        user: log user name
              level: log level
              str: log info(printf format)
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CLog::initUnlock()
{
    if(!m_create_thread_flag)
    {
        m_create_thread_flag = true;
        if(pthread_create(&m_log_thread, NULL, asyncLogThread, NULL) != 0)
        {
            printf("CLog create thread\n");
            return -1;
        }
        pthread_detach(m_log_thread);
    }

    /* Close any old file */
    close();

    m_option.log_file_path = std::string(LOG_DIRECTORY) + m_option.log_file_name;

	/* Init log system */
    printf("CLog::init: file is %s for logging.\n",m_option.log_file_path.c_str());
    /* Log type initialize */
    if(m_option.out_log_type == LogStdOut)
    {
        m_out_FP = stdout;
    }
    else if(m_option.out_log_type == LogFile)
    {
        if(!m_option.add_to_logfile)
        {
            if ((m_out_FP = fopen(m_option.log_file_path.c_str(), "w")) == NULL)
            {
                printf("CLog::init: Could not open file %s for logging.\n",m_option.log_file_path.c_str());
                return false;
            }
            else
            {
                printf("CLog::init: Open file %s for logging.\n",m_option.log_file_path.c_str());
            }
        }
        else
        {
            if ((m_out_FP = fopen(m_option.log_file_path.c_str(), "a")) == NULL)
            {
                printf("CLog::init: Could not open file %s for logging.\n",m_option.log_file_path.c_str());
                return false;
            }
            else
            {
                printf("CLog::init: Open file %s for logging.\n",m_option.log_file_path.c_str());
            }
        }

    }

    /* Printf user config according to user config */
    if(m_option.printf_this_call)
    {
        printfUserConfig();
    }

    return true;
}

/***********************************************************************************
Function:     asyncLogThread
Description:  asyncLogThread
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void* CLog::asyncLogThread(void *arg)
{
    TLogMessage log_message;
    while(1)
    {
        m_queue.wait_and_pop(log_message);

        pthread_mutex_lock(&m_cs);

        /* Log information according to out type */
        if(m_option.out_log_type == LogFile)
        {
            if(m_option.different_log)
            {
                fprintf(m_out_FP, "%s", log_message.msg.c_str());
                fflush(m_out_FP);
            }
            else
            {
                if(m_option.log_user_list & log_message.user)
                {
                    fprintf(m_out_FP, "%s", log_message.msg.c_str());
                    fflush(m_out_FP);
                }
            }
        }
        else if(m_option.out_log_type == LogStdOut)
        {
            printf("%s", log_message.msg.c_str());
            fflush(stdout);
        }
        else if (m_option.out_log_type == LogNone)
        {
            /* Do not log out anything */
        }

        /* Also printf according to user choice, user can log infomation to file and consle as the same time */
        if(m_option.out_log_type != LogStdOut && m_option.also_printf &&
           (m_option.log_user_list & log_message.user))
        {
            printf("%s", log_message.msg.c_str());
            fflush(stdout);
        }

        pthread_mutex_unlock(&m_cs);
    }
}

/***********************************************************************************
Function:     readLogSystemPerfix
Description:  Read log system perfix
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CLog::readLogSystemPerfix()
{
    std::ifstream file(SYSTEM_PERFIX_PATH);
    int perfix_number = 0;
    if(file)
    {
        file >> perfix_number;
        file.close();
    }
    else
    {
        std::cout << "[CManagerInit] can not open log system perfix " << std::endl;
    }
    return perfix_number;
}

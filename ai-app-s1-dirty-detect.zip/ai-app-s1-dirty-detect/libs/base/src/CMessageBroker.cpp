/**********************************************************************************
File name:	  CCountDown.h
Author:       Shifeng
Version:      V1.6.2
Date:	 	  2016-10-10
Description:  File transfer protocol class
Others:       None

History:
	1. Date: 2016-10-27
	Author: Kimbo
	Modification: Change it from C language to C++ lanuage
***********************************************************************************/

/********************************** File includes *********************************/
#include "everest/base/CMessageBroker.h"

/******************************* Current libs includes ****************************/
#include <everest/base/CTime.h>
#include <everest/base/CFilePath.h>
#include <everest/base/CFileSystem.h>
#include <everest/base/CLog.h>

/******************************* System libs includes *****************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>

/******************************* Other libs includes ******************************/

/*********************************** Name space ***********************************/
using namespace std;
using namespace everest;
using namespace everest::base;
using namespace mrpt::utils;

/***********************************************************************************
Function:     CMessageBroker
Description:  The constructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CMessageBroker::CMessageBroker()
{

}

/***********************************************************************************
Function:     ~CMessageBroker
Description:  The destructor of ftp
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CMessageBroker::~CMessageBroker()
{

}

/***********************************************************************************
Function:     discharge
Description:  discharge to entity pending message list
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CMessageBroker::discharge(CBaseModule* pReceiver,const CTelegram& telegram)
{
    pReceiver->pushMessageToPendingList(telegram);
}

/***********************************************************************************
Function:     dispatchMessage
Description:  given a message, a receiver, a sender and any time delay , this function
              routes the message to the correct agent (if no delay) or stores
              in the message queue to be dispatched at the correct time
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CMessageBroker::dispatchMessage(int sender, int receiver,
                                         int channel, int event,
                                         mrpt::utils::CMessage *extra_info,
                                         double  delay)
{
    CBaseModule* pSender = this->getEntityFromID(sender);
    CBaseModule* pReceiver = this->getEntityFromID(receiver);


    if (pReceiver == NULL)
    {
        CLog::log(LogKimbo, LogErro,"CMessageBroker::dispatchMessage Erro! No Receiver with ID of %d\n", receiver);
        return;
    }

    if(pSender == NULL)
    {
        CLog::log(LogKimbo, LogErro,"CMessageBroker::dispatchMessage Erro! The Sender is not exist %d\n", sender);
        return;
    }

    if(extra_info == NULL)
    {
        CTelegram telegram(sender, receiver, channel, event);
        discharge(pReceiver, telegram);
    }
    else
    {
        CTelegram telegram(sender, receiver, channel, event, *extra_info, 0.0);
        discharge(pReceiver, telegram);
    }
}

/***********************************************************************************
Function:     getEntityFromID
Description:  get entity from ID
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CBaseModule* CMessageBroker::getEntityFromID(int id)
{
	TEntityMap::const_iterator ent = m_entityMap.find(id);

    if(ent != m_entityMap.end())
    {
        return ent->second;
    }
    else
    {
        return NULL;
    }
}

/***********************************************************************************
Function:     registerEntity
Description:  register entity, so every entity has a ID
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CMessageBroker::registerEntity(CBaseModule* newEntity)
{
	m_entityMap.insert(std::make_pair(newEntity->getID(), newEntity));
}



/*********************************************************************************
File name:	 CDeviceR16.cpp
Author:		 Spencer Wu
Version: 	 V1.0.0
Date:		 2017-03-02
Description: RK 3188 drivers, for getting CPU information such as ip, sn eg
Others:		 None
History:
	1.Date:
	Author:
	Modification:

*********************************************************************************/

/********************************** File includes *******************************/
#include <everest/base/CDeviceR16.h>

/******************************* Current libs includes **************************/

/******************************* Other libs includes ****************************/
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/route.h>
#include <signal.h>
#include <asm/types.h>
#include <linux/sockios.h>

/*********************************** Name space *********************************/
using namespace std;
using namespace everest;
using namespace everest::base;

/********************************* Private macros ********************************/
#define  SN_PATH "/mnt/SNN/ULI/factory/snum.txt"
#define  SSID_PATH "/mnt/SNN/ULI/factory/ssid.txt"
#define  DEFUALT_SSID_PATH  "3ifactory-test"

/*********************************************************************************
Function:	 CDeviceR16
Description: The constructor of device rk3188 class
Input:		 None
Output:		 None
Return:		 None
Others:		 None
*********************************************************************************/
CDeviceR16::CDeviceR16():
               m_sn_length_offset(0),
               m_mac_length_offset(505),
               m_sn_sector_op_tag(0x41444E53),
               m_storage_data_length(512)
{

}

/*********************************************************************************
Function:	 ~CDeviceR16
Description: The destructor of device rk3188 class
Input:		 None
Output:		 None
Return:		 None
Others:		 None
*********************************************************************************/
CDeviceR16::~CDeviceR16()
{

}

/*********************************************************************************
Function:	 getSN
Description: Get SN form rk3188
Input:		 length: max read size
Output:		 None
Return:		 SN
Others:		 None
*********************************************************************************/
std::string CDeviceR16::getSN(int length)
{

	char buf_temp[32] = {0};
	std::string  devSn;

    if(access(SN_PATH,F_OK) == 0)
    {
        FILE * fp = NULL;
        fp = fopen(SN_PATH,"r");
        if(fp)
        {
            int nread = fread(buf_temp,1,sizeof(buf_temp),fp);
            if(nread > 0)
            {
                devSn.append(buf_temp,nread);
            }
            fclose(fp);
        }
    }
    return devSn;
}

/*********************************************************************************
Function:	 getSN
Description: Get SN form rk3188
Input:		 length: max read size
Output:		 buf: SN
Return:		 0: success, -1: fail
Others:		 None
*********************************************************************************/
int CDeviceR16::getSN(char *buf, int length)
{
    if(buf == NULL)
    {
        return -1;
    }

	int buf_temp_length = 0;
	char buf_temp[32] = {0};

    int nread = 0;
    if(access(SN_PATH,F_OK) == 0)
    {
        FILE * fp = NULL;
        fp = fopen(SN_PATH,"r");
        if(fp)
        {
            nread = fread(buf_temp,1,sizeof(buf_temp),fp);
            if(nread)
                strncpy(buf, buf_temp,(nread >= length) ? length : nread);
            fclose(fp);
        }
        else
            return -1;
    }

    return 0;
}

/*********************************************************************************
Function:	 getTestWifiSsid
Description: Get wlan ssid form rk3188
Input:		 length: max read size
Output:		 buf: ssid
Return:		 0: success, -1: input error, -2: file open fail, -3: file close fail
Others:		 None
*********************************************************************************/
std::string CDeviceR16::getTestWifiSsid(int length)
{
	char buf_temp[32] = {0};
	std::string  test_wlan_ssid;

    if(access(SSID_PATH,F_OK) == 0)
    {
        FILE * fp = NULL;
        fp = fopen(SSID_PATH,"r");
        if(fp)
        {
            int nread = fread(buf_temp,1,sizeof(buf_temp),fp);
            if(nread > 0)
            {
                test_wlan_ssid.append(buf_temp,nread);
            }
            fclose(fp);
        }
    }

    if(test_wlan_ssid.empty())
    {
        test_wlan_ssid = std::string(DEFUALT_SSID_PATH);
    }
    return test_wlan_ssid;
}

/*********************************************************************************
Function:	 getWlanSSID
Description: Get wlan ssid form rk3188
Input:		 length: max read size
Output:		 buf: ssid
Return:		 0: success, -1: input error, -2: file open fail, -3: file close fail
Others:		 None
*********************************************************************************/
int CDeviceR16::getWlanSSID(char *buf, int length)
{
	if(buf == NULL || length < 0)
	{
		// Print error information to log
		return -1;
	}

	memcpy(buf,"3irobotics-admin2",strlen("3irobotics-admin2"));

	buf[strlen(buf)] ='\0';
	return 0;
}

/*********************************************************************************
Function:	 getLocalIP
Description: Get local ip form rk3188
Input:		 name: name of network
			 length: max read size
Output:		 ip_address: device ip adderess
Return:		 0: success, -1: fail
Others:		 None
*********************************************************************************/
int CDeviceR16::getLocalIP(const char *name, char *ip_address, int length)
{
	if(ip_address == NULL || length < 16)
	{
		// Print error information to log
		return -1;
	}

	int sock_get_ip = socket(AF_INET, SOCK_STREAM, 0);
	if(sock_get_ip == -1)
	{
		// Print error information to log
		return -1;
	}

	struct ifreq ifr_ip;
	memset(&ifr_ip, 0, sizeof(ifr_ip));
	strncpy(ifr_ip.ifr_name, name, IFNAMSIZ - 1);

    if(ioctl(sock_get_ip, SIOCGIFADDR, &ifr_ip) < 0)
    {
        if(sock_get_ip)
        {
			close(sock_get_ip);
		}
        return -1;
    }

	struct sockaddr_in *sin = (struct sockaddr_in *)(&ifr_ip.ifr_addr);
    strcpy(ip_address, inet_ntoa(sin->sin_addr));

	if(sock_get_ip)
	{
		close( sock_get_ip );
	}
	return 0;
}

/*********************************************************************************
Function:	 getLocalMac
Description: Get local mac form rk3188
Input:		 name: name of network
			 length: max read size
Output:		 mac_address: device mac adderess
Return:		 0: success, -1: fail
Others:		 None
*********************************************************************************/
std::string CDeviceR16::getLocalMac(const char *name, int length)
{
	if(length < 17)
	{
		// Print error information to log
		return "\0";
	}

	int sock = socket(AF_INET,SOCK_STREAM,0);
	if(sock < 0)
	{
		// Print error information to log
		return "\0";
	}

	struct ifreq ifreq;
	strcpy(ifreq.ifr_name, name);
	if(ioctl(sock, SIOCGIFHWADDR, &ifreq) < 0)
	{
		// Print error information to log
		close(sock);
		return "\0";
	}

    char mac_address[32] = {0};
    sprintf(mac_address,"%02x:%02x:%02x:%02x:%02x:%02x",
           (unsigned char)ifreq.ifr_hwaddr.sa_data[0],
           (unsigned char)ifreq.ifr_hwaddr.sa_data[1],
           (unsigned char)ifreq.ifr_hwaddr.sa_data[2],
           (unsigned char)ifreq.ifr_hwaddr.sa_data[3],
           (unsigned char)ifreq.ifr_hwaddr.sa_data[4],
           (unsigned char)ifreq.ifr_hwaddr.sa_data[5]);

	close(sock);
	return (std::string)(mac_address);
}




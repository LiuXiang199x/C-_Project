/**********************************************************************************
File name:	  CBaseModule.cpp
Author:       Kimbo
Version:      V1.5
Date:	 	  2016-2-22
Description:  Entiy base class
Others:       None
History:
    1. Date:2015-9-9
    Author:Kimbo
    Modification: (1).Change CBaseModule name to CBaseModule
                  (2).Remove the function which judge the ID must greater than next ID,
                      because there is have entity ID table to manger it
    2. Date:2016-2-22
    Author:Kimbo
    Modification: Refactoring it
 **********************************************************************************/

/******************************* File includes ************************************/
#include "everest/base/CBaseModule.h"

/********************************** Name space ************************************/
using namespace everest;
using namespace everest::base;

/***********************************************************************************
Function:     CBaseModule
Description:  Constructor
Input:        id: entity id
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CBaseModule::CBaseModule(int id)
{
	setID(id);
	m_pending_message_list.clear();
	m_pending_messsage_max_size = 1000;
}

/***********************************************************************************
Function:     ~CBaseModule
Description:  Destructor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CBaseModule::~CBaseModule()
{
    m_pending_message_list.clear();
}

/***********************************************************************************
Function:     setID
Description:  Set base entity id
Input:        value: entity ID
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CBaseModule::setID(const int value)
{
	m_ID = value;
}

/***********************************************************************************
Function:     getID
Description:  Get base entity ID
Input:        None
Output:       None
Return:       entity ID
Others:       None
***********************************************************************************/
int CBaseModule::getID() const
{
    return m_ID;
}

/***********************************************************************************
Function:     handleMessage
Description:  Entity handle message
Input:        None
Output:       None
Return:       true: success to handle this message
              false: failed to handle this message
Others:       None
***********************************************************************************/
bool CBaseModule::handleMessage(const CTelegram& telegram)
{
    return false;
}

/***********************************************************************************
Function:     initialize
Description:  Entity initialize function
Input:        None
Output:       None
Return:       true: initialize succesful
              false: initialize failed
Others:       None
***********************************************************************************/
bool CBaseModule::initialize()
{
    return true;
}

/***********************************************************************************
Function:     close
Description:  Entity close function
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CBaseModule::close()
{

}

/***********************************************************************************
Function:     update
Description:  Entity update function
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CBaseModule::update()
{

}

/***********************************************************************************
Function:     getPendingMessageListSize
Description:  Get size of pending message list
Input:        None
Output:       None
Return:       Size of pending message list
Others:       None
***********************************************************************************/
unsigned int CBaseModule::getPendingMessageListSize()
{
    std::lock_guard<std::mutex> lock(m_pending_message_cs);
    //std::lock_guard<std::mutex> tmp_lock(this->kf_mutex);

    return m_pending_message_list.size();
}

/***********************************************************************************
Function:     pushMessageToPendingList
Description:  Push pending message to list
Input:        telegram: telegram to handle
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CBaseModule::pushMessageToPendingList(const CTelegram& telegram)
{
    std::lock_guard<std::mutex> lock(m_pending_message_cs);

    m_pending_message_list.push_back(telegram);

    if(m_pending_message_list.size() > m_pending_messsage_max_size)
    {
        m_pending_message_list.pop_front();
    }
}

/***********************************************************************************
Function:     getPendingMessageList
Description:  Get all pending message list, and clear it
Input:        None
Output:       None
Return:       Deque of pending message list
Others:       None
***********************************************************************************/
std::deque<CTelegram> CBaseModule::getPendingMessageList()
{
    std::deque<CTelegram> pending_message_list;
    {
        std::lock_guard<std::mutex> lock(m_pending_message_cs);

        pending_message_list = m_pending_message_list;

        m_pending_message_list.clear();
    }
    return pending_message_list;
}

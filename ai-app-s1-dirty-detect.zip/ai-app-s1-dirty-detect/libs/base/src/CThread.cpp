#include <everest/base/CThread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/prctl.h>
#include <iostream>

CThread::CThread()
{
    m_bool = true;
}

CThread::~CThread()
{

}

int CThread::start()
{
    if(pthread_create(&pid, NULL, start_thread, (void *)this) != 0)
    {
        return -1;
    }
    pthread_detach(pid);
    return 0;
}

void CThread::stop()
{
    m_bool = false;
}

int CThread::ThreadGetID(void)
{
	return syscall(__NR_gettid);
}

void *CThread::start_thread(void *arg)
{
    CThread *ptr = (CThread *)arg;
    ptr->run();
    return NULL;
}




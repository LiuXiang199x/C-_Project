/***********************************************************************************
File name:	  CLogConfig.cpp
Author:       kibmo
Version:      V1.5
Date:	 	  2016-4-7
Description:  Log system config
Others:       None

History:
 1. Date:
	Author:
	Modification:
************************************************************************************/

/********************************** File includes *********************************/
#include <everest/base/CLogConfig.h>

/********************************** Current libs includes *************************/
#include <everest/base/CLog.h>

/********************************** Other libs includes ***************************/


/********************************** Name space ************************************/
using namespace std;


/***********************************************************************************
Function:     CLogConfig
Description:  Construcotr
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CLogConfig::CLogConfig()
{
    log_file_path = "./app_logfile.txt";
    auto_build_directory = false;
    create_log_name_auto = false;
    log_time_string = true;
    log_module_string = true;
    log_username_string = true;
    log_level_string = true;
    also_printf = true;
    printf_this_call = true;
    add_to_logfile = false;
    different_log = true;
    out_log_level = LogNormal;
#ifdef EVEREST_R16_PLATFORM
    out_log_type  = CLog::LogFile;
#elif EVEREST_RK_PLATFORM
    out_log_type  = CLog::LogFile;
#else
    out_log_type  = CLog::LogStdOut;
#endif
    log_user_list  = LogAll;
    log_cut_down_size = 5 * 1024;
}

/*********************************************************************************
File name:	  CTelegram.cpp
Author:       Kimbo
Version:      V1.5
Date:	 	  2016-2-20
Description:  This defines a telegram. A telegram is a data structure that
              records information required to dispatch messages. Messages
              are used by game agents to communicate with each other
Others:       None

History:
1.  Date:
    Author:
    Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/base/CTelegram.h>

/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::base;

/***********************************************************************************
Function:     CTelegram
Description:  Constructor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTelegram::CTelegram():
           m_sender(-1),
           m_receiver(-1),
           m_channel(-1),
           m_event(-1)
{

}

/***********************************************************************************
Function:     CTelegram
Description:  Constructor
Input:        sender: telegram sender
              receiver: telegram receiver
              channel: telegram channel
              event: telegram event
              info: telegram extra information
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTelegram::CTelegram(const int sender, const int receiver,
                     const int channel, const int event,
                     const mrpt::utils::CMessage &info,
                     const double time)
{
    setSender(sender);
    setReceiver(receiver);
    setChannel(channel);
    setEvent(event);
    setExtraInforamtion(info);
}

/***********************************************************************************
Function:     CTelegram
Description:  Constructor
Input:        sender: telegram sender
              receiver: telegram receiver
              channel: telegram channel
              event: telegram event
              info: telegram extra information
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTelegram::CTelegram(const int sender, const int receiver,
                     const int channel, const int event,
                     const double time)
{
    setSender(sender);
    setReceiver(receiver);
    setChannel(channel);
    setEvent(event);

    mrpt::utils::CMessage info;
    setExtraInforamtion(info);
}

/***********************************************************************************
Function:     ~CTelegram
Description:  Destructor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTelegram::~CTelegram()
{

}

/***********************************************************************************
Function:     isEqual
Description:  Return true if two telegram equal,but not compare extra information
Input:        telegram: compared telegram
Output:       None
Return:       true: equal
              false: not equal
Others:       None
***********************************************************************************/
bool CTelegram::isEqual(const CTelegram &telegram) const
{
    if(getSender() == telegram.getSender() &&
       getReceiver() == telegram.getReceiver() &&
       getChannel() == telegram.getChannel() &&
       getEvent() == telegram.getEvent())
    {
        return true;
    }
    else
    {
        return false;
    }
}




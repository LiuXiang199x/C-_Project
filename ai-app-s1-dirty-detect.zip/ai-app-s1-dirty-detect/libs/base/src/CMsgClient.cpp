#include <sys/time.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "everest/base/CMsgClient.h"


#define MAX_SEND_LEN   64*1024


CMsgClient::CMsgClient()
{
	pthread_mutex_init(&m_lock,NULL);
	memset(m_path,0x0,sizeof(m_path));
}

CMsgClient::~CMsgClient( )
{
	pthread_mutex_destroy(&m_lock);
}


/*************************************************
  Function: run
  Description:
  Input��
  Output:
  Return:
*************************************************/
void CMsgClient::run()
{
	fd_set readfd;
	struct timeval wait_time;
	int max_fd;
    int nready = -1;
	int ret = -1;

	int thread_id = ThreadGetID();
    printf("[CMsgClient] Thread_ID = (%d) ############## \n", thread_id);


	wait_time.tv_sec =	1;
	wait_time.tv_usec = 200*1000;

	Connect(m_path);

	while(m_bool)
	{
		wait_time.tv_sec =	0;
		wait_time.tv_usec = 500*1000;

        pthread_mutex_lock(&m_lock);
        FD_ZERO(&readfd);
        if(m_fd < 0)
        {
            m_fd = Connect(m_path);
            if(m_fd <0)
            {
                printf( "[CMsgClient] Connect path =%s fail \n", m_path);
                pthread_mutex_unlock(&m_lock);
                sleep(2);
                continue;
            }
            else
            {
                FD_SET(m_fd, &readfd);
                max_fd = m_fd+1;
            }
        }
        else
        {
            FD_SET(m_fd, &readfd);
            max_fd = m_fd+1;
        }
        pthread_mutex_unlock(&m_lock);

		nready = select(max_fd, &readfd, NULL, NULL, &wait_time);
		if(nready < 0)
		{
            printf("[CMsgClient] select failed, err=%s\n", strerror(errno));
			usleep(200*1000);
			continue;
		}
		else if(nready == 0)
		{
			usleep(10*1000);
			continue;
		}
		else
		{
			if(FD_ISSET(m_fd,&readfd))
			{
				pthread_mutex_lock(&m_lock);
				ret = ReceiveLocalData();
				if(ret < 0)
                {
                    Close();
                }
			    pthread_mutex_unlock(&m_lock);
			}

		}
	}
    Close();
}


int CMsgClient::Connect(char * path)
{
	int err;
	struct sockaddr_un addr_ser;
	m_fd=socket(AF_LOCAL,SOCK_STREAM,0);
	if(-1 == m_fd)
	{
        printf("[CMsgClient] create socket err \n");
		return -1;
	}

	bzero(&addr_ser,sizeof(addr_ser));
	addr_ser.sun_family=AF_LOCAL;
	strcpy(addr_ser.sun_path,path);

	int len = 1024*1024;
	if (-1 == setsockopt(m_fd, SOL_SOCKET, SO_RCVBUF, &len, (socklen_t)sizeof(len)))
    {
       printf("[CMsgClient] Error to set Msg Client sock Recv Buf!!!!\n");
        Close();
        return -1;
    }

    if (-1 == setsockopt(m_fd, SOL_SOCKET, SO_SNDBUF, &len, (socklen_t)sizeof(len)))
    {
        printf("[CMsgClient] Error to set Msg Client sock Send Buf!!!!\n");
        Close();
        return -1;
    }

    struct timeval timeout={1,0};//3s

    if (-1 == setsockopt(m_fd,SOL_SOCKET,SO_SNDTIMEO,(const char*)&timeout,sizeof(timeout)))
    {
        printf("[CMsgClient] Error to set Msg Client sock Send Buf!!!!\n");
        Close();
        return -1;
    }

    if (-1 == setsockopt(m_fd,SOL_SOCKET,SO_RCVTIMEO,(const char*)&timeout,sizeof(timeout)))
    {
        printf("[CMsgClient] Error to set Msg Client sock Send Buf!!!!\n");
        Close();
        return -1;
    }


	err = connect(m_fd,(struct sockaddr *)&addr_ser,sizeof(addr_ser));
	if(-1 == err)
	{
        printf("[CMsgClient] Connect::connect error:%s errno =%d errstr=%s\n",path,errno,strerror(errno));
        Close();
		return -1;
	}

    SetNonblocking(m_fd);
    m_stat = MSG_HEAD;
    return m_fd;
}

void CMsgClient::Start(MsgCallBack callback, const char * path)
{
	SetCallback(callback);
	memcpy(m_path,path,strlen(path));
	start();
}

void CMsgClient::Stop()
{
    stop();
}


int CMsgClient::Send(int cmd, int len,char *buf, int did, uint64_t serialno)
{
    printf( "cms lenght...%ld\n",len);
    pthread_mutex_lock(&m_lock);
    if(m_fd < 0)
    {
        printf( "[CMsgClient] should create socket\n");
        pthread_mutex_unlock(&m_lock);
        return -1;
    }
    // printf( "aaaaa---\n");
	if (((0 == len) && (NULL != buf)) ||
	  ((NULL == buf) && (0 != len)))
	{
       printf( "[CMsgClient] Send buffer len does not match with buf\n");
		pthread_mutex_unlock(&m_lock);
		return -1;
	}
    // printf( "aaaaa1111---\n");
    int ret =-1;
    CMsgHead msg;
    msg.head_mark = IS_MSG_HEAD;
    msg.cmd = cmd;
    msg.len = len;
    msg.did = did;
    msg.serialno = serialno;
    msg.buf = buf;
    ret = SendLocalData(&msg);
    // printf( "aaaaa2222---\n");
    if(ret<0)
    {
        printf("[CMsgClient] send msg err\n");
        Close();
        pthread_mutex_unlock(&m_lock);
        return -1;
    }
    pthread_mutex_unlock(&m_lock);
	return ret;
}




/*********************************************************************************
File name:	  CAiTest.h
Author:       Kimbo
Version:      V1.7.1
Date:	 	  2017-02-03
Description:  3irobotics lidar sdk
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

/********************************* File includes **********************************/
#include "everest/ai/CAiTest.h"

/******************************* Current libs includes ****************************/
#include "everest/base/CLog.h"

#include <iostream>
#include <string.h>

/********************************** Name space ************************************/
using namespace everest;
using namespace everest::ai;



/***********************************************************************************
Function:     CAiTest
Description:  The constructor of CAiTest
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CAiTest::CAiTest()
{

}

/***********************************************************************************
Function:     CAiTest
Description:  The destructor of CAiTest
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CAiTest::~CAiTest()
{

}

/***********************************************************************************
Function:     initilize
Description:  Set device connect
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CAiTest::initilize( )
{
    return true;
}

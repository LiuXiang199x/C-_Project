/*********************************************************************************
File name:	  CRobotAi.cpp
Author:       sara
Version:
Date:	 	  2018-04-10
Description:  ai common interface for call, the logic process class of ai.
Others:       None.
**********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CRobotAi.h>
#include <everest/ai/CTypeTransform.h>

#include <everest/base/CAIMessages.pb.h>
#include <everest/base/CEntityProtocol.h>
#include <everest/base/CLog.h>
#include <everest/base/CTime.h>
#include <everest/base/CLogUtitls.h>
#include <everest/ai/CImageTransform.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/vfs.h>
#include <everest/hwdrivers/CCameraSensor.h>
#include "opencv2/imgcodecs/legacy/constants_c.h"
#include <everest/ai/CAiParameters.h>
using namespace std;
using namespace everest;
using namespace everest::base;
using namespace everest::ai;

#define DEBUG_AI 1
#define DEBUG_ORI_DETECT_CLASS_IMAGE 0
#define TWICE_DETECT 0
#define MAX_FLOOR_BLANKET_PASS_TIME_PERIOD 60000

#if DEBUG_AI
CImageLog g_debug_image_log;
#endif

int g_saveIndex = 0;
int g_maxSaveNumber = 1;


inline bool exists (const std::string& name) {
    std::ifstream f(name.c_str());
    return f.good();
}


std::string g_outputVideoPath = "/userdata/tmp.avi";
cv::VideoWriter g_outputVideo;


static int shell_call(std::string &cmdstr) {
    //enum { maxline=100 };
    int maxline = 100;             //读取的shell命令最大长度
    char line[maxline];            //存储读取到的shell命令
    FILE *fpin;                    //文件控制指针

    //popen以只读方式创建管道
    if((fpin = popen(cmdstr.c_str(), "r")) == NULL)
    {
        printf("popen error\n");
        exit(-1);
    }

    while(true)
    {
        //向控制台输出字符信息，stdout为标准输出流
        fputs("prompt> ", stdout);
        // fflush(stdout);          //显示输出缓冲区信息并清空输出缓冲区

        //从文件流中读取信息到line中
        if(fgets(line, sizeof(line), fpin) == NULL) /*read from pipe*/
            break;

        //将line中信息送入输出缓冲区显示
        if(fputs(line, stdout) == EOF)
        {
            printf("fputs error\n");
            exit(-1);
        }
    }

    //关闭shell执行管道
    int ret;
    if((ret = pclose(fpin)) == -1) {
        printf("pclose error\n");
        exit(-1);
    }

    return ret;
}



/***********************************************************************************
Function:     CRobotAi
Description:  The constructor of robot ai
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::CRobotAi() : m_current_ai_mode(AI_MODE_IDLE),
                       m_last_ai_mode(AI_MODE_IDLE),
                       m_current_detect_type(DETECT_TYPE_OBJECT),
                       m_last_image_time_stamp(INVALID_TIMESTAMP),
                       m_floor_widht_aspatia(0.665),
                       m_floor_height_aspatia(0.341),
                       m_image_log(NULL)
{
    // m_floor_widht_aspatia:0.716,m_floor_height_aspatia:0.276,
    // m_floor_widht_aspatia:0.665,m_floor_height_aspatia:0.341,
    registerInitializeFunction();
    registerUpdateFunction();
    m_obj_detect_i = 0;
    m_total_detect_count = 0;
    m_object_detect_count = 0;
    m_floor_detect_count = 0;
    m_obj_detect_total_time = 0;
    m_result_object.clear();

    m_obj_detect_one_index = 0;
    m_obj_detect_two_index = 0;
    m_obj_detect_one_total_time = 0;
    m_obj_detect_two_total_time = 0;
    m_calib_img_count = 0;
    m_upload_server_image_frequent = 30;
    m_last_upload_image_time_stamp = 1;
    m_detect_obj_num_limit = 5;

    m_last_upload_image = cv::Mat();
    m_last_upload_detect_image = cv::Mat();
    m_last_cover_detect_image = cv::Mat();
    m_upload_image_different_count_limit = 8;
    m_upload_detect_image_different_count_limit = 8;
    m_upload_detect_floor_count_limit = 5;
    m_upload_detect_floor_count = 0;
    m_last_upload_detect_obj_class = AI_OBJECT_NOTHING;
    m_upload_detect_obj_count = 0;
    m_upload_detect_obj_count_limit = 2;

    m_is_camera_covered = false;
    m_camera_cover_frame_count = 0;
    m_serias_detect_obj_count = 0;
    m_total_detect_box_count = 0;
    m_check_camera_cover_count = 0;
    m_last_detect_object_blanket_time = INVALID_TIMESTAMP;
}

/***********************************************************************************
Function:     CRobotAi
Description:  The destructor of robot ai
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::~CRobotAi()
{
    m_result_object.clear();

    if (m_image_log != NULL)
    {
        free(m_image_log);
    }
}

/***********************************************************************************
Function:     setRobotAIMode
Description:  Set robot ai mode
Input:        mode: ai mode
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::setRobotAIMode(TAiMode mode)
{
    if (m_last_ai_mode == mode)
        return;

    if (m_current_ai_mode == base::AI_MODE_CAMERA_CALIBRATION && mode == base::AI_MODE_IDLE)
    {
        return;
    }

    m_current_ai_mode = mode;
    m_last_ai_mode = mode;

    CLog::log(LogKimbo, LogNormal, "[CRobotAi] set ai mode %d!\n", m_current_ai_mode);

    (this->*mode_initialize_process[m_current_ai_mode])();
}

/***********************************************************************************
Function:     update
Description:  Robot ai normal update
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::update(CImage &image)
{
    m_current_image = image;

    cv::Mat image1 = m_current_image.getOriginImage();

    if (m_last_image_time_stamp == m_current_image.getTimeStamp())
    {
        m_last_image_time_stamp = m_current_image.getTimeStamp();
        return false;
    }
    else
    {
        m_last_image_time_stamp = m_current_image.getTimeStamp();
        (this->*mode_update_process[m_current_ai_mode])();
    }
    return true;
}

/***********************************************************************************
Function:     registerInitializeFunction
Description:  Register function
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::registerInitializeFunction()
{
    mode_initialize_process[AI_MODE_IDLE] = &CRobotAi::processIdleModeInitialize;
    mode_initialize_process[AI_MODE_LOCAL_DATA_COLLECTION] = &CRobotAi::processDataCollectionModeInitialize;
    mode_initialize_process[AI_MODE_SERVER_DATA_COLLECTION] = &CRobotAi::processServerDataCollectionModeInitialize;
    mode_initialize_process[AI_MODE_DETECTION] = &CRobotAi::processDetectionModeInitialize;
    mode_initialize_process[AI_MODE_CAMERA_CALIBRATION] = &CRobotAi::processCameraCalibModeInitialize;
    mode_initialize_process[AI_MODE_OUT_FAMILY_TEST] = &CRobotAi::processOutFamilyTestModeInitialize;
}

/***********************************************************************************
Function:     registerUpdateFunction
Description:  Register function
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::registerUpdateFunction()
{
    mode_update_process[AI_MODE_IDLE] = &CRobotAi::processIdleModeUpdate;
    mode_update_process[AI_MODE_LOCAL_DATA_COLLECTION] = &CRobotAi::processDataCollectionModeUpdate;
    mode_update_process[AI_MODE_SERVER_DATA_COLLECTION] = &CRobotAi::processServerDataCollectionModeUpdate;
    mode_update_process[AI_MODE_DETECTION] = &CRobotAi::processDetectionModeUpdate;
    mode_update_process[AI_MODE_CAMERA_CALIBRATION] = &CRobotAi::processCameraCalibModeUpdate;
    mode_update_process[AI_MODE_OUT_FAMILY_TEST] = &CRobotAi::processOutFamilyTestModeUpdate;
}

/***********************************************************************************
Function:     processIdleModeInitialize
Description:  processIdleModeInitialize
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processIdleModeInitialize()
{
    clearDetectResult();
}

/***********************************************************************************
Function:     processOutFamilyTestModeInitialize
Description:  processOutFamilyTestModeInitialize
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processOutFamilyTestModeInitialize()
{
    clearDetectResult();
    cv::Mat em;
    m_upload_server_image.setOriginImage(em);
    initDataCollectionFrequent();
    CAiParameters m_ai_parameter;
    m_detect_obj_num_limit = m_ai_parameter.getObjDetectNumLimit();
    m_upload_detect_floor_count_limit = m_ai_parameter.getServerDataCollectionFloorFrequt();
    m_upload_detect_obj_count_limit = m_ai_parameter.getServerDataCollectionObjectFrequt();
    m_upload_image_different_count_limit = m_ai_parameter.getImageUploadDifferenceLimitCount();
    m_upload_detect_image_different_count_limit = m_ai_parameter.getImageUploadDifferenceLimitCount();
    m_need_upload_detect_imgage = true;
}

/***********************************************************************************
Function:     processDataCollectionModeInitialize
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processDataCollectionModeInitialize()
{
    if (m_image_log == NULL)
    {
        m_image_log = new CImageLog();
    }
}

/***********************************************************************************
Function:     processServerDataCollectionModeInitialize
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processServerDataCollectionModeInitialize()
{
    cv::Mat em;
    m_upload_server_image.setOriginImage(em);
    initDataCollectionFrequent();
}
/***********************************************************************************
Function:     processCameraCalibModeInitialize
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processCameraCalibModeInitialize()
{
    m_camera_calib_result.calib_flag = 0;
}

/***********************************************************************************
Function:     processDetectionModeInitialize
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processDetectionModeInitialize()
{
    m_current_detect_type = DETECT_TYPE_OBJECT;
}

/***********************************************************************************
Function:     processIdleModeUpdate
Description:  Robot ai normal update
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processIdleModeUpdate()
{
    return true;
}

/***********************************************************************************
Function:     processDataCollectionModeUpdate
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processDataCollectionModeUpdate()
{
    cv::Mat image = m_current_image.getImage();
    m_image_log->saveCalibrationImage(image);

    systemSleep(2000);
    return true;
}

/***********************************************************************************
Function:     processServerDataCollectionModeUpdate
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processServerDataCollectionModeUpdate()
{
    // m_upload_server_image_frequent = 10;
    // systemSleep(m_upload_server_image_frequent*1000);
    // systemSleep(10);
    setUploadServerImage();
    return true;
}

/***********************************************************************************
Function:     processDataCollectionModeUpdate
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processCameraCalibModeUpdate()
{
    // cv::Mat image = m_current_image.getOriginImage();
    cv::Mat image = m_current_image.getImage();
    //---------
    cv::Mat src_img = image.clone();
    m_calib_img_count++;
    usleep(100 * 1000);
    if (m_calib_img_count == 15)
    {
        // cv::Mat m = cv::Mat::zeros(height, width, CV_32F);
        std::cout << "calib image timestamp......" << m_current_image.getTimeStamp() << std::endl;
        m_calib_img_count = 0;
        if (image.empty() || !imgIsValid(image))
        {
            m_camera_calib_result.camera_param_str = " ";
            m_camera_calib_result.result_code = 199;
            m_camera_calib_result.src_img = image;
            m_camera_calib_result.res_img = image;
            m_camera_calib_result.calib_flag = 1;
            return true;
        }

        // start_calib
        std::cout << "start calib......" << std::endl;
        ImageCalibration calibrate_param;

#if CAMERA_200W
        FisheyeIntrinsicCalib m_camera_calib;
#else
        PinholeIntrinsicCalib m_camera_calib;
#endif
        base::TTimeStamp start_calib_time = CTime::getCpuTime();
        cv::imwrite("/tmp/calib_cur.jpg", image);

        // m_image_log->saveCalibrationImage(image);

        calibrate_param = m_camera_calib.getCalibrationParam(image);

        m_last_calibration_image = image.clone();

        base::TTimeStamp end_calib_time = CTime::getCpuTime();
        std::cout << "calib spend time : " << CTime::timeDifference(end_calib_time, start_calib_time) << std::endl;

        m_camera_calib_result.camera_param_str = calibrate_param.calibratiton_result;
        m_camera_calib_result.result_code = calibrate_param.calibration_code;

        // cv::Mat src_mat = calibrate_param.image_src.clone();
        cv::Mat src_mat = src_img;
        cv::Mat res_mat = calibrate_param.image_res.clone();

        std::string time_stamp = CTime::getTimeString();
        if (src_mat.rows > 0 && src_mat.cols > 0 && !src_mat.empty())
        {
            // cv::resize(src_mat, src_mat, cv::Size((int)(src_mat.cols*0.75),
            // 	   (int)(src_mat.rows*0.75)), (0, 0), (0, 0), cv::INTER_LINEAR);
            m_camera_calib_result.src_img = src_mat;
            // cv::imwrite("/tmp/calib_src.jpg",src_mat);
            // std::string calib_src_str = "/tmp/calib_src_" + time_stamp + ".jpg";
            // cv::imwrite(calib_src_str,src_mat);
        }
        else
        {
            std::cout << "calib src_img img is empty" << std::endl;
        }

        if (res_mat.rows > 0 && res_mat.cols > 0 && !res_mat.empty())
        {
            cv::resize(res_mat, res_mat, cv::Size((int)(res_mat.cols * 0.5), (int)(res_mat.rows * 0.5)), (0, 0), (0, 0), cv::INTER_LINEAR);
            m_camera_calib_result.res_img = res_mat;
            // cv::imwrite("/tmp/calib_res.jpg",res_mat);
            // std::string calib_res_str = "/tmp/calib_res_" + time_stamp + ".jpg";
            // cv::imwrite(calib_res_str,res_mat);
        }
        else
        {
            std::cout << "calib res_img img is empty" << std::endl;
        }

        m_camera_calib_result.calib_flag = 1;
    }

    return true;
}

/***********************************************************************************
Function:     processOutFamilyTestModeUpdate
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processOutFamilyTestModeUpdate()
{
    processObjectDetect();
    return true;
}

/***********************************************************************************
Function:     processDetectionModeUpdate
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processDetectionModeUpdate()
{
    // CLog::log(LogKimbo, LogNormal, "[CRobotAi] m_current_detect_type %d!\n", m_current_detect_type);
    // m_current_detect_type = DETECT_TYPE_AUTO_TEST;
    m_current_detect_type = DETECT_TYPE_AUTO_CLASS_DETECT_TEST;
    switch (m_current_detect_type)
    {
    case DETECT_TYPE_OBJECT:
        m_current_detect_type = processObjectDetect();
        break;
    case DETECT_TYPE_FLOOR:
        m_current_detect_type = processFloorDetect();
        break;
    case DETECT_TYPE_SCENE:
        m_current_detect_type = processSceneDetect();
        break;
    case DETECT_TYPE_AUTO_TEST:
        m_current_detect_type = processAutoTestModel();
        break;
    case DETECT_TYPE_AUTO_CLASS_DETECT_TEST:
        m_current_detect_type = processAutoTestClassDetectModel();
        break;
    default:
        return false;
    }
    return true;
}

float CRobotAi::IOU_cv(const bbox &b1, const bbox &b2, bool base_b1, bool base_b2)
{
    float w = std::min(b1.m_left + b1.m_width, b2.m_left + b2.m_width) - std::max(b1.m_left, b2.m_left);
    float h = std::min(b1.m_top + b1.m_height, b2.m_top + b2.m_height) - std::max(b1.m_top, b2.m_top);

    if (w <= 0 || h <= 0)
        return 0;

    // std::cout << "w :" << w << "h :" << h << std::endl;
    if (base_b1)
    {
        return (w * h) / ((b1.m_height * b1.m_width) + 0.0000001);
    }

    if (base_b2)
    {
        return (w * h) / ((b2.m_height * b2.m_width) + 0.0000001);
    }

    return (w * h) / ((b1.m_height * b1.m_width) + (b2.m_height * b2.m_width) - (w * h) + 0.0000001);
}

// float CRobotAi::IOU_cv(const cv::Rect & r1,const cv::Rect & r2)
// {
// 	cv::Rect and = r1 | r2;
// 	cv::Rect U = r1 & r2;

// 	return U.area()*1.0 / and.area();
// }

bool CRobotAi::avoidBoxInhibitionSceneBox(std::vector<TAIObejectDetectData> &object_ori)
{
    std::vector<TAIObejectDetectData> object_left;
    bool has_avoid_box = false;
    for (size_t i = 0; i < object_ori.size(); i++)
    {
        TAIObejectDetectData detect_data = object_ori[i];
        if (classify_filter.boxWholeIsInAvoidInterestArea(detect_data))
        {
            has_avoid_box = true;
            // object_left.push_back(detect_data);
            break;
        }
    }

    if (!has_avoid_box)
    {
        printf("no filter scene box");
        for (size_t i = 0; i < object_ori.size(); i++)
        {
            TAIObejectDetectData detect_data = object_ori[i];
            object_left.push_back(detect_data);
        }
    }
    else
    {
        printf("has filter scene box");
        for (size_t i = 0; i < object_ori.size(); i++)
        {
            TAIObejectDetectData detect_data = object_ori[i];
            if (classify_filter.boxNeedToBeInhibitedByAvoidBox(detect_data))
            {
                continue;
            }
            object_left.push_back(detect_data);
        }
    }

    object_ori.clear();
    printf("object_left size is %d\n", object_left.size());
    object_ori.swap(object_left);
    printf("object_ori size is %d\n", object_ori.size());
}

bool CRobotAi::concactOridetectBoxAndCropDetectBox(std::vector<TAIObejectDetectData> &object_ori,
                                                   std::vector<TAIObejectDetectData> &object_crop, std::vector<TAIObejectDetectData> &object_concat)
{
    for (size_t i = 0; i < object_crop.size(); i++)
    {
        object_crop[i].detect_x1 += 140;
        object_crop[i].detect_x2 += 140;
    }

    object_concat.clear();

    for (size_t j = 0; j < object_crop.size(); j++)
    {
        TAIObejectDetectData object_crop1 = object_crop[j];
        float object_crop_roi_width = object_crop1.detect_x2 - object_crop1.detect_x1;
        float object_crop_roi_height = object_crop1.detect_y2 - object_crop1.detect_y1;
        if (object_crop_roi_width < 10 || object_crop_roi_height < 10)
        {
            continue;
        }

        bbox crop_object_roi_rec(object_crop1.detect_x1, object_crop1.detect_y1, object_crop_roi_width, object_crop_roi_height);

        bool filter = false;
        for (size_t i = 0; i < object_ori.size(); i++)
        {
            TAIObejectDetectData object_ori1 = object_ori[i];
            float object_ori_roi_width = object_ori1.detect_x2 - object_ori1.detect_x1;
            float object_ori_roi_height = object_ori1.detect_y2 - object_ori1.detect_y1;
            bbox ori_object_roi_rec(object_ori1.detect_x1, object_ori1.detect_y1, object_ori_roi_width, object_ori_roi_height);

            float iou_cv = IOU_cv(ori_object_roi_rec, crop_object_roi_rec, false, false);
            if (iou_cv > 0.3)
            {
                filter = true;
                break;
            }
        }

        if (!filter)
        {
            object_concat.push_back(object_crop1);
        }
    }
}
/***********************************************************************************
Function:     processObjectDetect
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::TDetectType CRobotAi::processObjectDetect()
{

#if DEBUG_AI
    //  cv::Mat img=cv::imread("/userdata/app/bin/1.jpg");

    // std::cout<<"width:"<<img.cols<<"height:"<<img.rows<<std::endl;
    // m_current_image.setImage(img);
    // m_current_image.setOriginImage(img);

       cv::Mat cur_mat = m_current_image.getImage();


#ifdef CAP_IMAGE

        std::string strPath="/userdata/tmp.jpg";
        cv::imwrite(strPath,cur_mat);
        
        std::string strCMD="rm /userdata/0.jpg";
        shell_call(strCMD);

        strCMD="mv /userdata/tmp.jpg /userdata/0.jpg";
        shell_call(strCMD);

        if(exists("/userdata/record"))
        {
            if(!g_outputVideo.isOpened())
            {
               std::string strCMD="rm /userdata/tmp.avi";
               shell_call(strCMD);
                //获取当前摄像头的视频信息
                cv::Size S = cv::Size(642,362);
                //打开视频路劲，设置基本信息 open函数中你参数跟上面给出的VideoWriter函数是一样的
                g_outputVideo.open(g_outputVideoPath, g_outputVideo.fourcc('M','J','P','G'), 10.0, S, true);
            }
            else
            {
                        //保存当前帧
                g_outputVideo.write(cur_mat);
            }
        }
        else
        {
            g_outputVideo.release();
        }

 
#endif




    //      g_debug_image_log.saveAiDetectIuputImage(cur_mat);
#endif

    // printf("imread ok");
    // if (!m_object_detector.detectModelAreOk())
    // {
    //     CLog::log(LogKimbo, LogNormal, "[CRobotAi] detect or class model are not ok!\n");
    //     return DETECT_TYPE_OBJECT;
    // }

    if (!m_object_detector.detectNanoOk())
    {
        CLog::log(LogKimbo, LogNormal, "[CRobotAi] detect or class model are not ok!\n");
        return DETECT_TYPE_OBJECT;
    }
    base::TTimeStamp start_detect_time = CTime::getCpuTime();
    // printf("time-statics===ImgCover===start-time:%f ms\n",start_detect_time);
    if (m_check_camera_cover_count == 50)
    {
        processImgCoverLogic(m_current_image.getImage());
        m_check_camera_cover_count = 0;
    }
    else
    {
        m_check_camera_cover_count++;
    }

    base::TTimeStamp end_img_cover_time = CTime::getCpuTime();
    // printf("time-statics===ImgCover===cost-time:%f ms\n",1000 * CTime::timeDifference(start_detect_time, end_img_cover_time));
    if (!imgIsValid(m_current_image.getImage()))
    {
        CLog::log(LogKimbo, LogNormal, "[CRobotAi] img is invalid\n");
        return DETECT_TYPE_OBJECT;
    }
    base::TTimeStamp end_img_invalid_end_time = CTime::getCpuTime();
    // printf("time-statics===ImgInvalid===cost-time:%f ms\n",1000 * CTime::timeDifference(end_img_cover_time, end_img_invalid_end_time));

    std::vector<TAIObejectDetectData> object_data;
    base::TTimeStamp start_time = CTime::getCpuTime();
    CImage upload_image;
    bool ori_detect_img_is_detect_ok = false;
    //  ori_detect_img_is_detect_ok = m_object_detector.detectObject(m_current_image, object_data);
    ori_detect_img_is_detect_ok = m_object_detector.detectObject_Nano(m_current_image, object_data);

#if TWICE_DETECT

    std::vector<TAIObejectDetectData> object_crop_data;
    bool ori_detect_crop_img_is_detect_ok = false;
    base::TTimeStamp start_getCurDetectExternImage_time = CTime::getCpuTime();
    CImage detect_crop_img = getCurDetectExternImage();
    // printf("time-statics===getCurDetectExternImage===cost-time:%f ms\n",1000 * CTime::timeDifference(start_getCurDetectExternImage_time, CTime::getCpuTime()));
    ori_detect_crop_img_is_detect_ok = m_object_detector.detectObject(detect_crop_img, object_crop_data);
    CLog::log(LogKimbo, LogNormal, "[CRobotAi] object crop ori detect size is %d!\n", object_crop_data.size());

    std::vector<TAIObejectDetectData> crop_left_objects;
    base::TTimeStamp start_concactOridetectBoxAndCropDetectBox_time = CTime::getCpuTime();
    concactOridetectBoxAndCropDetectBox(object_data, object_crop_data, crop_left_objects);
    // printf("time-statics===concactOridetectBoxAndCropDetectBox===cost-time:%f ms\n",1000 * CTime::timeDifference(start_concactOridetectBoxAndCropDetectBox_time, CTime::getCpuTime()));

#endif

#if DEBUG_ORI_DETECT_CLASS_IMAGE
    std::vector<TAIObejectDetectData> detect_class_ori_object_data;
#endif

    CLog::log(LogKimbo, LogNormal, "[CRobotAi] object size is %d !\n", object_data.size());
    int ori_img_detect_count = 0;
    static int nn=0;

    if (!object_data.empty())
    {
        long detect_just_take_time = 1000 * CTime::timeDifference(start_time, CTime::getCpuTime());

        for (size_t i = 0; i < object_data.size(); i++)
        {




            cv::Mat src_image = m_current_image.getImage().clone();
            m_mobilev2.runmobilenetv2Classifiaction(src_image, object_data[i]);

            // if (classify_filter.filterNotInInterestAreaDetectData(object_data[i]))
            // {
            //     continue;
            // }



          
            CImage classification_image = m_current_image;
            // //save ori detect debug image
            // cv::Mat origin_mat = classification_image.getOriginImage();
            // g_debug_image_log.saveOnlyDetectImage(object_data[i], origin_mat);

            // base::TTimeStamp start_createObjectClassficationImage_time = CTime::getCpuTime();
            if (!createObjectClassficationImage(object_data[i], classification_image))
            {
                continue;
            }

            /*
            if(!m_classification.confusionClassification(classification_image, object_data[i]))
            {
                continue;
            }
            */
            // printf("time-statics===confusionClassification===cost-time:%f ms\n",1000 * CTime::timeDifference(start_createObjectClassficationImage_time, CTime::getCpuTime()));

            base::TTimeStamp start_filterObject_time = CTime::getCpuTime();

#if DEBUG_ORI_DETECT_CLASS_IMAGE
            detect_class_ori_object_data.push_back(object_data[i]);
#endif

            // Result valid
            //      if(classify_filter.filterObject(object_data[i],m_current_ai_mode))
            {

                base::TTimeStamp end_filterObject_time = CTime::getCpuTime();
                // printf("time-statics===filterObject_time===cost-time:%f ms\n",1000 * CTime::timeDifference(start_filterObject_time, end_filterObject_time));

                object_data[i].timestamp = classification_image.getTimeStamp();
                object_data[i].detect_img = classification_image.getImage();
                object_data[i].robot_sensor = classification_image.setRobotSensor();
                // if(object_data[i].dirty_class==AI_OBJECT_DIRTY_WATER)
                // {
                //     object_data[i].obj_class=AI_OBJECT_SOCKS;
                // }
                // else if(object_data[i].dirty_class==AI_OBJECT_DIRTY_POWDER)
                // {
                //     object_data[i].obj_class=AI_OBJECT_SHOE;
                // }
                // else
                // {
                //     object_data[i].obj_class=AI_OBJECT_WIRE;
                // }

                m_result_object.push_back(object_data[i]);

                TAIObejectDetectData object_temp_data = object_data[i];
                if (object_temp_data.obj_class == AI_OBJECT_BLANKET)
                {
                    m_last_detect_object_blanket_time = CTime::getCpuTime();
                    // printf("object==blanket");
                }

                //         object_temp_data.obj_class=AI_OBJECT_SOCKS;
                object_temp_data.classify_score = object_data[i].object_detect_score;

                std::string result_label = CTypeTransform::aiObjectClass2String(object_temp_data.obj_class);
                CLog::log(LogKimbo, LogNormal, "classfision class type %d class name is %s class score %.2f!\n", object_temp_data.obj_class, result_label.c_str(), object_temp_data.classify_score);



// printf("time-statics===addObjectTime===cost-time:%f ms\n",1000 * CTime::timeDifference(end_filterObject_time, CTime::getCpuTime()));
#if DEBUG_AI
                cv::Mat origin_mat = classification_image.getOriginImage();
                cv::Mat detect_mat = classification_image.getImage();
                g_debug_image_log.saveDetectObjectImage(object_data[i], detect_mat, origin_mat);


                // rectangle(cur_mat, cv::Point(object_data[i].detect_x1, object_data[i].detect_y1), cv::Point(object_data[i].detect_x2, object_data[i].detect_y2), cv::Scalar(255, 0, 0, 255), 3);
                // putText(cur_mat, result_label + std::to_string(object_temp_data.classify_score)  , cv::Point(object_data[i].detect_x1-10, object_data[i].detect_y1), 1, 1, cv::Scalar(0, 255, 0, 255));

#endif
            }
            // else
            // {
            //     CLog::log(LogKimbo, LogNormal, " detect obj is filtered\n");
            // }
        }
        base::TTimeStamp end_detect_time = CTime::getCpuTime();
        if (object_data.size() > 0)
        {
            m_obj_detect_i++;
            long detect_take_time = 1000 * CTime::timeDifference(start_detect_time, end_detect_time);
            m_obj_detect_total_time += detect_take_time;
            CLog::log(LogKimbo, LogNormal, "==>object_detect_order:%ld just_detect_time:%ld detece_obj_num:%d take_time:%ld total_average_time:%ld\n", m_obj_detect_i, detect_just_take_time, object_data.size(), detect_take_time, m_obj_detect_total_time / m_obj_detect_i);

            if (object_data.size() == 1)
            {
                m_obj_detect_one_index++;
                m_obj_detect_one_total_time += detect_take_time;
                CLog::log(LogKimbo, LogNormal, "==>m_obj_detect_one average_time:%ld\n", m_obj_detect_one_total_time / m_obj_detect_one_index);
            }
            else if (object_data.size() == 2)
            {
                m_obj_detect_two_index++;
                m_obj_detect_two_total_time += detect_take_time;
                CLog::log(LogKimbo, LogNormal, "==>m_obj_detect_two average_time:%ld\n", m_obj_detect_two_total_time / m_obj_detect_two_index);
            }
        }


        //    std::string path= "/userdata/app/bin/"+std::to_string(nn++)+"_detect.jpg";
        //    cv::imwrite(path, cur_mat);

           CLog::log(LogKimbo, LogNormal, "[CRobotAi] object process time is %f ms!\n", 1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));
    }

    ori_img_detect_count = m_result_object.size();

#if DEBUG_ORI_DETECT_CLASS_IMAGE
    cv::Mat detect_class_mat = m_current_image.getImage();
    g_debug_image_log.saveDetectClassOriResultImage(detect_class_ori_object_data, detect_class_mat);
#endif

#if TWICE_DETECT
    if (!crop_left_objects.empty())
    {

        CLog::log(LogKimbo, LogNormal, "[CRobotAi] object crop size is %d!\n", crop_left_objects.size());
        for (size_t i = 0; i < crop_left_objects.size(); i++)
        {
            if (classify_filter.filterNotInInterestAreaDetectData(crop_left_objects[i]))
            {
                continue;
            }

            CImage classification_image = m_current_image;

            if (!createObjectClassficationImage(crop_left_objects[i], classification_image))
            {
                continue;
            }

            if (!m_classification.classification(classification_image, crop_left_objects[i]))
            {
                continue;
            }

            TAIObejectDetectData obj_dect_data = crop_left_objects[i];

            // if (obj_dect_data.obj_class != AI_OBJECT_SOCKS &&
            //     obj_dect_data.obj_class != AI_OBJECT_SHOE  &&
            //     obj_dect_data.obj_class != AI_OBJECT_WIRE  &&
            //     obj_dect_data.obj_class != AI_OBJECT_WEIGHT_SCALE  &&
            //     obj_dect_data.obj_class != AI_OBJECT_CHAIR_BASE
            //      &&obj_dect_data.obj_class != AI_OBJECT
            //    )
            // {
            //     continue;
            // }

            // if (obj_dect_data.classify_score < 0.1 || obj_dect_data.object_detect_score < 0.1)
            // {
            //     continue;
            // }

            // Result valid
            if (classify_filter.filterObject(crop_left_objects[i], m_current_ai_mode))
            {
                crop_left_objects[i].timestamp = classification_image.getTimeStamp();
                crop_left_objects[i].detect_img = classification_image.getImage();
                crop_left_objects[i].robot_sensor = classification_image.setRobotSensor();
                m_result_object.push_back(crop_left_objects[i]);

#if DEBUG_AI
                cv::Mat origin_mat = classification_image.getOriginImage();
                cv::Mat detect_mat = classification_image.getImage();
                g_debug_image_log.saveDetectObjectImage(crop_left_objects[i], detect_mat, origin_mat);
#endif
                CLog::log(LogKimbo, LogNormal, "==>object crop dectect unknown socks---------%d\n");
            }
        }
        CLog::log(LogKimbo, LogNormal, "[CRobotAi] object process time is %f ms!\n", 1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));
    }
#endif

    // bool need_detect_floor = m_result_object.empty();
    // ori_img_detect_count
    // bool need_detect_floor = (ori_img_detect_count == 0);
    // if (!m_result_object.empty())
    // {
    //     ++m_serias_detect_obj_count;
    //     if (m_serias_detect_obj_count >= 8)
    //     {
    //         need_detect_floor = true;
    //         m_serias_detect_obj_count = 0;
    //     }
    // }else
    // {
    //     m_serias_detect_obj_count = 0;
    // }
    // need_detect_floor = true;

    // bool isDetectObjectsInserInFloorArea_flag = isDetectObjectsHasBlanketAndInserInFloorArea(m_result_object);
    // if (isDetectObjectsInserInFloorArea_flag)
    // {
    //     CImage floor_image = m_current_image;
    //     createFloorClassficationImage(floor_image);
    //     TAIObejectDetectData floor_blanket_detect_data;
    //     floor_blanket_detect_data.obj_class = AI_OBJECT_BLANKET;
    //     floor_blanket_detect_data.timestamp = floor_image.getTimeStamp();
    //     floor_blanket_detect_data.detect_img = floor_image.getImage();
    //     setBlanketFloorLocationInfo(floor_blanket_detect_data);
    //     m_result_object.push_back(floor_blanket_detect_data);

    //     #if DEBUG_AI
    //     cv::Mat origin_mat = floor_image.getOriginImage();
    //     cv::Mat detect_mat = floor_image.getImage();
    //     g_debug_image_log.saveFloorBlanketImage(floor_blanket_detect_data, detect_mat);
    //     #endif

    //     printf("isDetectObjectsHasBlanketAndInserInFloorArea");
    // }

    // if (isDetectObjectsInserInFloorArea(m_result_object) || isDetectObjectsInserInFloorArea_flag)
    // {
    //     need_detect_floor = false;
    // }
    // // need_detect_floor = false;
    // if (need_detect_floor)
    // {
    //     CImage floor_image = m_current_image;
    //     CLog::log(LogKimbo, LogNormal, "[CManagerAI] processFloorDetect time %f ms!\n",
    //                         1000 * CTime::timeDifference(floor_image.getTimeStamp(), CTime::getCpuTime()));
    //     base::TTimeStamp start_time = CTime::getCpuTime();

    //     if(createFloorClassficationImage(floor_image))
    //     {
    //         TAIObejectDetectData detect_data;

    //         // if(m_classification.classification(floor_image, detect_data))
    //         if(m_classification.confusionClassification(floor_image, detect_data))
    //         // if(m_classification.classificationFloorBlanket(floor_image, detect_data))
    //         {
    //             // Result valid
    //             if(classify_filter.filterFloor(detect_data))
    //             {
    //                 detect_data.timestamp = floor_image.getTimeStamp();
    //                 detect_data.detect_img = floor_image.getImage();

    //                 bool floor_blanket_can_pass = true;
    //                 if (detect_data.obj_class == AI_OBJECT_BLANKET)
    //                 {
    //                     if(m_last_detect_object_blanket_time == INVALID_TIMESTAMP)
    //                     {
    //                         floor_blanket_can_pass = false;
    //                         printf("m_last_detect_object_blanket_time is invalid");
    //                     }else
    //                     {
    //                         long from_last_detect_blanket_time_inter_val = 1000 * CTime::timeDifference(m_last_detect_object_blanket_time, CTime::getCpuTime());
    //                         floor_blanket_can_pass = from_last_detect_blanket_time_inter_val < MAX_FLOOR_BLANKET_PASS_TIME_PERIOD;
    //                         printf("from_last_detect_blanket_time_inter_val is %lld ms\n",from_last_detect_blanket_time_inter_val);
    //                     }
    //                     if (floor_blanket_can_pass)
    //                     {
    //                         printf("floor blanket in period");
    //                         printf("floor==blanket");
    //                         setBlanketFloorLocationInfo(detect_data);
    //                         m_result_object.push_back(detect_data);
    //                         #if DEBUG_AI
    //                         cv::Mat origin_mat = floor_image.getOriginImage();
    //                         cv::Mat detect_mat = floor_image.getImage();
    //                         g_debug_image_log.saveFloorBlanketImage(detect_data, detect_mat);
    //                         #endif
    //                     }else
    //                     {
    //                         printf("floor blanket in not period");
    //                     }

    //                 }else
    //                 {
    //                     m_result_object.push_back(detect_data);
    //                     #if DEBUG_AI
    //                     cv::Mat origin_mat = floor_image.getOriginImage();
    //                     cv::Mat detect_mat = floor_image.getImage();
    //                     g_debug_image_log.saveDetectObjectImage(detect_data, detect_mat, origin_mat);
    //                     #endif
    //                 }

    //                 // if (detect_data.obj_class == AI_OBJECT_BLANKET)
    //                 // {
    //                 //     setBlanketFloorLocationInfo(detect_data);
    //                 // }
    //                 // m_result_object.push_back(detect_data);

    //                 // #if DEBUG_AI
    //                 // cv::Mat origin_mat = floor_image.getOriginImage();
    //                 // cv::Mat detect_mat = floor_image.getImage();
    //                 // g_debug_image_log.saveDetectObjectImage(detect_data, detect_mat, origin_mat);
    //                 // #endif
    //                 CLog::log(LogKimbo, LogNormal, "[CRobotAi] floor class is %d %s!\n", detect_data.obj_class,
    //                                                     CTypeTransform::aiObjectClass2String(detect_data.obj_class).c_str());
    //             }

    //         }
    //     }
    //     CLog::log(LogKimbo, LogNormal, "[CRobotAi] floor process time is %f ms!\n", 1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));
    // }

#if FAMILY_DATA_COLLECT
    if (m_current_ai_mode == base::AI_MODE_OUT_FAMILY_TEST)
    {
        long long time_diff_last_upload_image = CTime::timeDifference(m_last_upload_image_time_stamp, CTime::getCpuTime());
        if (time_diff_last_upload_image > m_upload_server_image_frequent)
        {
            setUploadServerImage();
            m_last_upload_image_time_stamp = CTime::getCpuTime();
        }
        // m_need_upload_detect_imgage = true;
        processTheCurrentUploadDetectImage();
    }
#endif

    // long per_lun_detect_box_count = crop_left_objects.size() + object_data.size();
    // m_total_detect_box_count += per_lun_detect_box_count;
    // printf("per-lun-detect-box-count %ld total-detect-box-count %ld\n",per_lun_detect_box_count,m_total_detect_box_count);

    return DETECT_TYPE_OBJECT;
}

/***********************************************************************************
Function:     processFloorDetect
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::TDetectType CRobotAi::processFloorDetect()
{
    CImage floor_image = m_current_image;
    CLog::log(LogKimbo, LogNormal, "[CManagerAI] processFloorDetect time %f ms!\n",
              1000 * CTime::timeDifference(floor_image.getTimeStamp(), CTime::getCpuTime()));
    base::TTimeStamp start_time = CTime::getCpuTime();

    if (createFloorClassficationImage(floor_image))
    {
        TAIObejectDetectData detect_data;

        if (m_classification.classification(floor_image, detect_data))
        {
#if DEBUG_AI
            cv::Mat origin_mat = floor_image.getOriginImage();
            cv::Mat detect_mat = floor_image.getImage();
            g_debug_image_log.saveDetectObjectImage(detect_data, detect_mat, origin_mat);
#endif

            // Result valid
            if (classify_filter.filterFloor(detect_data))
            {
                detect_data.timestamp = floor_image.getTimeStamp();
                detect_data.robot_sensor = floor_image.setRobotSensor();
                m_result_object.push_back(detect_data);
            }
            CLog::log(LogKimbo, LogNormal, "[CRobotAi] floor class is %d %s!\n", detect_data.obj_class,
                      CTypeTransform::aiObjectClass2String(detect_data.obj_class).c_str());
        }
    }
    CLog::log(LogKimbo, LogNormal, "[CRobotAi] floor process time is %f ms!\n", 1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));

    return DETECT_TYPE_OBJECT;
}

/***********************************************************************************
Function:     processSceneDetect
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::TDetectType CRobotAi::processSceneDetect()
{
    CImage scene_image = m_current_image;
    TAIObejectDetectData detect_data;
    base::TTimeStamp start_time = CTime::getCpuTime();

    if (m_classification.classification(scene_image, detect_data))
    {
        if (hasSecne(detect_data.obj_class))
        {
            std::vector<TAIObejectDetectData> object_data;

            if (m_object_detector.detectObject(scene_image, object_data))
            {
                for (size_t i = 0; i < object_data.size(); i++)
                {
                    CImage classification_image = scene_image;

                    if (!createObjectClassficationImage(object_data[i], classification_image))
                    {
                        continue;
                    }

                    if (!m_classification.classification(classification_image, object_data[i]))
                    {
                        continue;
                    }

#if DEBUG_AI
                    cv::Mat origin_mat = classification_image.getOriginImage();
                    cv::Mat detect_mat = classification_image.getImage();
                    g_debug_image_log.saveDetectObjectImage(object_data[i], detect_mat, origin_mat);
#endif

                    // Result valid
                    if (classify_filter.filter(object_data[i]))
                    {
                        object_data[i].timestamp = classification_image.getTimeStamp();
                        object_data[i].robot_sensor = classification_image.setRobotSensor();
                        m_result_object.push_back(object_data[i]);
                    }
                    CLog::log(LogKimbo, LogNormal, "[CRobotAi] scene class is %d %s!\n", object_data[i].obj_class,
                              CTypeTransform::aiObjectClass2String(object_data[i].obj_class).c_str());
                }
            }
        }
    }
    CLog::log(LogKimbo, LogNormal, "[CRobotAi] scene process time is %f ms!\n", 1000 * CTime::timeDifference(start_time, CTime::getCpuTime()));

    return DETECT_TYPE_OBJECT;
}

/***********************************************************************************
Function:     createObjectClassficationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::createObjectClassficationImage(ai::TAIObejectDetectData &object, ai::CImage &image)
{
    int object_roi_width = object.detect_x2 - object.detect_x1;
    int object_roi_height = object.detect_y2 - object.detect_y1;

    if (object_roi_width < 0 || object_roi_height < 0)
    {
        return false;
    }

    cv::Mat origin_mat = m_current_image.getImage();
    cv::Mat object_mat = origin_mat(cv::Rect(object.detect_x1, object.detect_y1,
                                             object_roi_width, object_roi_height));

    image.setOriginImage(origin_mat);
    image.setImage(object_mat);

    return true;
}

bool CRobotAi::isDetectObjectsHasBlanketAndInserInFloorArea(std::vector<TAIObejectDetectData> &result_objects)
{
    for (size_t i = 0; i < result_objects.size(); i++)
    {
        TAIObejectDetectData object_ori1 = result_objects[i];

        if (object_ori1.obj_class == AI_OBJECT_BLANKET)
        {
            float object_ori_roi_width = object_ori1.detect_x2 - object_ori1.detect_x1;
            float object_ori_roi_height = object_ori1.detect_y2 - object_ori1.detect_y1;
            bbox ori_object_roi_rec(object_ori1.detect_x1, object_ori1.detect_y1, object_ori_roi_width, object_ori_roi_height);

            int floor_reconize_width = SC_CAMERA_CROPED_WIDTH * m_floor_widht_aspatia;
            int floor_reconize_height = SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia;
            int x1 = (SC_CAMERA_CROPED_WIDTH - floor_reconize_width) / 2;
            int y1 = SC_CAMERA_CROPED_HEIGHT - SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia;
            int floor_area_middle_y = y1 + floor_reconize_height / 2;
            bbox floor_rec(x1, y1, floor_reconize_width, floor_reconize_height);

            float iou_cv = IOU_cv(floor_rec, ori_object_roi_rec, true, false);
            if (iou_cv >= 0.3 && object_ori1.detect_y2 >= floor_area_middle_y)
            {
                return true;
            }
        }
    }
    return false;
}

/***********************************************************************************
Function:     createObjectClassficationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::isDetectObjectsInserInFloorArea(std::vector<TAIObejectDetectData> &result_objects)
{

    bool isObjectInFloorArea = false;
    for (size_t i = 0; i < result_objects.size(); i++)
    {
        TAIObejectDetectData object_ori1 = result_objects[i];

        if (object_ori1.obj_class == AI_OBJECT_BLANKET)
        {
            return false;
        }

        float object_ori_roi_width = object_ori1.detect_x2 - object_ori1.detect_x1;
        float object_ori_roi_height = object_ori1.detect_y2 - object_ori1.detect_y1;
        bbox ori_object_roi_rec(object_ori1.detect_x1, object_ori1.detect_y1, object_ori_roi_width, object_ori_roi_height);

        int floor_reconize_width = SC_CAMERA_CROPED_WIDTH * m_floor_widht_aspatia;
        int floor_reconize_height = SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia;
        int x1 = (SC_CAMERA_CROPED_WIDTH - floor_reconize_width) / 2;
        int y1 = SC_CAMERA_CROPED_HEIGHT - SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia;

        bbox floor_rec(x1, y1, floor_reconize_width, floor_reconize_height);

        float iou_cv = IOU_cv(floor_rec, ori_object_roi_rec, true, false);
        if (iou_cv > 0.3)
        {
            isObjectInFloorArea = true;
            break;
        }
    }
    return isObjectInFloorArea;
}

/***********************************************************************************
Function:     createObjectClassficationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::setBlanketFloorLocationInfo(ai::TAIObejectDetectData &blanket_floor_object)
{

    int floor_reconize_width = SC_CAMERA_CROPED_WIDTH * m_floor_widht_aspatia;
    int floor_reconize_height = SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia * 0.5;
    int x1 = (SC_CAMERA_CROPED_WIDTH - floor_reconize_width) / 2;
    int y1 = SC_CAMERA_CROPED_HEIGHT - SC_CAMERA_CROPED_HEIGHT * m_floor_height_aspatia;

    int x2 = x1 + floor_reconize_width;
    int y2 = y1 + floor_reconize_height;

    if (x2 > SC_CAMERA_CROPED_WIDTH)
    {
        x2 = SC_CAMERA_CROPED_WIDTH - 1;
    }

    if (y2 > SC_CAMERA_CROPED_HEIGHT)
    {
        y2 = SC_CAMERA_CROPED_HEIGHT - 1;
    }

    CTofParameters m_tof_params;

    const float src_frame_x_to_tof_scale = SC_CAMERA_CROPED_WIDTH / m_tof_params.getTofCameraWidth();
    const float src_frame_y_to_tof_scale = SC_CAMERA_CROPED_HEIGHT / m_tof_params.getTofCameraHeight();

    int tof_rgb_x1 = x1 / src_frame_x_to_tof_scale;
    int tof_rgb_y1 = y1 / src_frame_y_to_tof_scale;

    int tof_rgb_x2 = x2 / src_frame_x_to_tof_scale;
    int tof_rgb_y2 = y2 / src_frame_y_to_tof_scale;

    // blanket_floor_object.object_detect_score = out_prop[i];
    blanket_floor_object.tof_rgb_x1 = tof_rgb_x1;
    blanket_floor_object.tof_rgb_y1 = tof_rgb_y1;
    blanket_floor_object.tof_rgb_x2 = tof_rgb_x2;
    blanket_floor_object.tof_rgb_y2 = tof_rgb_y2;

    blanket_floor_object.detect_x1 = x1;
    blanket_floor_object.detect_y1 = y1;
    blanket_floor_object.detect_x2 = x2;
    blanket_floor_object.detect_y2 = y2;
    return true;
}

CImage CRobotAi::getCurDetectExternImage()
{
    cv::Mat origin_mat = m_current_image.getImage();
    // int margin = (origin_mat.cols() - origin_mat.rows())/2;
    int margin = 140;
    float width = 362;
    float height = 362;

    cv::Mat object_mat = origin_mat(cv::Rect(margin, 0,
                                             width, height));
    CImage crop_image;

    crop_image.setOriginImage(origin_mat);
    crop_image.setImage(object_mat);

    return crop_image;
}

/***********************************************************************************
Function:     createExternObjectClassficationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::createExternObjectClassficationImage(ai::TAIObejectDetectData &object, ai::CImage &image)
{
    int object_roi_width = object.detect_x2 - object.detect_x1;
    int object_roi_height = object.detect_y2 - object.detect_y1;

    if (object_roi_width < 0 || object_roi_height < 0)
    {
        return false;
    }

    int deta_wh = object_roi_width - object_roi_height;
    if (deta_wh < 0)
    {
        deta_wh *= -1;
    }
    int deta = deta_wh / 2;
    int extern_size = object_roi_width > object_roi_height ? object_roi_width : object_roi_height;
    int top_extern, right_extern, bottom_extern, left_exern;
    top_extern = right_extern = bottom_extern = left_exern = 0;

    cv::Mat origin_mat = m_current_image.getImage();
    int ori_img_width = origin_mat.cols;
    int ori_img_height = origin_mat.rows;

    int new_x1 = 0, new_y1 = 0, new_x2 = 0, new_y2 = 0;
    if (object_roi_width > object_roi_height) // padding top bottom
    {
        new_x1 = object.detect_x1;
        new_x2 = object.detect_x2;
        new_y1 = object.detect_y1 - deta;
        new_y2 = object.detect_y2 + deta;
        if (new_y1 < 0)
        {
            top_extern = new_y1 * -1;
            new_y1 = 0;
        }
        if (new_y2 > ori_img_height)
        {
            bottom_extern = new_y2 - ori_img_height;
            new_y2 = ori_img_height - 1;
        }
    }
    else
    {
        new_y1 = object.detect_y1;
        new_y2 = object.detect_y2;
        new_x1 = object.detect_x1 - deta;
        new_x2 = object.detect_x2 + deta;
        if (new_x1 < 0)
        {
            left_exern = new_x1 * -1;
            new_x1 = 0;
        }
        if (new_x2 > ori_img_width)
        {
            right_extern = new_x2 - ori_img_width;
            new_x2 = ori_img_width - 1;
        }
    }

    cv::Mat object_mat = origin_mat(cv::Rect(new_x1, new_y1,
                                             new_x2 - new_x1, new_y2 - new_y1));

    cv::Mat extern_mat;
    cv::copyMakeBorder(object_mat, extern_mat, top_extern, bottom_extern, left_exern, right_extern, cv::BorderTypes::BORDER_CONSTANT, cv::Scalar(0, 0, 0));

    // cv::Mat object_mat = origin_mat(cv::Rect(object.detect_x1, object.detect_y1,
    //                                          object_roi_width, object_roi_height));

    image.setOriginImage(origin_mat);
    image.setImage(extern_mat);

    return true;
}

/***********************************************************************************
Function:     createFloorClassficationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::createFloorClassficationImage(ai::CImage &image)
{
    cv::Mat src_img = image.getImage();

    if (src_img.empty() || src_img.cols == 0 || src_img.rows == 0)
    {
        return false;
    }
    // m_floor_widht_aspatia:0.716,m_floor_height_aspatia:0.276,
    //  float m_floor_widht_aspatia1 = 0.716;
    //  float m_floor_height_aspatia1 = 0.276;
    //  int floor_reconize_width = src_img.cols * m_floor_widht_aspatia1;
    //  int floor_reconize_height = src_img.rows * m_floor_height_aspatia1;

    int floor_reconize_width = src_img.cols * m_floor_widht_aspatia;
    int floor_reconize_height = src_img.rows * m_floor_height_aspatia;
    int floor_reconize_ori_x = (src_img.cols - floor_reconize_width) / 2;
    int floor_reconize_ori_y = src_img.rows - floor_reconize_height;

    cv::Mat floor_mat = src_img(cv::Rect(floor_reconize_ori_x, floor_reconize_ori_y,
                                         floor_reconize_width, floor_reconize_height));
    image.setImage(floor_mat);
    return true;
}

/***********************************************************************************
Function:     hasSecne
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::hasSecne(TAIObjectClass object)
{
    return (object > AI_OBJECT_FURNITURE && object < AI_ROOM);
}

/***********************************************************************************
Function:     initDataCollectionFrequent
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::initDataCollectionFrequent()
{
    CAiParameters m_ai_parameter;
    m_upload_server_image_frequent = m_ai_parameter.getServerDataCollectionFrequt();
}

/***********************************************************************************
Function:     setUploadServerImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::setUploadServerImage()
{
    cv::Mat ori_image = m_current_image.getOriginImage();
    if (!imgIsValid(ori_image))
    {
        return false;
    }
    if (processTheCurrentUploadImage(ori_image))
    {
        // std::cout << "<==============same big frame================>"<<std::endl;
        return false;
    }
    m_image_log->saveCalibrationImage(ori_image);
    std::cout << "big frame are suit upload ================>" << std::endl;
    m_last_upload_image = ori_image;
    m_upload_server_image.setOriginImage(ori_image);
    base::TTimeStamp time_stamp = m_current_image.getTimeStamp();
    m_upload_server_image.setTimeStamp(time_stamp);
}

/***********************************************************************************
Function:     processUploadDetectImgLogic
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processUploadDetectImgLogic()
{
    if (m_result_object.size() > 0)
    {
        m_need_upload_detect_imgage = true;
        TAIObejectDetectData first_detect_obj = m_result_object[0];
        if (!m_last_upload_detect_image_info.detect_img.empty())
        {
            if (first_detect_obj.obj_class == AI_FLOOR_CONCRETE || first_detect_obj.obj_class == AI_FLOOR_TITLE)
            {
                m_upload_detect_floor_count++;
                if (m_upload_detect_floor_count != m_upload_detect_floor_count_limit)
                {
                    m_need_upload_detect_imgage = false;
                    return m_need_upload_detect_imgage;
                }
                else
                {
                    m_upload_detect_floor_count = 0;
                }
            }
            else
            {
                m_upload_detect_obj_count++;
                if (m_upload_detect_obj_count != m_upload_detect_obj_count_limit)
                {
                    m_need_upload_detect_imgage = false;
                    return m_need_upload_detect_imgage;
                }
                else
                {
                    m_upload_detect_obj_count = 0;
                }

                if (isTwoDetectInfoNearlySame(first_detect_obj, m_last_upload_detect_image_info))
                {
                    m_need_upload_detect_imgage = false;
                    return m_need_upload_detect_imgage;
                }
            }

            if (isTwoFrameNearlySame(m_last_upload_detect_image_info.detect_img, first_detect_obj.detect_img))
            {
                m_need_upload_detect_imgage = false;
                return m_need_upload_detect_imgage;
            }
        }

        if (m_need_upload_detect_imgage)
        {
            m_last_upload_detect_image_info.detect_img = first_detect_obj.detect_img.clone();
            m_last_upload_detect_image_info.obj_class = first_detect_obj.obj_class;
            // cv::Mat em;
            // g_debug_image_log.saveDetectObjectImage(first_detect_obj, first_detect_obj.detect_img, em);
        }
        else
        {
            std::cout << "<==============same detect frame================>" << std::endl;
        }
    }
    else
    {
        m_need_upload_detect_imgage = false;
    }
    return m_need_upload_detect_imgage;
}

/***********************************************************************************
Function:     processAutoTestClassDetectModel
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::TDetectType CRobotAi::processAutoTestClassDetectModel()
{
    if (m_current_image.getOriginImage().empty())
        return DETECT_TYPE_AUTO_CLASS_DETECT_TEST;

    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode class detect test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode class detect test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode class detect test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode class detect test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode class detect test!\n");
    std::string directory = "/userdata/AI/mode_test_class_detect/";
    std::vector<std::string> files_list;
    std::vector<std::string> files_name_list;
    long totol_take_time = 0;
    if (readDirFileList(directory.c_str(), files_list, files_name_list, true))
    {
        for (size_t i = 0; i < files_list.size(); i++)
        {
            //执行模型，输出结果
            CImage test_image;
            std::string name = files_list[i];

            cv::Mat image_read = cv::Mat();
            if (m_image_log->readDebugImage(name, image_read))
            {
                cv::Mat dest_mat = image_read;
                bool need_crop = true;
                if (image_read.cols == 1920 && image_read.rows == 1080)
                {
                    cv::resize(image_read, image_read, cv::Size(image_read.cols * 0.5, image_read.rows * 0.5), (0, 0), (0, 0), cv::INTER_LINEAR);
                }
                if (image_read.cols == 1280 && image_read.rows == 720)
                {
                    cv::resize(image_read, image_read, cv::Size(image_read.cols * 0.5, image_read.rows * 0.5), (0, 0), (0, 0), cv::INTER_LINEAR);
                    need_crop = false;
                }
                if (image_read.cols == 960 && image_read.rows == 540 && need_crop)
                {
                    ai::CImageTransform image_transform;
                    cv::Mat resize_image = image_transform.resizeImage(image_read);
                    dest_mat = resize_image;
                    // dest_mat = image_read;
                }
                if (image_read.cols > 600 && image_read.cols < 960) // 642x362,640x360
                {
                    dest_mat = image_read;
                }

                test_image.setImage(dest_mat);
                base::TTimeStamp time = CTime::getCpuTime();
                test_image.setTimeStamp(time);
                m_current_image = test_image;
                m_detect_ori_imgage_debug_name = files_name_list[i];
                base::TTimeStamp start_detect_time = CTime::getCpuTime();
                processObjectDetect();
                base::TTimeStamp end_detect_time = CTime::getCpuTime();
                long detect_take_time = 1000 * CTime::timeDifference(start_detect_time, end_detect_time);
                totol_take_time += detect_take_time;
                printf("static-image-index: %d per-take-time: %ld total-take-time: %ld\n", i, detect_take_time, totol_take_time);
            }
            std::cout << "process image index : " << i << std::endl;
            std::cout << "total size : " << files_list.size() << std::endl;
            std::cout << "img path : " << name << std::endl;
        }
    }
    std::cout << "finished class detect test : " << std::endl;
    while (1)
    {
        ;
    }
}

/***********************************************************************************
Function:     processAutoTestModel
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotAi::TDetectType CRobotAi::processAutoTestModel()
{
    if (m_current_image.getOriginImage().empty())
        return DETECT_TYPE_AUTO_TEST;

    int all_class = 35;
    double all_class_rate[35] = {0};
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode test!\n");
    CLog::log(LogKimbo, LogWarn, "[CRobotAi] Start mode test!\n");
    int class_count = 0;
    int success_count = 0;
    for (size_t j = 0; j < all_class; j++)
    {
        AIAllClassLabel current_label = (AIAllClassLabel)j;
        std::string directory = "/userdata/AI/mode_test/" + CTypeTransform::aiLable2String(current_label);
        // std::string directory = "/tmp/mode_test/" + CTypeTransform::aiLable2String(current_label);
        std::vector<std::string> files_list;
        std::vector<std::string> files_name_list;
        if (readDirFileList(directory.c_str(), files_list, files_name_list, true))
        {
            CLog::log(LogKimbo, LogWarn, "[CRobotAi] directory files_list size is %d %s!\n", files_list.size(), CTypeTransform::aiLable2String(current_label).c_str());
            int sucess_times = 0;
            int all_times = 0;
            double process_time = 0.0;
            double all_process_time = 0.0;
            double total_score = 0.0;
            int right = 0;
            for (size_t i = 0; i < files_list.size(); i++)
            {
                //执行模型，输出结果
                CImage floor_image = m_current_image;
                std::string name = files_list[i];

                cv::Mat image_read = cv::Mat();
                if (m_image_log->readDebugImage(name, image_read))
                {
                    // std::vector<TAIObejectDetectData> object_data;
                    // m_object_detector.detectObject(m_current_image, object_data);

                    floor_image.setImage(image_read);
                    TAIObejectDetectData detect_data;
                    base::TTimeStamp start_time = CTime::getCpuTime();
                    m_classification.classification(floor_image, detect_data);
                    process_time = 1000 * CTime::timeDifference(start_time, CTime::getCpuTime());
                    all_process_time += process_time;
                    class_count += 1;
                    std::cout << i << " " << CTypeTransform::aiLable2String(current_label) << " time " << process_time << " ms " << (double)sucess_times / all_times << std::endl;
                    if (detect_data.obj_class == CTypeTransform::aiLable2AiObjectClass(current_label) && detect_data.obj_class != AI_OBJECT_NOTHING)
                    {
                        right++;
                        total_score += detect_data.classify_score;
                        std::cout << "average score : " << total_score / right << std::endl;
                        sucess_times++;
                        success_count += 1;
                    }
                    all_times++;
                }
            }
            double success_rate = (double)sucess_times / all_times;
            double av_process_time = all_process_time / all_times;
            all_class_rate[j] = success_rate;
            CLog::log(LogKimbo, LogWarn, "[CRobotAi] %s end success_rate is %f, %d, %d, %f!\n",
                      CTypeTransform::aiLable2String(current_label).c_str(),
                      success_rate, sucess_times, all_times, av_process_time);
        }
        else
        {
            CLog::log(LogKimbo, LogWarn, "[CRobotAi] directory fail %s!\n", CTypeTransform::aiLable2String(current_label).c_str());
        }
    }

    for (size_t j = 0; j < all_class; j++)
    {
        AIAllClassLabel current_label = (AIAllClassLabel)j;
        double success_rate = all_class_rate[j];
        CLog::log(LogKimbo, LogWarn, "[CRobotAi] directory end %s %f!\n", CTypeTransform::aiLable2String(current_label).c_str(), success_rate);
    }
    printf("class count:%d success count:%d", class_count, success_count);
    //读取文件路径
    // std::string directory = "/tmp/wire";
    // std::vector<std::string> files_list;
    // if(readDirFileList(directory.c_str(), files_list, true))
    // {
    //     CLog::log(LogKimbo, LogWarn, "[CRobotAi] directory files_list size is %d!\n", files_list.size());
    // }
    // int sucess_times = 0;
    // for(size_t i = 0; i < files_list.size(); i++)
    // {
    //     //执行模型，输出结果
    //     CImage floor_image = m_current_image;
    //     std::string name = files_list[i];
    //     std::cout << i << " name " << name << std::endl;
    //     cv::Mat image_read = m_image_log->readDebugImage(name);
    //     floor_image.setImage(image_read);
    //     TAIObejectDetectData detect_data;
    //     m_classification.classification(floor_image, detect_data);
    //     // CLog::log(LogKimbo, LogNormal, "[CRobotAi] floor class is %d %s !\n", detect_data.obj_class,
    //     //                                                 CTypeTransform::aiObjectClass2String(detect_data.obj_class).c_str());

    //     if(detect_data.obj_class == AI_OBJECT_WIRE)
    //     {
    //         sucess_times++;
    //     }
    //     // CLog::log(LogKimbo, LogWarn, "[CRobotAi] detect end success_rate is %f, %d, %d!\n", (double)sucess_times / i, sucess_times, i);

    // }

    // double success_rate = (double)sucess_times / files_list.size();

    // CLog::log(LogKimbo, LogWarn, "[CRobotAi] detect end success_rate is %f, %d, %d!\n", success_rate, sucess_times, files_list.size());
    while (1)
    {
        ;
    }
}
bool CRobotAi::readDirFileList(const char *directory, std::vector<std::string> &files_list, std::vector<std::string> &files_name_list, bool recursion)
{
    DIR *dir;
    struct dirent *ptr;
    char base[1000];
    const char *base_path = directory;

    if ((dir = opendir(base_path)) == NULL)
    {
        CLog::log(LogKimbo, LogWarn, "[CFileSystem]Can not open directory %s !\n", directory);
        return false;
    }

    while ((ptr = readdir(dir)) != NULL)
    {
        if (strcmp(ptr->d_name, ".") == 0 || strcmp(ptr->d_name, "..") == 0)
        {
            /* Current dir OR parrent dir */
            continue;
        }
        else if (ptr->d_type == 8)
        {
            /* File */
            std::string str = evformat("%s/%s", base_path, ptr->d_name);
            std::string str_name = evformat("%s", ptr->d_name);
            std::cout << "ori str :" << str_name << std::endl;
            std::string name_str = str_name.replace(str_name.find(".jpg"), 4, "");
            std::cout << "after replaced str :" << name_str << std::endl;
            files_name_list.push_back(name_str);
            files_list.push_back(str);
        }
        else if (ptr->d_type == 10)
        {
            /* Link file */
        }
        else if (ptr->d_type == 4)
        {
            /* Directory */
            if (recursion)
            {
                memset(base, '\0', sizeof(base));
                strcpy(base, base_path);
                strcat(base, "/");
                strcat(base, ptr->d_name);
                readDirFileList(base, files_list, files_name_list, true);
            }
        }
    }
    closedir(dir);
    return true;
}

/***********************************************************************************
Function:     invalidImageTest
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::invalidImageTest()
{
    std::string time_stamp = CTime::getTimeString();
    std::string image_name = time_stamp + ".jpg";

    base::TTimeStamp start_fiter_time = CTime::getCpuTime();
    bool valid = imgIsValid(m_current_image.getImage());
    base::TTimeStamp end_fiter_time = CTime::getCpuTime();
    long detect_take_time = 1000 * CTime::timeDifference(start_fiter_time, end_fiter_time);
    CLog::log(LogKimbo, LogNormal, "==>image valid filter take time: %ldms!\n", detect_take_time);

    if (valid)
    {
        std::string valid_name = "/tmp/light_test/valid/" + image_name;
        cv::imwrite(valid_name, m_current_image.getImage());
    }
    else
    {
        std::string in_valid_name = "/tmp/light_test/invalid/" + image_name;
        cv::imwrite(in_valid_name, m_current_image.getImage());
    }
}

/***********************************************************************************
Function:     img_filter
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::imgIsValid(cv::Mat origin_img)
{

    bool is_valid = true;
    cv::Mat img;
    cv::Mat channels[3];
    resize(origin_img.clone(), img, cv::Size(64, 64), 0, 0);
    cv::cvtColor(img, img, cv::COLOR_BGR2HSV);
    cv::split(img, channels);
    int bright_sum = cv::sum(channels[2])[0];
    if (bright_sum < 90000)
        is_valid = false;

    return is_valid;
}

/***********************************************************************************
Function:     isTwoFrameNearlySame
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::isTwoFrameNearlySame(cv::Mat frame1, cv::Mat frame2)
{
    bool is_valid = true;
    cv::Mat img_one;
    resize(frame1.clone(), img_one, cv::Size(64, 64), 0, 0);
    cvtColor(img_one, img_one, cv::COLOR_RGB2GRAY);

    cv::Mat img_two;
    resize(frame2.clone(), img_two, cv::Size(64, 64), 0, 0);
    cvtColor(img_two, img_two, cv::COLOR_RGB2GRAY);

    cv::Mat diff_mat = img_two - img_one;
    // cv::Mat diff_mat = frame1 - frame2;
    cv::Scalar mean;                        //均值
    cv::Scalar stddev;                      //标准差
    cv::meanStdDev(diff_mat, mean, stddev); //计算均值和标准差
    double mean_pxl = mean.val[0];
    double stddev_pxl = stddev.val[0];
    // std::cout << " mean_pxl : "<<mean_pxl<< std::endl;
    // std::cout << " stddev_pxl : "<<stddev_pxl<< std::endl;

    return stddev_pxl < 10;
}

/***********************************************************************************
Function:     isTwoDetectInfoNearlySame
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::isTwoDetectInfoNearlySame(TAIObejectDetectData obj_info1, TAIObejectDetectData obj_info2)
{
    float last_detect_image_area = obj_info1.detect_img.rows * obj_info1.detect_img.cols;
    float now_detect_image_area = obj_info2.detect_img.rows * obj_info2.detect_img.cols;
    float aspatio = last_detect_image_area / now_detect_image_area;
    bool is_two_upload_area_similar = (aspatio > 0.95 && aspatio < 1.05);
    // std::cout << "apation is ...."<< aspatio << std::endl;
    // std::cout << "obj_info1.obj_class is ...."<< obj_info1.obj_class << std::endl;
    // std::cout << "obj_info2.obj_class is ...."<< obj_info2.obj_class << std::endl;
    return obj_info1.obj_class == obj_info2.obj_class && is_two_upload_area_similar;
}

/***********************************************************************************
Function:     processTheCurrentUploadDetectImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processTheCurrentUploadDetectImage()
{
    if (m_result_object.size() > 0)
    {
        m_need_upload_detect_imgage = true;
        TAIObejectDetectData first_detect_obj = m_result_object[0];
        if (first_detect_obj.obj_class == AI_FLOOR_WOOD || first_detect_obj.obj_class == AI_FLOOR_TITLE)
        {
            m_upload_detect_floor_count++;
            if (m_upload_detect_floor_count != m_upload_detect_floor_count_limit)
            {
                // std::cout << "floor upload count are not suit "<<std::endl;
                m_need_upload_detect_imgage = false;
                return m_need_upload_detect_imgage;
            }
            else
            {
                // std::cout << "floor upload count are suit "<<std::endl;
                m_upload_detect_floor_count = 0;
            }
            if (isTheSameWithLatestUploadDetectImages(first_detect_obj, true))
            {
                // std::cout << "floor are similar "<<std::endl;
                m_need_upload_detect_imgage = false;
                return m_need_upload_detect_imgage;
            }
        }
        else
        {
            m_upload_detect_obj_count++;
            if (m_upload_detect_obj_count != m_upload_detect_obj_count_limit)
            {
                // std::cout << "obj upload count are not suit "<<std::endl;
                m_need_upload_detect_imgage = false;
                return m_need_upload_detect_imgage;
            }
            else
            {
                // std::cout << "obj upload count are suit "<<std::endl;
                m_upload_detect_obj_count = 0;
            }
            base::TTimeStamp start_time = CTime::getCpuTime();
            if (isTheSameWithLatestUploadDetectImages(first_detect_obj, false))
            {
                // std::cout << "obj are similar "<<std::endl;
                m_need_upload_detect_imgage = false;
                return m_need_upload_detect_imgage;
            }
            long image_compare_time = 1000 * CTime::timeDifference(start_time, CTime::getCpuTime());
            // std::cout << "image compare spend ..................."<<image_compare_time<<std::endl;
        }
        if (m_need_upload_detect_imgage)
        {
            // cv::Mat em;
            // g_debug_image_log.saveDetectObjectImage(first_detect_obj, first_detect_obj.detect_img, em);
            std::cout << "detect frame are suit upload ================>" << std::endl;
            if (m_last_upload_detect_images.size() < m_upload_detect_image_different_count_limit)
            {
                m_last_upload_detect_images.push_back(first_detect_obj);
            }
            else
            {
                m_last_upload_detect_images.pop_front();
                m_last_upload_detect_images.push_back(first_detect_obj);
            }
        }
    }
    else
    {
        m_need_upload_detect_imgage = false;
    }
    return m_need_upload_detect_imgage;
}

/***********************************************************************************
Function:     isTheSameWithLatestUploadImages
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::isTheSameWithLatestUploadDetectImages(TAIObejectDetectData detect_obj, bool is_floor)
{
    if (m_last_upload_detect_images.empty())
    {
        return false;
    }
    list<TAIObejectDetectData>::iterator itor;
    itor = m_last_upload_detect_images.begin();
    while (itor != m_last_upload_detect_images.end())
    {
        TAIObejectDetectData lastest_upload_obj = *itor++;

        if (!is_floor)
        {
            if (isTwoDetectInfoNearlySame(detect_obj, lastest_upload_obj))
            {
                return true;
            }
        }

        if (detect_obj.obj_class == lastest_upload_obj.obj_class && isTwoFrameNearlySame(detect_obj.detect_img, lastest_upload_obj.detect_img))
        {
            return true;
        }
    }
    return false;
}

/***********************************************************************************
Function:     processTheCurrentUploadImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::processTheCurrentUploadImage(cv::Mat frame)
{
    bool is_the_same_with_latest_upload_image = isTheSameWithLatestUploadImages(frame);
    if (!is_the_same_with_latest_upload_image)
    {
        if (m_last_upload_images.size() < m_upload_image_different_count_limit)
        {
            m_last_upload_images.push_back(frame.clone());
        }
        else
        {
            m_last_upload_images.pop_front();
            m_last_upload_images.push_back(frame.clone());
        }
    }
    return is_the_same_with_latest_upload_image;
}

/***********************************************************************************
Function:     isTheSameWithLatestUploadImages
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotAi::isTheSameWithLatestUploadImages(cv::Mat frame)
{
    if (m_last_upload_images.empty())
    {
        return false;
    }
    list<cv::Mat>::iterator itor;
    itor = m_last_upload_images.begin();
    while (itor != m_last_upload_images.end())
    {
        cv::Mat lastest_upload_mat = *itor++;
        if (isTwoFrameNearlySame(lastest_upload_mat, frame))
        {
            return true;
        }
    }
    return false;
}

/***********************************************************************************
Function:     coverRectMat
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
cv::Mat CRobotAi::coverRectMat(cv::Mat img)
{
    cv::Mat resize_mat;
    cv::resize(img.clone(), resize_mat, cv::Size(320, 180));
    cv::cvtColor(resize_mat, resize_mat, cv::COLOR_BGR2GRAY);
    int h_base = 18;
    int w_base = 32;
    int height, width;
    height = resize_mat.rows;
    width = resize_mat.cols;

    int height_div = height / h_base;
    int width_div = width / w_base;
    cv::Mat rec_mat = cv::Mat::zeros(h_base, w_base, CV_8UC1);
    for (int i = 0; i < height; i += height_div)
    {
        for (int j = 0; j < width; j += width_div)
        {
            cv::Mat subimg = resize_mat(cv::Rect(j, i, width_div, height_div));
            cv::Scalar sum_pixel = cv::sum(subimg);
            if (sum_pixel[0] < 3000)
            {
                int m = i / height_div;
                int n = j / width_div;
                rec_mat.at<uchar>(m, n) = 1;
            }
        }
    }

    rec_mat.convertTo(rec_mat, CV_32FC1);
    return rec_mat;
}

/***********************************************************************************
Function:     processImgCoverLogic
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotAi::processImgCoverLogic(cv::Mat current_mat)
{
    if (m_is_camera_covered)
    {
        return;
    }

    if (m_last_cover_detect_image.empty())
    {
        m_camera_cover_frame_count = 1;
        m_last_cover_detect_image = current_mat.clone();
        return;
    }

    bool is_cover = false;
    cv::Mat img1 = current_mat.clone();
    cv::Mat img2 = m_last_cover_detect_image.clone();

    cv::Mat rec_mat1 = coverRectMat(img1);
    cv::Mat rec_mat2 = coverRectMat(img2);

    cv::Mat diff_mat = rec_mat1 - rec_mat2;
    cv::Mat cheng_mat = diff_mat.mul(diff_mat);
    double cover_diff = cv::mean(cheng_mat).val[0];

    float mat1_cover_rate = cv::mean(rec_mat1).val[0];
    float mat2_cover_rate = cv::mean(rec_mat2).val[0];

    //    std::cout<< "cover_rate_1 is:"<<mat1_cover_rate << std::endl;
    //    std::cout<< "cover_rate_2 is:"<<mat2_cover_rate << std::endl;
    //    std::cout<< "cover_intersect is:"<<cover_diff << std::endl;

    if (mat1_cover_rate > 0.2 && mat2_cover_rate > 0.2)
    {
        //   std::cout<< "cover_rate suit " << std::endl;
        if (cover_diff < 0.1)
        {
            // std::cout<< "cover_intersect suit " << std::endl;
            m_camera_cover_frame_count++;
            if (m_camera_cover_frame_count == 100)
            {
                base::TTimeStamp cover_time = CTime::getCpuTime();
                m_camera_cover_frame_count = 0;
                m_is_camera_covered = true;
                // std::cout<< "camera is covered................................" << std::endl;
                CLog::log(LogKimbo, LogNormal, "camera is covered................................!\n");
                CLog::log(LogKimbo, LogNormal, "camera camera time: %ldms!\n", cover_time / 10000);
                // std::string coverd_save_img_name = "/tmp/cover_suit_" + to_string((int)(mat1_cover_rate*1000)) + ".jpg";
                std::string coverd_save_img_name = "/tmp/cover_camera.jpg";
                cv::imwrite(coverd_save_img_name.c_str(), current_mat);
            }
        }
        else
        {
            //  std::cout<< "cover_intersect not suit " << std::endl;
            m_last_cover_detect_image = current_mat.clone();
        }
    }
    else
    {
        //    std::cout<< "cover_rate not suit " << std::endl;
        m_last_cover_detect_image = current_mat.clone();
    }
}

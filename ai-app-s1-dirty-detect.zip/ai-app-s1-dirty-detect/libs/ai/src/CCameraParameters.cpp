/**********************************************************************************
File name:	  CCameraParameters.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CCameraParameters.h>
#include <everest/hwdrivers/CCameraSensor.h>
#include <everest/base/CConfigFile.h>
#include <everest/base/CFilePath.h>


/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::hwdrivers;
using namespace everest::ai;

/***********************************************************************************
Function:     CCameraParameters
Description:  The constructor of camera parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CCameraParameters::CCameraParameters():
							m_origin_width(960),
							m_origin_height(540),
							m_croped_width(642),
							m_croped_heigt(362)
{
	//yellow machine,remap->crop
	// m_f_x = 324.62012;
	// m_f_y = 323.13147;
	// m_c_x = 476.96635;
	// m_c_y = 261.45504;
	// m_k1 = 0.00480;
	// m_k2 = 0.51538;
	// m_p1 = -0.74585;
	// m_p2 = 0.46538;

	//black machine 1,crop->remap
	// m_f_x = 375.11262;
	// m_f_y = 374.93162;
	// m_c_x = 290.12335;
	// m_c_y = 167.25965;
	// m_k1 = 0.04426;
	// m_k2 = 0.36288;
	// m_p1 = -0.76700;
	// m_p2 = 0.60272;

	//black machine 2,crop->remap
	m_f_x = 315.61342;
	m_f_y = 314.94732;
	m_c_x = 324.39907;
	m_c_y = 178.82170;
	m_k1 = 0.11022;
	m_k2 = 0.0642387;
	m_p1 = -0.0778461;
	m_p2 = 0.0497042;
	loadCameraParams();

	// loadFromConfigFile();
}

/***********************************************************************************
Function:     ~CCameraParameters
Description:  The destructor of camera parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CCameraParameters::~CCameraParameters()
{
    
}

/***********************************************************************************
Function:     loadCameraParams
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CCameraParameters::loadCameraParams()
{
	cv::Mat cameraMatrix = cv::Mat::eye(3, 3, CV_64F);
	cv::Mat distCoeffs = cv::Mat::zeros(4, 1, CV_64F);
	cv::Mat R = cv::Mat::eye(3, 3, CV_32F);

    double x_scale = 1.0; //m_origin_width / 224;
    double y_scale = 1.0; //m_origin_height / 172;

    cameraMatrix.at<double>(0, 0) = m_f_x * x_scale;
    cameraMatrix.at<double>(1, 1) = m_f_y * y_scale;
    cameraMatrix.at<double>(0, 2) = m_c_x * x_scale;
    cameraMatrix.at<double>(1, 2) = m_c_y * y_scale;
    cameraMatrix.at<double>(2, 2) = 1;

    distCoeffs.at<double>(0, 0) = m_k1;
    distCoeffs.at<double>(1, 0) = m_k2;
    distCoeffs.at<double>(2, 0) = m_p1;
    distCoeffs.at<double>(3, 0) = m_p2;

	cv::Size imageSize(SC_CAMERA_CROPED_WIDTH, SC_CAMERA_CROPED_HEIGHT);

	cv::fisheye::initUndistortRectifyMap(cameraMatrix, distCoeffs, R,
				cameraMatrix, imageSize, CV_32FC1, m_mapx, m_mapy);
	
	return true;
}
/***********************************************************************************
Function:     saveFromConfigFile
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CCameraParameters::saveFromConfigFile()
{
	
	std::string path = everest::base::CFilePath::getCameraParametersConfigFilePath();
	std::cout << " saveFromConfigFile  " << path << std::endl;
	everest::base::CConfigFile config_file;
	
	config_file.addContext(m_f_x, "m_f_x");
	config_file.addContext(m_f_y, "m_f_y");
	config_file.addContext(m_c_x, "m_c_x");
	config_file.addContext(m_c_y, "m_c_y");
	config_file.addContext(m_k1,  "m_k1");
	config_file.addContext(m_k2,  "m_k2");
	config_file.addContext(m_p1,  "m_p1");
	config_file.addContext(m_p2,  "m_p2");
	config_file.addContext(m_f_x, "m_f_x");
	config_file.addContext(m_f_x, "m_f_x");
	config_file.addContext(m_f_x, "m_f_x");

	config_file.addContext(m_origin_width,  "m_origin_width");
	config_file.addContext(m_origin_height, "m_origin_height");
	config_file.addContext(m_croped_width, "m_croped_width");
	config_file.addContext(m_croped_heigt, "m_croped_heigt");
	if(!config_file.saveFileContext(path))
	{
		std::cout << " not  " << path << " fail!!" << std::endl;
	}
}
/***********************************************************************************
Function:     loadFromConfigFile
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CCameraParameters::loadFromConfigFile()
{
	std::string path = everest::base::CFilePath::getCameraParametersConfigFilePath();
	everest::base::CConfigFile config_file;
	std::cout << " loadFromConfigFile  " << path << std::endl;
	std::cout << " ------------------start----------------------  " << std::endl;
	if(config_file.readFileContext(path))
	{
		bool ret = true;
		ret &= config_file.loadConfigValueDouble(m_f_x, "m_f_x");
		ret &= config_file.loadConfigValueDouble(m_f_y, "m_f_y");
		ret &= config_file.loadConfigValueDouble(m_c_x, "m_c_x");
		ret &= config_file.loadConfigValueDouble(m_c_y, "m_c_y");
		ret &= config_file.loadConfigValueDouble(m_k1,  "m_k1");
		ret &= config_file.loadConfigValueDouble(m_k2,  "m_k2");
		ret &= config_file.loadConfigValueDouble(m_p1,  "m_p1");
		ret &= config_file.loadConfigValueDouble(m_p2,  "m_p2");

		ret &= config_file.loadConfigValueInt(m_origin_width,  "m_origin_width");
		ret &= config_file.loadConfigValueInt(m_origin_height, "m_origin_height");
		ret &= config_file.loadConfigValueInt(m_croped_width, "m_croped_width");
		ret &= config_file.loadConfigValueInt(m_croped_heigt, "m_croped_heigt");

		std::cout << " load  " << path << " sucess!!" << std::endl;
		std::cout << " m_f_x  " << m_f_x <<  std::endl;
		std::cout << " m_f_y  " << m_f_y <<  std::endl;
		std::cout << " m_c_x  " << m_c_x <<  std::endl;
		std::cout << " m_c_y  " << m_c_y <<  std::endl;
		std::cout << " m_k1  " << m_k1 <<  std::endl;
		std::cout << " m_k2  " << m_k2 <<  std::endl;
		std::cout << " m_p1  " << m_p1 <<  std::endl;
		std::cout << " m_p2  " << m_p2 <<  std::endl;
		std::cout << " m_origin_width  " << m_origin_width <<  std::endl;
		std::cout << " m_origin_height  " << m_origin_height <<  std::endl;
		std::cout << " m_croped_width  " << m_croped_width <<  std::endl;
		std::cout << " m_croped_heigt  " << m_croped_heigt <<  std::endl;
		std::cout << " ------------------end----------------------  " << std::endl;
		return ret;
	}
	else
	{
		saveFromConfigFile();
	}
	
}
/**********************************************************************************
File name:	  CObjectDetector.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CObjectDetector.h>
#include <everest/base/CTime.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;
/***********************************************************************************
Function:     CObjectDetector
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CObjectDetector::CObjectDetector()
{
	
}

/***********************************************************************************
Function:     ~CObjectDetector
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CObjectDetector::~CObjectDetector()
{
    
}

/***********************************************************************************
Function:     ~detectModelAreOk
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CObjectDetector::detectModelAreOk()
{
 //   return m_yolo3_detector.yoloModelInitOk();
}

bool CObjectDetector::detectNanoOk()
{
    return m_nanoDet.NanoInitOk();
}

/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CObjectDetector::detectObject(CImage &input_image,
                                   std::vector<TAIObejectDetectData> &object)
{   

    base::TTimeStamp yolo_first_behand_process_data_time = CTime::getCpuTime();
    cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();
//    cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);
    // printf("time-statics===YoloBeforeHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(yolo_first_behand_process_data_time,  CTime::getCpuTime()));
    // if(m_yolo3_detector.runYoloDector(src_image, object))
    // {        
    //     return true;
    // }
    // else
    // {
    //     return false;
    // }
}


/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CObjectDetector::detectObject_Nano(CImage &input_image,
                                   std::vector<TAIObejectDetectData> &object)
{   

    base::TTimeStamp yolo_first_behand_process_data_time = CTime::getCpuTime();
    cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();

    if(m_nanoDet.runNanoDector(src_image, object))
    {
        return true;
    }
    else
    {
        return false;
    }
}

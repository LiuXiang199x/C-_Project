/**********************************************************************************
File name:	  CEfficientNetClassification.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
    1. Date:
    Author: Kimbo
    Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/mobilenetv2.h>
#include <everest/ai/CTypeTransform.h>
#include <everest/base/CTime.h>

#define HAS_SOFT_MAX 1
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;

static void mat_print(const cv::Mat &m)
{
    for (int c = 0; c < 3; c++)
    {
        for (int y = 0; y < 5; y++)
        {
            for (int x = 0; x < 5; x++)
            {
                int pix = m.at<cv::Vec3b>(y, x)[c];
                printf("%d ", pix);
            }
            printf("\n");
        }
        printf("------------------------\n");
    }
}

std::vector<int> mobilenetv2::get_bdbox(float min_x, float min_y, float max_x, float max_y)
{
    float scale = 1.2;
    bool is_square = true;
    std::string short_long = "long";
    float width = max_x - min_x;
    float height = max_y - min_y;
    float bd_length = std::max(width, height) * scale;
    float bd_min_x = int((min_x + max_x) / 2 - bd_length / 2);
    float bd_min_y = int((min_y + max_y) / 2 - bd_length / 2);
    float new_width, new_height;
    new_width = new_height = int(bd_length);
    std::vector<int> vectxy{bd_min_x, bd_min_y, new_width, new_height};
    return vectxy;
}

/***********************************************************************************
Function:     CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
mobilenetv2::mobilenetv2() : m_model(NULL),
                             m_network_input_width(112),
                             m_network_input_height(112),
                             m_top_n_result(2),
                             m_min_score(0.01),
                             m_model_path("/userdata/AI/mobilenet.rknn")
{
    // m_model_path = "/userdata/AI/all_class_model.rknn";
    // m_class_model_type = CLASS_MODLE_TYPE_ALL;
    m_init_success = initmobilenetv2();
}

/***********************************************************************************
Function:     CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
mobilenetv2::mobilenetv2(
    int network_input_width,
    int network_input_height,
    std::string model_path) : m_model(NULL),
                              m_top_n_result(2),
                              m_min_score(0.01)
{

    // m_network_input_width = network_input_width;
    // m_network_input_height = network_input_height;
    // m_model_path = model_path;
    // m_init_success = initmobilenetv2();
}

/***********************************************************************************
Function:     ~CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
mobilenetv2::~mobilenetv2()
{
    if (m_ctx >= 0)
    {
        rknn_destroy(m_ctx);
    }

    if (m_model)
    {
        free(m_model);
    }
}

/***********************************************************************************
Function:     loadModel
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
unsigned char *mobilenetv2::loadModel(const char *filename, int *model_size)
{
    FILE *fp = fopen(filename, "rb");
    if (fp == nullptr)
    {
        printf("fopen %s fail!\n", filename);
        return NULL;
    }

    fseek(fp, 0, SEEK_END);

    int model_len = ftell(fp);
    unsigned char *model = (unsigned char *)malloc(model_len);

    fseek(fp, 0, SEEK_SET);

    if (model_len != fread(model, 1, model_len, fp))
    {
        printf("fread %s fail!\n", filename);
        free(model);
        return NULL;
    }

    *model_size = model_len;

    if (fp)
    {
        fclose(fp);
    }

    return model;
}

/***********************************************************************************
Function:     printRKNNTensor
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void mobilenetv2::printRKNNTensor(rknn_tensor_attr *attr)
{
    printf("index=%d name=%s n_dims=%d dims=[%d %d %d %d] n_elems=%d size=%d fmt=%d \
			type=%d qnt_type=%d fl=%d zp=%d scale=%f\n",
           attr->index, attr->name, attr->n_dims, attr->dims[3], attr->dims[2], attr->dims[1], attr->dims[0],
           attr->n_elems, attr->size, 0, attr->type, attr->qnt_type, attr->fl, attr->zp, attr->scale);
}

/***********************************************************************************
Function:     initEfficientNet
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool mobilenetv2::initmobilenetv2()
{
    char *m_model_path = "/userdata/AI/mv2.rknn";
    // const char *m_model_path = m_model_path;
    int model_len = 0;

    m_model = loadModel(m_model_path, &model_len);

    if (m_model == NULL)
    {
        printf("efficient_net model load failed\n");
        return false;
    }
    else
    {
        printf("load model %s successed\n", m_model_path);
    }

    int ret = rknn_init(&m_ctx, m_model, model_len, 0);

    if (ret < 0)
    {
        printf("rknn_init mobilenet fail! ret=%d\n", ret);
        return false;
    }

    ret = rknn_query(m_ctx, RKNN_QUERY_IN_OUT_NUM,
                     &m_io_num, sizeof(m_io_num));

    if (ret != RKNN_SUCC)
    {
        printf("rknn_query fail! ret_mobilenet=%d\n", ret);
        return false;
    }

    printf("model_cls input num: %d, output num: %d\n",
           m_io_num.n_input, m_io_num.n_output);

    printf("input tensors:\n");

    memset(m_input_attrs, 0, sizeof(m_input_attrs));

    for (int i = 0; i < m_io_num.n_input; i++)
    {
        m_input_attrs[i].index = i;
        ret = rknn_query(m_ctx, RKNN_QUERY_INPUT_ATTR,
                         &(m_input_attrs[i]), sizeof(rknn_tensor_attr));

        if (ret != RKNN_SUCC)
        {
            printf("rknn_query mobilenet fail! ret=%d\n", ret);
            return false;
        }
        printRKNNTensor(&(m_input_attrs[i]));
    }

    memset(m_output_attrs, 0, sizeof(m_output_attrs));
    for (int i = 0; i < m_io_num.n_output; i++)
    {
        m_output_attrs[i].index = i;
        ret = rknn_query(m_ctx, RKNN_QUERY_OUTPUT_ATTR,
                         &(m_output_attrs[i]), sizeof(rknn_tensor_attr));

        if (ret != RKNN_SUCC)
        {
            printf("rknn_query mobilenet fail! ret=%d\n", ret);
            return false;
        }
        printRKNNTensor(&(m_output_attrs[i]));
    }

    printf("initial mobilenet-net successfully!!!\n");

    return true;
}

/***********************************************************************************
Function:     getTopN
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void mobilenetv2::getTopN(float *prediction, int prediction_size, size_t num_results,
                          float threshold, std::vector<std::pair<float, int>> *top_results,
                          bool input_floating)
{
    // Will contain top N results in ascending order.
    std::priority_queue<std::pair<float, int>, std::vector<std::pair<float, int>>,
                        std::greater<std::pair<float, int>>>
        top_result_pq;

    const long count = prediction_size;

    for (int i = 0; i < count; ++i)
    {
        // std::cout << " i is " << i << " prediction is " << prediction[i] << std::endl;
        float value;
        if (input_floating)
        {
            value = prediction[i];
        }
        else
        {
            value = prediction[i] / 255.0;
        }

        // Only add it if it beats the threshold and has a chance at being in
        // the top N.
        // if (value < m_ai_parameter.getAiObjectClassSorceThreshold(CTypeTransform::aiLable2AiObjectClass((AIAllClassLabel)i)))
        if (value < threshold)
        {
            continue;
        }

        top_result_pq.push(std::pair<float, int>(value, i));

        // If at capacity, kick the smallest value out.
        if (top_result_pq.size() > num_results)
        {
            top_result_pq.pop();
        }
    }

    // Copy to output vector and reverse into descending order.
    while (!top_result_pq.empty())
    {
        top_results->push_back(top_result_pq.top());
        top_result_pq.pop();
    }

    std::reverse(top_results->begin(), top_results->end());
}

/***********************************************************************************
Function:     activation_function_softmax
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void mobilenetv2::activation_function_softmax(float *src, float *dst, int length)
{
    float max = *std::max_element(src, src + length);
    float sum = 0;

    for (int i = 0; i < length; ++i)
    {
        dst[i] = std::exp(src[i] - max);
        sum += dst[i];
    }

    for (int i = 0; i < length; ++i)
    {
        dst[i] /= sum;
        // printf("src = %.2f, dest = %.2f\n", src[i],dst[i]);
    }
}

int mobilenetv2::rknn_GetTop(
    float *pfProb,
    float *pfMaxProb,
    uint32_t *pMaxClass,
    uint32_t outputCount,
    uint32_t topNum)
{
    uint32_t i, j;

#define MAX_TOP_NUM 20
    if (topNum > MAX_TOP_NUM)
        return 0;

    memset(pfMaxProb, 0, sizeof(float) * topNum);
    memset(pMaxClass, 0xff, sizeof(float) * topNum);

    for (j = 0; j < topNum; j++)
    {
        for (i = 0; i < outputCount; i++)
        {
            if ((i == *(pMaxClass + 0)) || (i == *(pMaxClass + 1)) || (i == *(pMaxClass + 2)) ||
                (i == *(pMaxClass + 3)) || (i == *(pMaxClass + 4)))
            {
                continue;
            }

            if (pfProb[i] > *(pfMaxProb + j))
            {
                *(pfMaxProb + j) = pfProb[i];
                *(pMaxClass + j) = i;
            }
        }
    }

    return 1;
}

/***********************************************************************************
Function:     runEfficientNetClassifiaction
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool mobilenetv2::runmobilenetv2Classifiaction(cv::Mat &src_img,
                                               TAIObejectDetectData &result)
{
    base::TTimeStamp class_second_behand_process_data_time = CTime::getCpuTime();
    if (src_img.empty() || src_img.cols == 0 || src_img.rows == 0)
    {
        return false;
    }

    if (!m_init_success)
    {
        return false;
    }

    cv::Mat orig_img = src_img;
    cv::Mat img = orig_img.clone();

    std::vector<float> bbox{result.detect_x1, result.detect_y1, result.detect_x2, result.detect_y2};
    std::cout << "classify box : " << result.detect_x1 << " " << result.detect_y1 << " " << result.detect_x2 << " " << result.detect_y2 << std::endl;
    //   std::vector<float> bbox{263,230,334,250};

    std::vector<int> box = get_bdbox(bbox[0], bbox[1], bbox[2], bbox[3]);

    int bd_min_x = box[0];
    int bd_min_y = box[1];
    int bd_width = box[2];
    int bd_height = box[3];

    std::cout << bd_min_x << " " << bd_min_y << " " << bd_width << " " << bd_height << std::endl;

    cv::Mat img_border;
    cv::copyMakeBorder(img, img_border, bd_height, bd_height, bd_width, bd_width, cv::BORDER_CONSTANT);

    cv::Mat detMat = img_border(cv::Rect(bd_width + bd_min_x, bd_height + bd_min_y, bd_width, bd_height));

    //   mat_print(detMat);

    if (detMat.cols != m_network_input_width || detMat.rows != m_network_input_height)
    {
        printf("resize %d %d to %d %d\n", detMat.cols, detMat.rows, m_network_input_width, m_network_input_height);
        cv::resize(detMat, detMat, cv::Size(m_network_input_width, m_network_input_height), (0, 0), (0, 0), cv::INTER_LINEAR);
    }

    //    mat_print(detMat);

    cv::cvtColor(detMat, detMat, cv::COLOR_BGR2RGB);

    // Get Model Input Output Info
    // rknn_input_output_num io_num;
    // ret = rknn_query(m_ctx, RKNN_QUERY_IN_OUT_NUM, &io_num, sizeof(io_num));
    // if (ret != RKNN_SUCC) {
    //     printf("rknn_query fail! ret=%d\n", ret);
    //     return -1;
    // }
    // printf("model input num: %d, output num: %d\n", io_num.n_input, io_num.n_output);

    // printf("input tensors:\n");
    // rknn_tensor_attr input_attrs[io_num.n_input];
    // memset(input_attrs, 0, sizeof(input_attrs));
    // for (int i = 0; i < io_num.n_input; i++) {
    //     input_attrs[i].index = i;
    //     ret = rknn_query(m_ctx, RKNN_QUERY_INPUT_ATTR, &(input_attrs[i]), sizeof(rknn_tensor_attr));
    //     if (ret != RKNN_SUCC) {
    //         printf("rknn_query fail! ret=%d\n", ret);
    //         return -1;
    //     }
    //     printRKNNTensor(&(input_attrs[i]));
    // }

    // printf("output tensors:\n");
    // rknn_tensor_attr output_attrs[io_num.n_output];
    // memset(output_attrs, 0, sizeof(output_attrs));
    // for (int i = 0; i < io_num.n_output; i++) {
    //     output_attrs[i].index = i;
    //     ret = rknn_query(m_ctx, RKNN_QUERY_OUTPUT_ATTR, &(output_attrs[i]), sizeof(rknn_tensor_attr));
    //     if (ret != RKNN_SUCC) {
    //         printf("rknn_query fail! ret=%d\n", ret);
    //         return -1;
    //     }
    //     printRKNNTensor(&(output_attrs[i]));
    // }

    // Set Input Data
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].size = detMat.cols * detMat.rows * detMat.channels();
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = detMat.data;

    int ret = rknn_inputs_set(m_ctx, m_io_num.n_input, inputs);
    if (ret < 0)
    {
        printf("rknn_input_set fail! ret=%d\n", ret);
        return -1;
    }

    // Run
    printf("rknn_run\n");
    ret = rknn_run(m_ctx, nullptr);
    if (ret < 0)
    {
        printf("rknn_run fail! ret=%d\n", ret);
        return -1;
    }

    // Get Output
    rknn_output outputs[1];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 1;
    ret = rknn_outputs_get(m_ctx, 1, outputs, NULL);
    if (ret < 0)
    {
        printf("rknn_outputs_get fail! ret=%d\n", ret);
        return -1;
    }

    // Post Process
    for (int i = 0; i < m_io_num.n_output; i++)
    {
        uint32_t MaxClass[5];
        float fMaxProb[5];
        float *buffer = (float *)outputs[i].buf;
        uint32_t sz = outputs[i].size / 4;

        rknn_GetTop(buffer, fMaxProb, MaxClass, sz, 5);

        printf(" --- Top5 ---\n");
        for (int i = 0; i < 5; i++)
        {
            printf("%3d: %8.6f\n", MaxClass[i], fMaxProb[i]);
        }

        int label = MaxClass[0];
        float score = fMaxProb[0];
        result.dirty_class = (TAIObjectClass)(1039 + label);

        std::cout << "......classfiy image label:" << label << std::endl;
        if (label == 1)
        {
            result.obj_class = AI_OBJECT_SOCKS;
        }
        else if (label == 2)
        {
            result.obj_class = AI_OBJECT_SHOE;
        }
        else if (label == 3)
        {
            result.obj_class = AI_OBJECT_WIRE;
        }
        else
        {
            result.obj_class = AI_OBJECT_NOTHING;
        }
        //     result.obj_class=AI_OBJECT_WIRE;
    }

    // Release rknn_outputs
    rknn_outputs_release(m_ctx, 1, outputs);

    // if(orig_img.cols != m_network_input_width ||
    //    orig_img.rows != m_network_input_height)
    // {
    //     cv::resize(orig_img, img, cv::Size(m_network_input_width,
    //                m_network_input_height), (0, 0), (0, 0), cv::INTER_LINEAR);

    //     // std::string origin_image_path = "/tmp/AI/test/" + CTime::getTimeString() + "_origin.jpg";
    //     // std::string detect_image_path = "/tmp/AI/test/" + CTime::getTimeString() + "_detect.jpg";
    //     // cv::imwrite(origin_image_path, orig_img);
    //     // cv::imwrite(detect_image_path, img);
    // }

    // // Set Input Data
    // rknn_input inputs[1];
    // memset(inputs, 0, sizeof(inputs));
    // inputs[0].index = 0;
    // inputs[0].type = RKNN_TENSOR_UINT8;//图片数据类型
    // inputs[0].size = img.cols*img.rows*img.channels();
    // inputs[0].fmt = RKNN_TENSOR_NHWC;
    // inputs[0].buf = img.data;
    // // printf("rknn_inputs_set\n");
    // int ret = rknn_inputs_set(m_ctx, m_io_num.n_input, inputs);
    // if(ret < 0)
    // {
    //     printf("rknn_input_set fail! ret=%d\n", ret);
    //     return false;
    // }
    // // printf("time-statics===ClassBeforeHandData2===cost-time:%f ms\n",1000 * CTime::timeDifference(class_second_behand_process_data_time,  CTime::getCpuTime()));
    // // Run
    // // printf("rknn_run\n");
    // base::TTimeStamp start_run_class_time = CTime::getCpuTime();
    // ret = rknn_run(m_ctx, nullptr);
    // base::TTimeStamp end_run_class_time = CTime::getCpuTime();
    // // printf("time-statics===RunClassTime===cost-time:%f ms\n",1000 * CTime::timeDifference(start_run_class_time,  end_run_class_time));
    // if(ret < 0)
    // {
    //     printf("rknn_run fail! ret=%d\n", ret);
    //     return false;
    // }
    // base::TTimeStamp class_second_after_process_data_time = CTime::getCpuTime();
    // // Get Output
    // rknn_output outputs[1];
    // memset(outputs, 0, sizeof(outputs));
    // outputs[0].want_float = 1;
    // // printf("rknn_outputs_get\n");
    // ret = rknn_outputs_get(m_ctx, 1, outputs, NULL);
    // if(ret < 0)
    // {
    //     printf("rknn_outputs_get fail! ret=%d\n", ret);
    //     return false;
    // }

    // std::vector<std::pair<float, int>> top_results;
    // std::vector<std::pair<float, int>> top_results_ori;

    // getTopN((float *)(outputs[0].buf), m_output_attrs[0].n_elems,
    //               m_top_n_result, m_min_score, &top_results_ori,outputs[0].want_float);

    // //softmaxs
    // float *src_prediction = (float *)(outputs[0].buf);

    // #if HAS_SOFT_MAX
    // float *dest_prediction = new float[m_output_attrs[0].n_elems];
    // memset(dest_prediction, 0, m_output_attrs[0].n_elems);
    // activation_function_softmax(src_prediction,dest_prediction,m_output_attrs[0].n_elems);
    // getTopN(dest_prediction, m_output_attrs[0].n_elems,
    //               m_top_n_result, m_min_score, &top_results, outputs[0].want_float);
    // delete []dest_prediction;

    // #else
    // getTopN(src_prediction, m_output_attrs[0].n_elems,
    //               m_top_n_result, m_min_score, &top_results, outputs[0].want_float);
    // #endif

    // rknn_outputs_release(m_ctx, 1, outputs);

    // if(top_results.empty())
    // {
    //     printf("detected nothing \n");
    //     result.obj_class = AI_OBJECT_NOTHING;
    //     return false;
    // }
    // else
    // {

    //     if (m_class_model_type == CLASS_MODLE_TYPE_ALL)
    //     {
    //         result.obj_class = CTypeTransform::aiLable2AiObjectClass((AIAllClassLabel)(top_results[0].second));
    //         result.ori_all_class = (AIAllClassLabel)top_results[0].second;

    //     }else
    //     {
    //         result.obj_class = CTypeTransform::aiFloorBlanketLable2AiObjectClass((AIFloorBlanketClassLabel)(top_results[0].second));
    //         result.ori_floor_class = (AIFloorBlanketClassLabel)top_results[0].second;
    //     }
    //     // printf("ori top 1 num is %d score is %.4f\n",top_results_ori[0].second,top_results_ori[0].first);
    //     // printf("softmax top 1 num is %d score is %.4f\n",top_results[0].second,top_results[0].first);
    //     result.classify_score = top_results[0].first;
    //     // printf("time-statics===ClassAfterHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(class_second_after_process_data_time,  CTime::getCpuTime()));

    //     //define unknown class
    //     //define unknown class
    //     if (result.obj_class > AI_OBJECT && result.obj_class < AI_OBJECT_FURNITURE)
    //     {
    //         //
    //         if (
    //             result.obj_class == AI_OBJECT_SOCKS
    //             ||
    //             result.obj_class == AI_OBJECT_CHAIR_BASE
    //             ||
    //             result.obj_class == AI_OBJECT_WEIGHT_SCALE
    //             ||
    //             result.obj_class == AI_OBJECT_METAL_CHAIR_FOOT
    //             ||
    //             result.obj_class == AI_OBJECT_SHOE
    //             ||
    //             result.obj_class == AI_OBJECT_WIRE
    //             )
    //         {
    //             double obj_class_score_max= m_ai_parameter.getAiObjectClassSorceThreshold(result.obj_class);
    //             double obj_detect_score_max = m_ai_parameter.getAiObjectDetectSorceThreshold(result.obj_class);
    //             double obj_unknown_class_min_score = m_ai_parameter.getUnownObjectClassminScore();
    //             double obj_unknown_detect_min_score = m_ai_parameter.getUnownObjectDetectminScore();
    //             bool class_is_low_score = false;
    //             bool detect_is_low_score = false;
    //             if (result.classify_score < obj_class_score_max && result.classify_score > obj_unknown_class_min_score)
    //             {
    //                 class_is_low_score = true;
    //             }

    //             if (result.object_detect_score < obj_detect_score_max && result.object_detect_score > obj_unknown_detect_min_score)
    //             {
    //                 detect_is_low_score = true;
    //             }

    //             if (class_is_low_score || detect_is_low_score)
    //             {
    //                 result.obj_ori_class = result.obj_class;
    //                 if (result.obj_class == AI_OBJECT_SOCKS)
    //                 {
    //                     result.obj_class = AI_OBJECT_UKNOWN_SOCKS;

    //                 }else if (result.obj_class == AI_OBJECT_CHAIR_BASE)
    //                 {
    //                     // result.obj_class = AI_OBJECT_UKNOWN_CHAIR_BASE;

    //                 }else if (result.obj_class == AI_OBJECT_WEIGHT_SCALE)
    //                 {
    //                     // result.obj_class = AI_OBJECT_UKNOWN_WEIGHT_SCALE;

    //                 }else if (result.obj_class == AI_OBJECT_METAL_CHAIR_FOOT)
    //                 {
    //                     // result.obj_class = AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT;

    //                 }else if (result.obj_class == AI_OBJECT_SHOE)
    //                 {
    //                     // result.obj_class = AI_OBJECT_UKNOWN_SHOE;

    //                 }else if (result.obj_class == AI_OBJECT_WIRE)
    //                 {
    //                     // result.obj_class = AI_OBJECT_UKNOWN_WIRE;

    //                 }

    //                 // result.obj_class = AI_OBJECT;
    //             }

    //         }
    //     }

    //     return true;
    // }
}
/**********************************************************************************
File name:	  CClassification.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CClassiModelFusion.h>
#include <everest/base/CTime.h>
#include <everest/base/CLog.h>
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;
/***********************************************************************************
Function:     CClassification
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassiModelFusion::CClassiModelFusion()
{

	#if CLASS_MODEL_INT8
	initInt8Models();
	#else
	initFloatModels();
    #endif
}

/***********************************************************************************
Function:     ~CClassification
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassiModelFusion::~CClassiModelFusion()
{
    
}

/***********************************************************************************
Function:     ~initModels
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::initInt8Models()
{
    // std::string floor_class_model_path = "/userdata/AI/floor_class_model.rknn";
	// m_floor_blanket_net_classication = new CEfficientNetClassification(CLASS_MODLE_TYPE_FLOOR_BLANKET,128,128,floor_blanket_model_path);
	//regnet-64,regnet-128,efficienet-128---to 1 2 3
	std::string all_class_model1_path = "/userdata/AI/all_class_model1.rknn";
	m_all_class_classification1 = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,64,64,all_class_model1_path);
	std::string all_class_model2_path = "/userdata/AI/all_class_model2.rknn";
	m_all_class_classification2 = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,128,128,all_class_model2_path);
	std::string all_class_model3_path = "/userdata/AI/all_class_model3.rknn";
	m_all_class_classification3 = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,128,128,all_class_model3_path);
	
	#if CLASS_MODEL_NEED_BD
	std::string all_class_model_bd_path = "/userdata/AI/all_class_model_bd.rknn";
	m_all_class_classification_bd = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,64,64,all_class_model_bd_path);
    #endif
}


/***********************************************************************************
Function:     ~initFloatModels
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::initFloatModels()
{
	std::string all_class_model_path = "/userdata/AI/all_class_model.rknn";
	m_all_class_classification = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,64,64,all_class_model_path);
	// m_all_class_classification = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,128,128,all_class_model_path);

	#if CLASS_MODEL_NEED_BD
	std::string all_class_model_bd_path = "/userdata/AI/all_class_model_bd.rknn";
	m_all_class_classification_bd = new CEfficientNetClassification(CLASS_MODLE_TYPE_ALL,64,64,all_class_model_bd_path);
    #endif
}



/***********************************************************************************
Function:     ~split_str
Description:  split_str
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::vector<std::string> CClassiModelFusion::splitStr(const std::string &s, const std::string &seperator) {
	std::vector<std::string> result;
	typedef std::string::size_type string_size;
	string_size i = 0;

	while (i != s.size()) {
		//找到字符串中首个不等于分隔符的字母；
		int flag = 0;
		while (i != s.size() && flag == 0) {
			flag = 1;
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[i] == seperator[x]) {
					++i;
					flag = 0;
					break;
				}
		}

		//找到又一个分隔符，将两个分隔符之间的字符串取出；
		flag = 0;
		string_size j = i;
		while (j != s.size() && flag == 0) {
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[j] == seperator[x]) {
					flag = 1;
					break;
				}
			if (flag == 0)
				++j;
		}
		if (i != j) {
			result.push_back(s.substr(i, j - i));
			i = j;
		}
	}
	return result;
}

/***********************************************************************************
Function:     ~loadALLClassModelPrecisionInfo
Description:  loadALLClassModelPrecisionInfo
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::loadALLClassModelPrecisionInfo(std::string config_file_name,
														std::string seprate_s,
														float *model1,
														float *model2,
														float *model3) 
{
	std::ifstream fin(config_file_name);
	if (!fin.is_open()){
        std::cout << config_file_name << "  not exit "<< std::endl;
		return false;
	}
	std::string line;
	int lineNum = 0;
	// std::cout << config_file_name << " file param: "<< std::endl;
	while(getline(fin, line))
	{
		// std::cout << line << std::endl;
		std::vector<std::string> str_ = splitStr(line,seprate_s);
		if (lineNum > 0)//第0行是头
		{
			if (str_.size()==3)
			{
				model1[lineNum] = atof(str_[0].c_str());
				model2[lineNum] = atof(str_[1].c_str());
				model3[lineNum] = atof(str_[2].c_str());
			}
		}
		lineNum++;
	}

	return lineNum > 0;
}


/***********************************************************************************
Function:     ~classModelAreOk
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::classModelAreOk()
{
    // return m_efficient_net_classification.efficientnet_init_success();
	return true;
}


/***********************************************************************************
Function:     ~maxThree
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CClassiModelFusion::maxThree(double n1,double n2,double n3)
{
	double max;
	if (n1>=n2&&n1>=n3)
	max=n1;
	else if (n2>=n1&&n2>=n3)
	max=n2;
	else
	max=n3;
	return max;
}

/***********************************************************************************
Function:     isAvoidMostImportantClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::isRecallMostImportantClass(TAIObjectClass object_class)
{
    switch(object_class)
    {
        case everest::ai::AI_OBJECT_UKNOWN_SOCKS: return true;
        case everest::ai::AI_OBJECT_SOCKS: return true;
		// case everest::ai::AI_OBJECT_UKNOWN_CHAIR_BASE: return true;
		case everest::ai::AI_OBJECT_CHAIR_BASE: return true;
		// case everest::ai::AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT: return true;
		// case everest::ai::AI_OBJECT_METAL_CHAIR_FOOT: return true;
		// case everest::ai::AI_OBJECT_UKNOWN_WEIGHT_SCALE: return true;
		// case everest::ai::AI_OBJECT_WEIGHT_SCALE: return true;
        // case everest::ai::AI_OBJECT_WIRE: return true;
        default: return false;
    }
}

/***********************************************************************************
Function:     isAvoidMostImportantClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::isPrecisionMostImportantClass(TAIObjectClass object_class)
{
    switch(object_class)
    {
        case everest::ai::AI_OBJECT_CLOSESTOOL: return true;
		// case everest::ai::AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT: return true;
		// case everest::ai::AI_OBJECT_METAL_CHAIR_FOOT: return true;
		case everest::ai::AI_OBJECT_UKNOWN_WEIGHT_SCALE: return true;
		case everest::ai::AI_OBJECT_UKNOWN_CHAIR_BASE: return true;
		case everest::ai::AI_FLOOR_TITLE: return true;
		case everest::ai::AI_FLOOR_WOOD: return true;
		// case everest::ai::AI_OBJECT_WIRE: return true;
		// case everest::ai::AI_OBJECT_SHOE: return true;
        default: return false;
    }
}

/***********************************************************************************
Function:     isNeedBdClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::isNeedBdClass(TAIObjectClass object_class)
{
    switch(object_class)
    {
        case everest::ai::AI_OBJECT_UKNOWN_SOCKS: return true;
        case everest::ai::AI_OBJECT_SOCKS: return true;
        default: return false;
    }
}

/***********************************************************************************
Function:     isNeedBdClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::classificationBD(cv::Mat &input_image, TAIObejectDetectData &detect_data)
{

	TAIObejectDetectData object_detect_result_bd = constractDetectData(detect_data);
	bool class_bd_sucs = m_all_class_classification_bd->runEfficientNetClassifiaction(input_image, object_detect_result_bd);
	CLog::log(LogKimbo, LogNormal, "====bd-class==>result is %d\n",object_detect_result_bd.obj_class);

	if (isNeedBdClass(object_detect_result_bd.obj_class))
	{
		detect_data.obj_class = object_detect_result_bd.obj_class;
		detect_data.classify_score = object_detect_result_bd.classify_score;
		return true;
	}

	return false;	
}

bool CClassiModelFusion::confusionClassification(CImage &input_image, TAIObejectDetectData &detect_data)
{

	#if CLASS_MODEL_INT8
	
		return classification(input_image, detect_data);
	#else
		return classificationFloat(input_image, detect_data);

	#endif

}

/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::classificationFloat(CImage &input_image, TAIObejectDetectData &detect_data)
{   
	cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();

	//相机获取到的图片是BRG格式图片，需转换成RGB格式送入分类模型
	//实际测试，图片经过转换后才能识别
	cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);

	TAIObejectDetectData object_detect_result = constractDetectData(detect_data);
	bool class_sucs = m_all_class_classification->runEfficientNetClassifiaction(src_image, object_detect_result);

	if (class_sucs)
	{
		#if CLASS_MODEL_NEED_BD
			if (!isNeedBdClass(object_detect_result.obj_class))
			{
				TAIObejectDetectData object_detect_result_bd = constractDetectData(detect_data);
				if (classificationBD(src_image,object_detect_result_bd))
				{
					detect_data.obj_class = object_detect_result_bd.obj_class;
					detect_data.classify_score = object_detect_result_bd.classify_score;
					return true;
				}
			}
		#endif

		detect_data.obj_class = object_detect_result.obj_class;
		detect_data.classify_score = object_detect_result.classify_score;
		return true;
		
	}
	
	
	detect_data.obj_class = AI_OBJECT_NOTHING;
	return true;	
}

/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::classification(CImage &input_image, TAIObejectDetectData &detect_data)
{   
	cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();

	//相机获取到的图片是BRG格式图片，需转换成RGB格式送入分类模型
	//实际测试，图片经过转换后才能识别
	cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);

	#if CLASS_MODEL_NEED_BD
		TAIObejectDetectData object_detect_result_bd = constractDetectData(detect_data);
		if (classificationBD(src_image,object_detect_result_bd))
		{
			detect_data.obj_class = object_detect_result_bd.obj_class;
			detect_data.classify_score = object_detect_result_bd.classify_score;
			return true;
		}
	#endif

	TAIObejectDetectData object_detect_result1 = constractDetectData(detect_data);
	TAIObejectDetectData object_detect_result2 = constractDetectData(detect_data);
	TAIObejectDetectData object_detect_result3 = constractDetectData(detect_data);

	bool class_1_sucs = m_all_class_classification1->runEfficientNetClassifiaction(src_image, object_detect_result1);
	bool class_2_sucs = m_all_class_classification2->runEfficientNetClassifiaction(src_image, object_detect_result2);
	bool class_3_sucs = m_all_class_classification3->runEfficientNetClassifiaction(src_image, object_detect_result3);

	if (class_1_sucs && class_2_sucs && class_3_sucs)
	{
		CLog::log(LogKimbo, LogNormal, "====class-fusion 1 2 3==>result is %d %d %d \n",object_detect_result1.obj_class,object_detect_result2.obj_class,object_detect_result3.obj_class);
		//three model same class,
		if (object_detect_result1.obj_class == object_detect_result2.obj_class && object_detect_result2.obj_class == object_detect_result3.obj_class)
		{
			detect_data.obj_class = object_detect_result1.obj_class;
			detect_data.classify_score = maxThree(object_detect_result1.classify_score,object_detect_result2.classify_score,object_detect_result3.classify_score);
			return true;
		}

		//for some class recall is the most import ,such as socks,object,wire
		if (isRecallMostImportantClass(object_detect_result1.obj_class)  && 
			!isRecallMostImportantClass(object_detect_result2.obj_class) &&
			!isRecallMostImportantClass(object_detect_result3.obj_class) )
		{
			detect_data.obj_class = object_detect_result1.obj_class;
			detect_data.classify_score = object_detect_result1.classify_score;
			return true;
		}

		if (!isRecallMostImportantClass(object_detect_result1.obj_class)  && 
			isRecallMostImportantClass(object_detect_result2.obj_class) &&
			!isRecallMostImportantClass(object_detect_result3.obj_class) )
		{
			detect_data.obj_class = object_detect_result2.obj_class;
			detect_data.classify_score = object_detect_result2.classify_score;
			return true;
		}
		
		if (!isRecallMostImportantClass(object_detect_result1.obj_class)  && 
			!isRecallMostImportantClass(object_detect_result2.obj_class) &&
			isRecallMostImportantClass(object_detect_result3.obj_class) )
		{
			detect_data.obj_class = object_detect_result3.obj_class;
			detect_data.classify_score = object_detect_result3.classify_score;
			return true;
		}

		// two model class same 
		if (object_detect_result1.obj_class == object_detect_result2.obj_class && object_detect_result2.obj_class != object_detect_result3.obj_class )
		{
			//PrecisionMostImportant must three model result same 
			if (!isPrecisionMostImportantClass(object_detect_result1.obj_class) && object_detect_result1.obj_class != AI_OBJECT_NOTHING)
			{
				//two class same , which score * model_precison max ,which score 
				// float mode1_precsion =  m_all_class_model1_precsion[(int)object_detect_result1.ori_all_class];
				// float mode2_precsion =  m_all_class_model2_precsion[(int)object_detect_result2.ori_all_class];
				if (object_detect_result1.classify_score  > object_detect_result2.classify_score )
				{
					detect_data.obj_class = object_detect_result1.obj_class;
					detect_data.classify_score = object_detect_result1.classify_score;
					return true;
				}else
				{
					detect_data.obj_class = object_detect_result2.obj_class;
					detect_data.classify_score = object_detect_result2.classify_score;
					return true;
				}
			}
		}

		if (object_detect_result1.obj_class != object_detect_result2.obj_class && object_detect_result2.obj_class == object_detect_result3.obj_class )
		{
			//PrecisionMostImportant must three model result same 
			if (!isPrecisionMostImportantClass(object_detect_result2.obj_class) && object_detect_result2.obj_class != AI_OBJECT_NOTHING)
			{
				// //two class same , which score * model_precison max ,which score 
				// float mode2_precsion =  m_all_class_model2_precsion[(int)object_detect_result2.ori_all_class];
				// float mode3_precsion =  m_all_class_model3_precsion[(int)object_detect_result3.ori_all_class];
				if (object_detect_result2.classify_score > object_detect_result3.classify_score )
				{
					detect_data.obj_class = object_detect_result2.obj_class;
					detect_data.classify_score = object_detect_result2.classify_score;
					return true;
				}else
				{
					detect_data.obj_class = object_detect_result3.obj_class;
					detect_data.classify_score = object_detect_result3.classify_score;
					return true;
				}
			}
		}

		if (object_detect_result1.obj_class == object_detect_result3.obj_class && object_detect_result2.obj_class != object_detect_result3.obj_class )
		{
			//PrecisionMostImportant must three model result same 
			if (!isPrecisionMostImportantClass(object_detect_result1.obj_class) && object_detect_result1.obj_class != AI_OBJECT_NOTHING)
			{
				//two class same , which score * model_precison max ,which score 
				// float mode1_precsion =  m_all_class_model1_precsion[(int)object_detect_result1.ori_all_class];
				// float mode3_precsion =  m_all_class_model3_precsion[(int)object_detect_result3.ori_all_class];
				if (object_detect_result1.classify_score > object_detect_result3.classify_score)
				{
					detect_data.obj_class = object_detect_result1.obj_class;
					detect_data.classify_score = object_detect_result1.classify_score;
					return true;
				}else
				{
					detect_data.obj_class = object_detect_result3.obj_class;
					detect_data.classify_score = object_detect_result3.classify_score;
					return true;
				}
			}
		}
	}

	detect_data.obj_class = AI_OBJECT_NOTHING;
	return true;	
}
/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
TAIObejectDetectData CClassiModelFusion::constractDetectData(TAIObejectDetectData &detect_data)
{   
	TAIObejectDetectData object_detect_result;
	object_detect_result.object_detect_score = detect_data.object_detect_score;
	object_detect_result.tof_rgb_x1 = detect_data.tof_rgb_x1;
	object_detect_result.tof_rgb_y1 = detect_data.tof_rgb_y1;
	object_detect_result.tof_rgb_x2 = detect_data.tof_rgb_x2;
	object_detect_result.tof_rgb_y2 = detect_data.tof_rgb_y2;

	object_detect_result.detect_x1 = detect_data.detect_x1;
	object_detect_result.detect_y1 = detect_data.detect_y1;
	object_detect_result.detect_x2 = detect_data.detect_x2;
	object_detect_result.detect_y2 = detect_data.detect_y2;
	return object_detect_result;
}

/***********************************************************************************
Function:     classificationFloorBlanket
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassiModelFusion::classificationFloorBlanket(CImage &input_image, TAIObejectDetectData &detect_data)
{   
	cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();

	//相机获取到的图片是BRG格式图片，需转换成RGB格式送入分类模型
	//实际测试，图片经过转换后才能识别
	cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);

	TAIObejectDetectData object_detect_result1 = constractDetectData(detect_data);
	TAIObejectDetectData object_detect_result2 = constractDetectData(detect_data);
	TAIObejectDetectData object_detect_result3 = constractDetectData(detect_data);

	bool class_1_sucs = m_all_class_classification1->runEfficientNetClassifiaction(src_image, object_detect_result1);
	bool class_2_sucs = m_all_class_classification2->runEfficientNetClassifiaction(src_image, object_detect_result2);
	bool class_3_sucs = m_all_class_classification3->runEfficientNetClassifiaction(src_image, object_detect_result3);

	if (class_1_sucs && class_2_sucs && class_3_sucs)
	{
	
		if (object_detect_result1.obj_class == object_detect_result2.obj_class && object_detect_result2.obj_class == object_detect_result3.obj_class)
		{
			detect_data.obj_class = object_detect_result1.obj_class;
			detect_data.classify_score = maxThree(object_detect_result1.classify_score,object_detect_result2.classify_score,object_detect_result3.classify_score);
			return true;
		}
	}
	
	detect_data.obj_class = AI_OBJECT_NOTHING;
	return true;	
}

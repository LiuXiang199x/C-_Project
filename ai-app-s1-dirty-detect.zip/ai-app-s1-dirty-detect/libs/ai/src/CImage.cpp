/**********************************************************************************
File name:	  CImage.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CImage.h>

/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::base;
using namespace everest::ai;

/***********************************************************************************
Function:     CImage
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImage::CImage(cv::Mat &cut_image, cv::Mat &origin_image, base::TTimeStamp &time)
{
	m_cut_image = cut_image;
	m_origin_image = origin_image;
    m_time_stamp = time;
}

/***********************************************************************************
Function:     CImage
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImage::CImage()
{
	m_cut_image = cv::Mat();
	m_origin_image = cv::Mat();
	m_time_stamp = INVALID_TIMESTAMP;
}

/***********************************************************************************
Function:     ~CImage
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImage::~CImage()
{
    
}

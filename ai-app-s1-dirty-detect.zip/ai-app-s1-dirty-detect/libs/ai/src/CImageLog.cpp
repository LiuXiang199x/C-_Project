/**********************************************************************************
File name:	  CImageLog.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CImageLog.h>
#include <everest/ai/CTypeTransform.h>
#include <everest/base/CTime.h>
#include <everest/base/CFilePath.h>
#include <everest/hwdrivers/CCameraSensor.h>
#include <stdlib.h>
#include <everest/ai/CImageTransform.h>
#include <fstream>
#include <everest/base/CLog.h>
/*********************************** Name space ***********************************/
using namespace std;
using namespace everest;
using namespace everest::base;
using namespace everest::ai;

#define DEBUG_ORI_IMG 0
#define DEBUG_ORI_DETECT_IMG 1
#define DEBUG_DETECT_RESULT_TXT 0

/***********************************************************************************
Function:     CImageLog
Description:  The constructor of image log
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImageLog::CImageLog()
{
	
}

/***********************************************************************************
Function:     CImageLog
Description:  The destructor of image log
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImageLog::~CImageLog()
{
    
}

/***********************************************************************************
Function:     saveRawImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CImageLog::saveRawImage(cv::Mat &image)
{
    std::string time_stamp = CTime::getTimeString();
    std::string image_path = base::CFilePath::getAiImagePathPrefix() + "rgb/origin/" + time_stamp + "_origin.jpg";
    if(!image.empty())
    {
        std::cout << "origin ims " << image_path << std::endl;
        cv::imwrite(image_path, image);
    } 
}

/***********************************************************************************
Function:     saveDetectInfoString
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CImageLog::saveDetectInfoString(std::string &detect_info_file_name,std::string &detect_info_str)
{

    std::string debug_file_name = "/tmp/AI/debug/" + detect_info_file_name + ".txt";
    // std::ofstream out_file(debug_file_name, ios::app);
    std::ofstream out_file(debug_file_name, ios::out | ios::app);
    out_file<<detect_info_str;
    out_file<<std::endl;
    out_file.close();
}

/***********************************************************************************
Function:     classNeedSaveDebugInfo
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CImageLog::classNeedSaveDebugInfo(TAIObjectClass object_class)
{
    
    if (object_class == AI_FLOOR_TITLE || object_class == AI_FLOOR_WOOD)
    {
        return false;
    }
    return true;
    
}



/***********************************************************************************
Function:     saveCalibrationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CImageLog::saveCalibrationImage(cv::Mat &calibration_image)
{
    std::string time_stamp = CTime::getTimeString();
    std::string calibratiom_image_path = base::CFilePath::getAiImagePathPrefix() + "rgb/calibration/" + time_stamp + "right_calibration.jpg";
    if(!calibration_image.empty())
    {   
        std::cout << "calibration img " << calibratiom_image_path << std::endl;
        cv::imwrite(calibratiom_image_path, calibration_image);
    }

    // if(!calibration_image.empty())
    // {   
    //     m_calib_img_count ++;
    //     if (m_calib_img_count == 20)
    //     {

    //         char file_path[128];
    //         std::string fileName;
    //         size_t curr_time = time(NULL);      
    //         memset(file_path,0x0,sizeof(file_path));
    //         sprintf(file_path,"/tmp/rgb/right-%d.png",curr_time); 
    //         fileName.append(file_path,strlen(file_path));
    //         cv::imwrite(fileName, calibration_image);
    //         std::cout << "calibration img " << fileName << std::endl;
    //         sleep(20);
    //         m_calib_img_count = 0;
    //     }
        
    // }
}

void CImageLog::saveOnlyDetectImage(TAIObejectDetectData debug_obj, 
                                      cv::Mat &origin_image)
{
    std::string time_stamp = CTime::getTimeString();
    std::string detect_image_path = base::CFilePath::getAiImagePathPrefix() + "detect/" + time_stamp + "detect.jpg";
    std::cout << "================detect object======================"  << std::endl;
    cv::Mat detect_save_image = origin_image.clone(); 
    std::string result_label = "obj";
    rectangle(detect_save_image, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1), cv::Point(debug_obj.detect_x2, debug_obj.detect_y2), cv::Scalar(255, 0, 0, 255), 3);
    putText(detect_save_image, result_label.c_str(), cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
    cv::imwrite(detect_image_path, detect_save_image);
}


std::string CImageLog::subreplace(std::string resource_str, std::string sub_str, std::string new_str)
{
    std::string dst_str = resource_str;
    std::string::size_type pos = 0;
    while((pos = dst_str.find(sub_str)) != std::string::npos)   //替换所有指定子串
    {
        dst_str.replace(pos, sub_str.length(), new_str);
    }
    return dst_str;
}

void CImageLog::saveDetectClassOriResultImage(std::vector<TAIObejectDetectData> result_objects, 
                                          cv::Mat &big_image)
{
    if (result_objects.empty())
    {
        return;
    }
    std::string detect_path = "detect_class_image/";
    cv::Mat detect_save_image = big_image.clone();
    string class_name_str = "";
    for (size_t i = 0; i < result_objects.size(); i++)
    {
        TAIObejectDetectData debug_obj = result_objects[i];
        double score = debug_obj.classify_score;
        double detect_score = debug_obj.object_detect_score;
        std::string result_label = CTypeTransform::aiObjectClass2String(debug_obj.obj_class);
        result_label = subreplace(result_label,"AI_OBJECT","");
        class_name_str = class_name_str + "-" + result_label;
        string cls_score_str = to_string((int)(score * 100));
        string detect_score_str = to_string((int)(detect_score * 100));
        std::string score_str_draw = detect_score_str + "_" + cls_score_str;
        rectangle(detect_save_image, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1), cv::Point(debug_obj.detect_x2, debug_obj.detect_y2), cv::Scalar(255, 0, 0, 255), 3);
        putText(detect_save_image, result_label.c_str(), cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
        putText(detect_save_image, score_str_draw, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 30), 1, 2, cv::Scalar(0, 255, 0, 255));
    }

    long long time_stamp_l = CTime::getRealTime();
    //std::string image_path = CFilePath::getAiImagePathPrefix() + class_path  +  to_string(time_stamp_l) + ".jpg";
    // std::string time_stamp = CTime::getTimeString();
    // std::string ori_detect_image_path = CFilePath::getAiImagePathPrefix() + detect_path + time_stamp + "_" + class_name_str + ".jpg";
    std::string ori_detect_image_path = CFilePath::getAiImagePathPrefix() + detect_path + to_string(time_stamp_l) + "_" + class_name_str + ".jpg";
    cv::imwrite(ori_detect_image_path, detect_save_image);
}


void CImageLog::saveFloorBlanketImage(TAIObejectDetectData debug_obj, 
                                      cv::Mat &floor_image)

{
    std::string result_label = CTypeTransform::aiObjectClass2String(debug_obj.obj_class);
    string score_str = to_string((int)(debug_obj.classify_score * 100));
    std::string time_stamp = CTime::getTimeString();
    std::string class_path = "floor_blanket/";
    std::string image_path = CFilePath::getAiImagePathPrefix() + class_path  + score_str + "_"  + result_label + "_"+ time_stamp + ".jpg";
    std::cout << "save floor blanket " << image_path << std::endl;
    cv::Mat save_image = floor_image.clone();
    cv::imwrite(image_path, save_image);
}

void CImageLog::saveAiDetectIuputImage(cv::Mat &aiDetectIuputImage)
{
    // std::string time_stamp = CTime::getTimeString();
    long long time_stamp_l = CTime::getRealTime();
    std::string class_path = "aiDetectIuputImage/";
    // std::string image_path = CFilePath::getAiImagePathPrefix() + class_path  +  time_stamp + ".jpg";
    std::string image_path = CFilePath::getAiImagePathPrefix() + class_path  +  to_string(time_stamp_l) + ".jpg";
    // std::cout << "save saveAiDetectIuputImage " << image_path << std::endl;
    
    cv::Mat save_image = aiDetectIuputImage.clone();
    CLog::log(LogKimbo, LogNormal, "[CImageLog] save saveAiDetectIuputImage path %s!\n",image_path.c_str());
    CLog::log(LogKimbo, LogNormal, "[CImageLog] imgwith %d imgHeight %d!\n",save_image.cols,save_image.rows);
    cv::imwrite(image_path, save_image);
}

/***********************************************************************************
Function:     saveCalibrationImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CImageLog::saveDetectObjectImage(TAIObejectDetectData debug_obj, 
                                      cv::Mat &detect_image_roi,  
                                      cv::Mat &origin_image)
{
    std::string class_path; // /tmp/AI/ai_collection_data/
    std::string detect_path; //
    TAIObjectClass object_class = debug_obj.obj_class;
    double score = debug_obj.classify_score;
    double detect_score = debug_obj.object_detect_score;

    if(object_class < AI_OBJECT)
    {
        class_path = "nothing/";
        detect_path = "nothing_detect/";
    }
    else if(object_class < AI_OBJECT_FURNITURE)
    {
        class_path = "object/";
        detect_path = "object_detect/";
    }
    else if(object_class < AI_ROOM)
    {
        class_path = "furniture/";
        detect_path = "furniture_detect/";
    }
    else if(object_class < AI_FLOOR)
    {
        class_path = "room/";
        detect_path = "room_detect/";
    }
    else 
    {
        class_path = "floor/";
        detect_path = "floor_detect/";
    }

    if(object_class == AI_OBJECT_UKNOWN_CHAIR_BASE || 
    object_class == AI_OBJECT_UKNOWN_SOCKS || 
    object_class == AI_OBJECT_UKNOWN_WEIGHT_SCALE ||
    object_class == AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT
    ||
    object_class == AI_OBJECT_UKNOWN_SHOE
    ||
    object_class == AI_OBJECT_UKNOWN_WIRE
    )
    {
        class_path = "object/";
        detect_path = "unknown_object_detect/";
    } 

    std::string result_label = CTypeTransform::aiObjectClass2String(object_class);
    string score_str = to_string((int)(score * 100));
    string detect_score_str = to_string((int)(detect_score * 100));

    std::string time_stamp = CTime::getTimeString();
    std::string origin_image_path = CFilePath::getAiImagePathPrefix() + class_path + "origin_" + score_str + "_" + detect_score_str + result_label + "_"+ time_stamp + ".jpg";
    std::string detect_image_path = CFilePath::getAiImagePathPrefix() + class_path + "detect_" + score_str + "_" + detect_score_str + result_label + "_"+ time_stamp + ".jpg";
    std::string ori_detect_image_path = CFilePath::getAiImagePathPrefix() + detect_path + time_stamp + ".jpg";

    std::cout << "save origin img  " << origin_image_path << std::endl;
    std::cout << "save detect img  " << detect_image_path << std::endl;
    std::cout << "save ori detect img  " << ori_detect_image_path << std::endl;
    CLog::log(LogKimbo, LogNormal, " save detect img  %s\n",detect_image_path.c_str());


    #if CAMERA_200W 
        // cv::imwrite(origin_image_path, origin_image);
        cv::imwrite(detect_image_path, detect_image_roi);
        #if DEBUG_ORI_DETECT_IMG
            cv::Mat detect_save_image = origin_image.clone(); 
            std::string score_str_draw = to_string(score);
            rectangle(detect_save_image, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1), cv::Point(debug_obj.detect_x2, debug_obj.detect_y2), cv::Scalar(255, 0, 0, 255), 3);
            putText(detect_save_image, result_label.c_str(), cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
            putText(detect_save_image, score_str_draw, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 30), 1, 2, cv::Scalar(0, 255, 0, 255));
            cv::imwrite(ori_detect_image_path, detect_save_image);

            if(object_class == AI_OBJECT_UKNOWN_CHAIR_BASE || 
                object_class == AI_OBJECT_UKNOWN_SOCKS || 
                object_class == AI_OBJECT_UKNOWN_WEIGHT_SCALE ||
                object_class == AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT
                ||
                object_class == AI_OBJECT_UKNOWN_SHOE
                ||
                object_class == AI_OBJECT_UKNOWN_WIRE
                )            
            {
                std::string ori_cls_label = CTypeTransform::aiObjectClass2String(debug_obj.obj_ori_class);
                std::cout << "save unknown object  " << ori_cls_label << std::endl;
                std::string ori_detect_image_path = CFilePath::getAiImagePathPrefix() + detect_path + "detect_" + score_str + "_" + detect_score_str + result_label + time_stamp + ".jpg";;
                cv::Mat detect_save_image = origin_image.clone(); 
                std::string score_str_draw = to_string(score);
                rectangle(detect_save_image, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1), cv::Point(debug_obj.detect_x2, debug_obj.detect_y2), cv::Scalar(255, 0, 0, 255), 3);
                putText(detect_save_image, result_label.c_str(), cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
                putText(detect_save_image, score_str_draw, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 30), 1, 2, cv::Scalar(0, 255, 0, 255));
                cv::imwrite(ori_detect_image_path, detect_save_image);
            } 
        #endif

        #if DEBUG_ORI_IMG
            cv::Mat ori_save_image = origin_image.clone();   
            cv::resize(ori_save_image, ori_save_image, cv::Size((int)(ori_save_image.cols/1.5), 
                                (int)(ori_save_image.rows/1.5)), (0, 0), (0, 0), cv::INTER_LINEAR);
            cv::imwrite(origin_image_path, ori_save_image);
        #endif

        #if DEBUG_DETECT_RESULT_TXT

        if (classNeedSaveDebugInfo(object_class))
        {
            // std::string class_debug_str = CTypeTransform::aiObjectClass2OriTrainModelClassString(object_class);
            std::cout << "save detect text info" << std::endl;
            std::string class_debug_str = to_string(object_class);
            std::string score_debug_str = to_string(score);
            std::string detect_score_debug_str = to_string(detect_score);
            std::string pre_location_str = to_string(debug_obj.detect_x1) + " " + to_string(debug_obj.detect_y1) + " " + to_string(debug_obj.detect_x2) + " " + to_string(debug_obj.detect_y2);
            std::string debug_info_str = class_debug_str + " " + score_debug_str + " " + pre_location_str + " " + detect_score_debug_str;
            saveDetectInfoString(debug_obj.detect_ori_image_debug_str,debug_info_str);
        }
        #endif


    #else //100W
        cv::Mat detect_image_save_roi = detect_image_roi.clone();
        cv::resize(detect_image_save_roi, detect_image_save_roi, cv::Size((int)(detect_image_save_roi.cols/1.5), 
                            (int)(detect_image_save_roi.rows/1.5)), (0, 0), (0, 0), cv::INTER_LINEAR);
        cv::imwrite(detect_image_path, detect_image_save_roi); 

        #if DEBUG_ORI_DETECT_IMG
            cv::Mat detect_save_image = origin_image.clone(); 
            std::string score_str_draw = to_string(score);
            rectangle(detect_save_image, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1), cv::Point(debug_obj.detect_x2, debug_obj.detect_y2), cv::Scalar(255, 0, 0, 255), 3);
            putText(detect_save_image, result_label.c_str(), cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
            putText(detect_save_image, score_str_draw, cv::Point(debug_obj.detect_x1, debug_obj.detect_y1 - 30), 1, 2, cv::Scalar(0, 255, 0, 255));
            cv::imwrite(ori_detect_image_path, detect_save_image);
        #endif

        #if DEBUG_ORI_IMG
            cv::Mat ori_save_image = origin_image.clone();   
            cv::resize(ori_save_image, ori_save_image, cv::Size((int)(ori_save_image.cols/1.5), 
                                (int)(ori_save_image.rows/1.5)), (0, 0), (0, 0), cv::INTER_LINEAR);
            cv::imwrite(origin_image_path, ori_save_image);
        #endif
      
    #endif
  
}

/***********************************************************************************
Function:     readDebugImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CImageLog::readDebugImage(std::string &name, cv::Mat &image)
{
    image = cv::imread(name, 1);
    
    if(!image.empty())
    {
        // std::string time_str = CTime::getTimeString();
        // std::string origin_image_path = "/tmp/AI/test/" + time_str + "_origin.jpg";
        // std::string cvtColor1_image_path = "/tmp/AI/test/" + time_str + "_cvtColor1.jpg";
        // std::string cvtColor2_image_path = "/tmp/AI/test/" + time_str + "_cvtColor2.jpg";
        // cv::imwrite(origin_image_path, image);
        
        // cv::cvtColor(image, image, cv::COLOR_BGR2RGB);

        // cv::imwrite(cvtColor1_image_path, image);

        // cv::cvtColor(image, image, cv::COLOR_BGR2RGB);

        // cv::imwrite(cvtColor2_image_path, image);
        
        return true;
    }
    std::cout << "read img fail " << name << std::endl;
    return false;
}
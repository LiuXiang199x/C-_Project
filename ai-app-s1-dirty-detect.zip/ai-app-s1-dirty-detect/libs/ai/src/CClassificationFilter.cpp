/**********************************************************************************
File name:	  CClassificationFilter.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CClassificationFilter.h>
// #include <everest/hwdrivers/CCameraSensor.h>
#include <everest/hwdrivers/CCameraSensor.h>

/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;

/***********************************************************************************
Function:     CClassificationFilter
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassificationFilter::CClassificationFilter()
{
	
}

/***********************************************************************************
Function:     ~CClassificationFilter
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassificationFilter::~CClassificationFilter()
{
    
}

/***********************************************************************************
Function:     ~CClassificationFilter
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filter(TAIObejectDetectData &classify_data)
{
    return true;
}


/***********************************************************************************
Function:     ~filterByScore
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filterByScore(TAIObejectDetectData &classify_data)
{
	return classify_data.classify_score >= m_ai_parameter.getAiObjectClassSorceThreshold(classify_data.obj_class);
}


bool CClassificationFilter::filterUnknownObjectData(TAIObejectDetectData &classify_data)
{
	int width = classify_data.detect_x2 - classify_data.detect_x1;
	int height = classify_data.detect_y2 - classify_data.detect_y1;
	int center_x = classify_data.detect_x1 + width / 2;
	int center_y = classify_data.detect_y1 + height / 2;
	int box_area = width * height;
	int max_box_area = 143260;//1-0.77
	int middle_box_area = 114185;//0.77,70200

	if (
		classify_data.obj_class == AI_OBJECT_UKNOWN_CHAIR_BASE || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_SOCKS || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_WEIGHT_SCALE || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT
		||
        classify_data.obj_class == AI_OBJECT_UKNOWN_SHOE
        ||
        classify_data.obj_class == AI_OBJECT_UKNOWN_WIRE
		)
	{
		//filter center y top 1/2
		if (center_y < SC_CAMERA_CROPED_HEIGHT / 2.0)
		{
			return false;
		}
		
		float box_bottom_location_aspatio = classify_data.detect_y2 * 1.0 / SC_CAMERA_CROPED_HEIGHT;
		if (box_bottom_location_aspatio > 0.77 && box_bottom_location_aspatio < 1)
		{
			if (box_area > max_box_area)
			{
				return false;
			}
		}

		if (box_bottom_location_aspatio <= 0.77)
		{
			if (box_area > middle_box_area)
			{
				return false;
			}
			
		}
	}
	
	return true;
}


/***********************************************************************************
Function:     ~filterFloor
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filterFloor(TAIObejectDetectData &classify_data)
{
	if (classify_data.obj_class == AI_FLOOR_TITLE 
	|| classify_data.obj_class == AI_FLOOR_WOOD
	||
	classify_data.obj_class == AI_OBJECT_BLANKET
	)
	{
		return filterByScore(classify_data);
	}

	return false;
}

/***********************************************************************************
Function:     ~filterNotInInterestAreaDetectData
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filterNotInInterestAreaDetectData(TAIObejectDetectData &classify_data)
{
	int width = classify_data.detect_x2 - classify_data.detect_x1;
	int height = classify_data.detect_y2 - classify_data.detect_y1;
	//5170 9279
	int small_box_area = 2600;
	//0.64,2600
	int inter_area_left = 642 * 0.2;
	int inter_area_right = 642 * 0.8;
	int inter_area_top = 362 * 0.64;
	if (width * height < small_box_area)
	{
		if (classify_data.detect_x2 < inter_area_left || classify_data.detect_x1 > inter_area_right || classify_data.detect_y2 < inter_area_top)
		{
			return true;
		}
	}
	
	return false;
}

/***********************************************************************************
Function:     ~boxCenterPointIsInAvoidInterestArea
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::boxCenterPointIsInAvoidInterestArea(TAIObejectDetectData &classify_data)
{
	int width = classify_data.detect_x2 - classify_data.detect_x1;
	int height = classify_data.detect_y2 - classify_data.detect_y1;
	int center_x = classify_data.detect_x1 + width / 2;
	int center_y = classify_data.detect_y1 + height / 2;
	//5170 9279
	int small_box_area = 2600;
	//0.64,2600
	int inter_area_left = 642 * 0.2;
	int inter_area_right = 642 * 0.8;
	int inter_area_top = 362 * 0.50;
	int inter_area_bottom = SC_CAMERA_CROPED_HEIGHT;

	return (center_x > inter_area_left && center_x < inter_area_right) && (center_y > inter_area_top && center_y < inter_area_bottom);
}

bool CClassificationFilter::boxNeedToBeInhibitedByAvoidBox(TAIObejectDetectData &classify_data)
{
	int width = classify_data.detect_x2 - classify_data.detect_x1;
	int height = classify_data.detect_y2 - classify_data.detect_y1;
	//5170 9279
	int small_box_area = 2600;
	//0.64,2600
	int inter_area_left = 642 * 0.2;
	int inter_area_right = 642 * 0.8;
	int inter_area_top = 362 * 0.5;
	// if (width * height < small_box_area)
	// {
	// 	if (classify_data.detect_x2 < inter_area_left || classify_data.detect_x1 > inter_area_right || classify_data.detect_y2 < inter_area_top)
	// 	{
	// 		return true;
	// 	}
	// }

	if (classify_data.detect_x2 < inter_area_left || classify_data.detect_x1 > inter_area_right || classify_data.detect_y2 < inter_area_top)
	{
		return true;
	}
	
	return false;
}


bool CClassificationFilter::boxWholeIsInAvoidInterestArea(TAIObejectDetectData &classify_data)
{

	int width = classify_data.detect_x2 - classify_data.detect_x1;
	int height = classify_data.detect_y2 - classify_data.detect_y1;
	//5170 9279
	int small_box_area = 2600;
	//0.64,2600
	int inter_area_left = 642 * 0.2;
	int inter_area_right = 642 * 0.8;
	int inter_area_top = 362 * 0.64;

	int inter_area_bottom = SC_CAMERA_CROPED_HEIGHT;

	return (classify_data.detect_x1 > inter_area_left  && classify_data.detect_x2 < inter_area_right) 
	&& (classify_data.detect_y1 > inter_area_top&& classify_data.detect_y2 < inter_area_bottom);
}

/***********************************************************************************
Function:     filterObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filterObject(TAIObejectDetectData &classify_data,base::TAiMode ai_mode)
{
	// if (classify_data.object_detect_score < 0.40 && classify_data.obj_class != AI_OBJECT_WIRE)
	// {
	// 	return false;
	// }

//作为未知障碍物
	if (
		classify_data.obj_class == AI_OBJECT_UKNOWN_CHAIR_BASE || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_SOCKS || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_WEIGHT_SCALE || 
		classify_data.obj_class == AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT
		||
        classify_data.obj_class == AI_OBJECT_UKNOWN_SHOE
        ||
        classify_data.obj_class == AI_OBJECT_UKNOWN_WIRE
		)
		{
		// bool unknown_object_box_is_ok = filterUnknownObjectData(classify_data);
		if (classify_data.obj_class == AI_OBJECT_UKNOWN_SOCKS)
		{
			return true;
		}else
		{
			return filterUnknownObjectData(classify_data);
		}
		
	}

	// if (classify_data.obj_class == AI_OBJECT)
	// {
	// 	return true;
	// }
	
	if (classify_data.obj_class > AI_OBJECT && classify_data.obj_class < AI_OBJECT_FURNITURE && classify_data.obj_class != AI_OBJECT_DOOR_THRESHOLD)
	{
		//object detect score filter
		if (classify_data.obj_class == AI_OBJECT_WIRE || 
			classify_data.obj_class == AI_OBJECT_CHAIR_BASE || 
			classify_data.obj_class == AI_OBJECT_SHOE ||
			classify_data.obj_class == AI_OBJECT_SOCKS ||
			classify_data.obj_class == AI_OBJECT_WEIGHT_SCALE
			)
		{
			if (classify_data.object_detect_score < m_ai_parameter.getAiObjectDetectSorceThreshold(classify_data.obj_class))
			{
				return false;
			}
		}else
		{
			//object filter detect min score
			float common_object_detect_min_score = m_ai_parameter.getObjectDetectThreshold();
			if (classify_data.object_detect_score < common_object_detect_min_score)
			{
				return false;
			}
		}
		
		// if (classify_data.obj_class != AI_OBJECT_WIRE && classify_data.obj_class != AI_OBJECT_BLANKET && classify_data.obj_class != AI_OBJECT_METAL_CHAIR_FOOT)
		// {
		// 	int detect_width = fabs(classify_data.detect_x2 - classify_data.detect_x1);
		// 	if ((detect_width * 1.0)/SC_CAMERA_CROPED_WIDTH > 0.8)
		// 	{
		// 		return false;
		// 	}
		// }
			
		if (classify_data.obj_class != AI_OBJECT_DOG)//except dog cat
		{
			// if (!detectBoxLocationImageTop(classify_data))
			// {
			// 	return filterByScore(classify_data);
			// }
			// else
			// {
			// 	if (classify_data.obj_class == AI_OBJECT_WIRE)
			// 	{
					return filterByScore(classify_data);
			// 	}else
			// 	{
			// 		return false;
			// 	}
			// }
		}
		else
		{
			return filterByScore(classify_data);
		}
	}
	
	return filterScene(classify_data);

}

/***********************************************************************************
Function:     ~filterScene
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassificationFilter::filterScene(TAIObejectDetectData &classify_data)
{
	//scene filter detect min score
	float scene_detect_min_score = m_ai_parameter.getSceceDetectThreshold();
	if (classify_data.object_detect_score < scene_detect_min_score)
	{
		return false;
	}

	int detect_width = fabs(classify_data.detect_x2 - classify_data.detect_x1);
	int detect_height = fabs(classify_data.detect_y2 - classify_data.detect_y1);
	float width_height_aspatio = detect_width * 1.0 / detect_height;

	if (classify_data.obj_class == AI_OBJECT_DINING_TABLE || 
		classify_data.obj_class == AI_OBJECT_SOFA || 
		classify_data.obj_class == AI_OBJECT_BED || 
		classify_data.obj_class == AI_OBJECT_CUPBOARD || 
		classify_data.obj_class == AI_OBJECT_REFRIGERATOR ||
		classify_data.obj_class == AI_OBJECT_DOOR || 
		classify_data.obj_class == AI_OBJECT_CABINET_TEA_TABLE || 
		classify_data.obj_class == AI_OBJECT_CABINET_BED || 
		classify_data.obj_class == AI_OBJECT_CABINET_TV||
		classify_data.obj_class == AI_OBJECT_BED1 || 
		classify_data.obj_class == AI_OBJECT_SOFA1||  
		classify_data.obj_class == AI_OBJECT_REFRIGERATOR1 
		//||  
		// classify_data.obj_class == AI_OBJECT_CUPBOARD1 || 
		// classify_data.obj_class == AI_OBJECT_DINING_TABLE1 ||
		// classify_data.obj_class == AI_OBJECT_CABINET_TEA_TABLE1 || 
		// classify_data.obj_class == AI_OBJECT_CABINET_BED1 || 
		// classify_data.obj_class == AI_OBJECT_CABINET_TV1
		)//except dog cat
	{
		//refrigerator width/height aspatia filter
		if (classify_data.obj_class == AI_OBJECT_REFRIGERATOR || classify_data.obj_class == AI_OBJECT_REFRIGERATOR1)
		{
			if (width_height_aspatio > REFRIGERATOR_WIGHT_HEIGHT_ASPATIA_MAX || width_height_aspatio < REFRIGERATOR_WIGHT_HEIGHT_ASPATIA_MIN)
			{
				return false;
			}			
		}

		if (detectBoxLocationImageTop(classify_data) || detectBoxLocationImageMiddle(classify_data))
		{
			return filterByScore(classify_data);
		}
	}
	else if (classify_data.obj_class == AI_OBJECT_CLOSESTOOL || 
			 classify_data.obj_class == AI_OBJECT_DOOR_THRESHOLD || 
			 classify_data.obj_class == AI_OBJECT_WASHSTAND|| 
			 classify_data.obj_class == AI_OBJECT_WASHING_MACHINE
			//  ||	
			//  classify_data.obj_class == AI_OBJECT_CLOSESTOOL1 || 
			//  classify_data.obj_class == AI_OBJECT_WASHING_MACHINE1
			 )
	{
		//AI_OBJECT_CLOSESTOOL width/height aspatia filter
		if (classify_data.obj_class == AI_OBJECT_CLOSESTOOL || classify_data.obj_class == AI_OBJECT_CLOSESTOOL1)
		{
			if (width_height_aspatio > TOILET_WIGHT_HEIGHT_ASPATIA_MAX || width_height_aspatio < TOILET_WIGHT_HEIGHT_ASPATIA_MIN)
			{
				return false;
			}			  
		}

		//washing_machine width/height aspatia filter
		if (classify_data.obj_class == AI_OBJECT_WASHING_MACHINE || classify_data.obj_class == AI_OBJECT_WASHING_MACHINE1)
		{
			if (width_height_aspatio > WASHING_MACHINE_WIGHT_HEIGHT_ASPATIA_MAX || width_height_aspatio < WASHING_MACHINE_WIGHT_HEIGHT_ASPATIA_MIN)
			{
				return false;
			}			
		}

		// if (!detectBoxLocationImageTop(classify_data))
		// {
			return filterByScore(classify_data);
		// }
	}
	return false;
	
}


/***********************************************************************************
Function:     ~get_detect_box_center
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CClassificationFilter::get_detect_box_center(TAIObejectDetectData obj_roi_class_result,int &x_center, int &y_center)
{
    int x1 = obj_roi_class_result.detect_x1;
    int x2 = obj_roi_class_result.detect_x2;
    int y1 = obj_roi_class_result.detect_y1;
    int y2 = obj_roi_class_result.detect_y2;

    int width = x2 - x1;
    int height = y2 - y1;
    x_center = x1 + width/2;
    y_center = y1 + height/2;
}

/***********************************************************************************
Function:     detectBoxLocationImageTop
Description:  None
Input:        None
Output:       None      l-----top-----l
Return:       None      l-------------l
Others:       None      l-------------l
***********************************************************************************/
bool CClassificationFilter::detectBoxLocationImageTop(TAIObejectDetectData obj_roi_class_result)
{
	int three_devide_deta = SC_CAMERA_CROPED_HEIGHT / 3.0;
	int x_center=0, y_center=0;
	get_detect_box_center(obj_roi_class_result,x_center,y_center);

	return  (y_center <= three_devide_deta);
}

/***********************************************************************************
Function:     detectBoxLocationImageMiddle
Description:  None
Input:        None
Output:       None      l-------------l
Return:       None      l----middle---l
Others:       None      l-------------l
***********************************************************************************/
bool CClassificationFilter::detectBoxLocationImageMiddle(TAIObejectDetectData obj_roi_class_result)
{
	int three_devide_deta = SC_CAMERA_CROPED_HEIGHT / 3.0;
	int x_center=0, y_center=0;
	get_detect_box_center(obj_roi_class_result,x_center,y_center);

	return  (y_center >= three_devide_deta && y_center <= 2*three_devide_deta);
}

/***********************************************************************************
Function:     ~detectBoxLocationImageBottom
Description:  None
Input:        None      
Output:       None      l-------------l
Return:       None      l----bottom---l
Others:       None      l----bottom---l
***********************************************************************************/
bool CClassificationFilter::detectBoxLocationImageBottom(TAIObejectDetectData obj_roi_class_result)
{
	int three_devide_deta = SC_CAMERA_CROPED_HEIGHT / 3.0;
	int x_center=0, y_center=0;
	get_detect_box_center(obj_roi_class_result,x_center,y_center);

	return (y_center >= three_devide_deta && y_center <= 3*three_devide_deta);
}

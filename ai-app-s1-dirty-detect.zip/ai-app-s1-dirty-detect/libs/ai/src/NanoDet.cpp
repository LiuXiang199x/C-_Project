#include <everest/ai/NanoDet.h>
//#include "commdef.h"
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <chrono>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>

using namespace everest::ai;
// get current local time stamp
 int64_t getCurrentLocalTimeStamp()
{
    std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> tp = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
    auto tmp = std::chrono::duration_cast<std::chrono::milliseconds>(tp.time_since_epoch());
    return tmp.count();

    // return std::chrono::duration_cast(std::chrono::system_clock::now().time_since_epoch()).count();
};



struct object_rect {
    int x;
    int y;
    int width;
    int height;
};
const int color_list[80][3] =
        {
                //{255 ,255 ,255}, //bg
                {216 , 82 , 24},
                {236 ,176 , 31},
                {125 , 46 ,141},
                {118 ,171 , 47},
                { 76 ,189 ,237},
                {238 , 19 , 46},
                { 76 , 76 , 76},
                {153 ,153 ,153},
                {255 ,  0 ,  0},
                {255 ,127 ,  0},
                {190 ,190 ,  0},
                {  0 ,255 ,  0},
                {  0 ,  0 ,255},
                {170 ,  0 ,255},
                { 84 , 84 ,  0},
                { 84 ,170 ,  0},
                { 84 ,255 ,  0},
                {170 , 84 ,  0},
                {170 ,170 ,  0},
                {170 ,255 ,  0},
                {255 , 84 ,  0},
                {255 ,170 ,  0},
                {255 ,255 ,  0},
                {  0 , 84 ,127},
                {  0 ,170 ,127},
                {  0 ,255 ,127},
                { 84 ,  0 ,127},
                { 84 , 84 ,127},
                { 84 ,170 ,127},
                { 84 ,255 ,127},
                {170 ,  0 ,127},
                {170 , 84 ,127},
                {170 ,170 ,127},
                {170 ,255 ,127},
                {255 ,  0 ,127},
                {255 , 84 ,127},
                {255 ,170 ,127},
                {255 ,255 ,127},
                {  0 , 84 ,255},
                {  0 ,170 ,255},
                {  0 ,255 ,255},
                { 84 ,  0 ,255},
                { 84 , 84 ,255},
                { 84 ,170 ,255},
                { 84 ,255 ,255},
                {170 ,  0 ,255},
                {170 , 84 ,255},
                {170 ,170 ,255},
                {170 ,255 ,255},
                {255 ,  0 ,255},
                {255 , 84 ,255},
                {255 ,170 ,255},
                { 42 ,  0 ,  0},
                { 84 ,  0 ,  0},
                {127 ,  0 ,  0},
                {170 ,  0 ,  0},
                {212 ,  0 ,  0},
                {255 ,  0 ,  0},
                {  0 , 42 ,  0},
                {  0 , 84 ,  0},
                {  0 ,127 ,  0},
                {  0 ,170 ,  0},
                {  0 ,212 ,  0},
                {  0 ,255 ,  0},
                {  0 ,  0 , 42},
                {  0 ,  0 , 84},
                {  0 ,  0 ,127},
                {  0 ,  0 ,170},
                {  0 ,  0 ,212},
                {  0 ,  0 ,255},
                {  0 ,  0 ,  0},
                { 36 , 36 , 36},
                { 72 , 72 , 72},
                {109 ,109 ,109},
                {145 ,145 ,145},
                {182 ,182 ,182},
                {218 ,218 ,218},
                {  0 ,113 ,188},
                { 80 ,182 ,188},
                {127 ,127 ,  0},
        };

float target_size=416;

int num_classes=3;



std::vector<float> img_size{416,416};



void draw_bboxes(const cv::Mat& bgr, const std::vector<BoxInfo>& bboxes, object_rect effect_roi)
{
    static const char* class_names[] = { "liquid", "powder", "hair"
    };

    cv::Mat image = bgr.clone();
    int src_w = image.cols;
    int src_h = image.rows;
    int dst_w = effect_roi.width;
    int dst_h = effect_roi.height;
    float width_ratio = (float)src_w / (float)dst_w;
    float height_ratio = (float)src_h / (float)dst_h;


    for (size_t i = 0; i < bboxes.size(); i++)
    {
        const BoxInfo& bbox = bboxes[i];
        cv::Scalar color = cv::Scalar(color_list[bbox.label][0], color_list[bbox.label][1], color_list[bbox.label][2]);
        //fprintf(stderr, "%d = %.5f at %.2f %.2f %.2f %.2f\n", bbox.label, bbox.score,
        //    bbox.x1, bbox.y1, bbox.x2, bbox.y2);

        cv::rectangle(image, cv::Rect(cv::Point((bbox.x1 - effect_roi.x) * width_ratio, (bbox.y1 - effect_roi.y) * height_ratio),
                                      cv::Point((bbox.x2 - effect_roi.x) * width_ratio, (bbox.y2 - effect_roi.y) * height_ratio)), color);

        char text[256];
        sprintf(text, "%s %.1f%%", class_names[bbox.label], bbox.score * 100);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        int x = (bbox.x1 - effect_roi.x) * width_ratio;
        int y = (bbox.y1 - effect_roi.y) * height_ratio - label_size.height - baseLine;
        if (y < 0)
            y = 0;
        if (x + label_size.width > image.cols)
            x = image.cols - label_size.width;

        cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      color, -1);

        cv::putText(image, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, cv::Scalar(255, 255, 255));
    }

       cv::imwrite("/userdata/app/bin/out.jpg",image);
 //   cv::imshow("image", image);
}



inline float fast_exp(float x)
{
    union {
        uint32_t i;
        float f;
    } v{};
    v.i = (1 << 23) * (1.4426950409 * x + 126.93490512f);
    return v.f;
}

inline float sigmoid(float x)
{
    return 1.0f / (1.0f + fast_exp(-x));
}

template<typename _Tp>
int activation_function_softmax(const _Tp* src, _Tp* dst, int length)
{
    const _Tp alpha = *std::max_element(src, src + length);
    _Tp denominator{ 0 };

    for (int i = 0; i < length; ++i) {
        dst[i] = fast_exp(src[i] - alpha);
        denominator += dst[i];
    }

    for (int i = 0; i < length; ++i) {
        dst[i] /= denominator;
    }

    return 0;
}


static void generate_grid_center_priors(const int input_height, const int input_width, std::vector<int>& strides, std::vector<CenterPrior>& center_priors)
{
    for (int i = 0; i < (int)strides.size(); i++)
    {
        int stride = strides[i];
        int feat_w = ceil((float)input_width / stride);
        int feat_h = ceil((float)input_height / stride);
        for (int y = 0; y < feat_h; y++)
        {
            for (int x = 0; x < feat_w; x++)
            {
                CenterPrior ct;
                ct.x = x;
                ct.y = y;
                ct.stride = stride;
                center_priors.push_back(ct);
            }
        }
    }
}

//struct object_rect {
//    int x;
//    int y;
//    int width;
//    int height;
//};

int resize_uniform(cv::Mat& src, cv::Mat& dst, cv::Size dst_size, object_rect& effect_area)
{
    int w = src.cols;
    int h = src.rows;
    int dst_w = dst_size.width;
    int dst_h = dst_size.height;
    //std::cout << "src: (" << h << ", " << w << ")" << std::endl;
    dst = cv::Mat(cv::Size(dst_w, dst_h), CV_8UC3, cv::Scalar(0));

    float ratio_src = w * 1.0 / h;
    float ratio_dst = dst_w * 1.0 / dst_h;

    int tmp_w = 0;
    int tmp_h = 0;
    if (ratio_src > ratio_dst) {
        tmp_w = dst_w;
        tmp_h = floor((dst_w * 1.0 / w) * h);
    }
    else if (ratio_src < ratio_dst) {
        tmp_h = dst_h;
        tmp_w = floor((dst_h * 1.0 / h) * w);
    }
    else {
        cv::resize(src, dst, dst_size);
        effect_area.x = 0;
        effect_area.y = 0;
        effect_area.width = dst_w;
        effect_area.height = dst_h;
        return 0;
    }

    //std::cout << "tmp: (" << tmp_h << ", " << tmp_w << ")" << std::endl;
    cv::Mat tmp;
    cv::resize(src, tmp, cv::Size(tmp_w, tmp_h));

    if (tmp_w != dst_w) {
        int index_w = floor((dst_w - tmp_w) / 2.0);
        //std::cout << "index_w: " << index_w << std::endl;
        for (int i = 0; i < dst_h; i++) {
            memcpy(dst.data + i * dst_w * 3 + index_w * 3, tmp.data + i * tmp_w * 3, tmp_w * 3);
        }
        effect_area.x = index_w;
        effect_area.y = 0;
        effect_area.width = tmp_w;
        effect_area.height = tmp_h;
    }
    else if (tmp_h != dst_h) {
        int index_h = floor((dst_h - tmp_h) / 2.0);
        //std::cout << "index_h: " << index_h << std::endl;
        memcpy(dst.data + index_h * dst_w * 3, tmp.data, tmp_w * tmp_h * 3);
        effect_area.x = 0;
        effect_area.y = index_h;
        effect_area.width = tmp_w;
        effect_area.height = tmp_h;
    }
    else {
        printf("error\n");
    }
    //cv::imshow("dst", dst);
    //cv::waitKey(0);
    return 0;
}




NanoDet::NanoDet()
{
     m_init_success= ini();
}
NanoDet::~NanoDet()
{
    // Release
    if(m_ctx >= 0) {
        rknn_destroy(m_ctx);
    }
    if(m_model) {
        free(m_model);
    }

}




struct CmpBoundingBox
{
    bool operator()(const BoundingBox& b1, const BoundingBox& b2)
    {
        return b1.score < b2.score;  //增序
    }
};


void nms_s(std::vector<BoundingBox>& boxes, float threshold, std::vector<BoundingBox>& outputBoxes)
{
    // input check
    uint32_t boxsSize = boxes.size();
    outputBoxes.clear();
    if (boxsSize == 0)
    {
        std::cout << "the inputs boxes size is empty!";
        return;
    }

    // sort the boundingBox
    sort(boxes.begin(), boxes.end(), CmpBoundingBox());

    // pick the box
    uint32_t lastBoxIdex;
    float overlap;
    float area1, area2, inter_area;
    float inter_x1, inter_y1, inter_x2, inter_y2;
    float w, h = 0;

    while (!boxes.empty())
    {
        lastBoxIdex = boxes.size() - 1;
        auto tempBox = boxes[lastBoxIdex];
        outputBoxes.push_back(boxes[lastBoxIdex]);
        boxes.erase(boxes.begin() + lastBoxIdex);
        area1 = (tempBox.x2 - tempBox.x1 + 1) * (tempBox.y2 - tempBox.y1 + 1);
        std::vector<BoundingBox>::iterator boxIter = boxes.begin();
        while (boxIter != boxes.end())
        {
            inter_x1 = std::max(boxIter->x1, tempBox.x1);
            inter_y1 = std::max(boxIter->y1, tempBox.y1);
            inter_x2 = std::min(boxIter->x2, tempBox.x2);
            inter_y2 = std::min(boxIter->y2, tempBox.y2);

            w = std::max(inter_x2 - inter_x1 + 1, 0.0f);
            h = std::max(inter_y2 - inter_y1 + 1, 0.0f);

            inter_area = w * h;
            area2 = (boxIter->x2 - boxIter->x1 + 1) * (boxIter->y2 - boxIter->y1 + 1);

            overlap = inter_area / (area1 + area2 - inter_area);
            if (overlap > threshold)
            {
                boxIter = boxes.erase(boxIter);
            }
            else
            {
                boxIter++;
            }
        }
    }
}





/*-------------------------------------------
                  Functions
-------------------------------------------*/

void NanoDet::printRKNNTensor(rknn_tensor_attr *attr) {
    printf("index=%d name=%s n_dims=%d dims=[%d %d %d %d] n_elems=%d size=%d fmt=%d type=%d qnt_type=%d fl=%d zp=%d scale=%f\n",
           attr->index, attr->name, attr->n_dims, attr->dims[3], attr->dims[2], attr->dims[1], attr->dims[0],
           attr->n_elems, attr->size, 0, attr->type, attr->qnt_type, attr->fl, attr->zp, attr->scale);
}

unsigned char *NanoDet::load_model(const char *filename, int *model_size)
{
    FILE *fp = fopen(filename, "rb");
    if(fp == nullptr) {
        printf("fopen %s fail!\n", filename);
        return NULL;
    }
    fseek(fp, 0, SEEK_END);
    int model_len = ftell(fp);
    unsigned char *model = (unsigned char*)malloc(model_len);
    fseek(fp, 0, SEEK_SET);
    if(model_len != fread(model, 1, model_len, fp)) {
        printf("fread %s fail!\n", filename);
        free(model);
        return NULL;
    }
    *model_size = model_len;
    if(fp) {
        fclose(fp);
    }
    return model;
}
int NanoDet::ini()
{
    const int img_width = 416;
    const int img_height = 416;
    const int img_channels = 3;

    int ret=0;
    int model_len = 0;


    const char *model_path = "/userdata/AI/nano.rknn";


//
//    if (argc != 3) {
//        printf("Usage:%s model image\n", argv[0]);
//        return -1;
//    }



    // Load RKNN Model
    printf("Loading model ...\n");
    m_model = load_model(model_path, &model_len);
    ret = rknn_init(&m_ctx, m_model, model_len, 0);
    if(ret < 0) {
        printf("rknn_init fail! ret=%d\n", ret);
        return -1;
    }

}

bool NanoDet::runNanoDector(cv::Mat src_img, std::vector<TAIObejectDetectData> &detect_results)
{
    cv::Mat orig_img=src_img.clone();
    std::vector<BoxInfo> objects;
    nano_det(src_img,objects,0.4,0.4);


    std::vector<TAIObejectDetectData> results;
    const float src_frame_x_to_tof_scale = orig_img.cols / m_tof_params.getTofCameraWidth();
    const float src_frame_y_to_tof_scale = orig_img.rows / m_tof_params.getTofCameraHeight();

    // Draw Objects
    const std::string class_name_yolo3[] = {"liquid","powder","hair"};

    for(int i=0;i<objects.size();i++)
    {
        int x1 = objects[i].x1;
        int x2 = objects[i].x2;
        int y1 = objects[i].y1;
        int y2 = objects[i].y2;
        float score=objects[i].score;
        int label=objects[i].label;
        if (x1 < 1) x1 = 1;
        if (y1 < 1) y1 = 1;
        
        if (x2 >= orig_img.cols) x2 = orig_img.cols - 1;
        if (y2 >= orig_img.rows) y2 = orig_img.rows - 1;
        
        int tof_rgb_x1 = x1 / src_frame_x_to_tof_scale;
        int tof_rgb_y1 = y1 / src_frame_y_to_tof_scale;

        int tof_rgb_x2 = x2 / src_frame_x_to_tof_scale;
        int tof_rgb_y2 = y2 / src_frame_y_to_tof_scale;

        int index1 = tof_rgb_y1 * m_tof_params.getTofCameraWidth() + tof_rgb_x1;
        int index2 = tof_rgb_y2 * m_tof_params.getTofCameraHeight() + tof_rgb_x2;

        TAIObejectDetectData object_detect_result;
        object_detect_result.object_detect_score = score;
        object_detect_result.tof_rgb_x1 = tof_rgb_x1;
        object_detect_result.tof_rgb_y1 = tof_rgb_y1;
        object_detect_result.tof_rgb_x2 = tof_rgb_x2;
        object_detect_result.tof_rgb_y2 = tof_rgb_y2;    

        object_detect_result.detect_x1 = x1;
        object_detect_result.detect_y1 = y1;
        object_detect_result.detect_x2 = x2;
        object_detect_result.detect_y2 = y2;

        object_detect_result.dirty_class=(TAIObjectClass)(1039+label);
        detect_results.push_back(object_detect_result);

        CLog::log(LogKimbo, LogNormal, "[yolo] (%d %d %d %d %f %d )\n", x1,y1,x2,y2,score,label);


        rectangle(orig_img, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(255, 0, 0, 255), 3);
        putText(orig_img, class_name_yolo3[label].c_str() + std::to_string(score)  , cv::Point(x1, y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
        std::string path= "/userdata/app/bin/"+std::to_string(getCurrentLocalTimeStamp())+"_detect.jpg";
      //  cv::imwrite(path, orig_img);




    }

}



int NanoDet::nano_det(const cv::Mat& bgr, std::vector<BoxInfo>& objects, float score_threshold, float nms_threshold)
{
    cv::Mat img = bgr.clone();


    int ret=0;
    int img_w = bgr.cols;
    int img_h = bgr.rows;
    int img_width=416;
    int img_height=416;


    cv::Mat resized_img;
    object_rect effect_roi;
    resize_uniform(img, resized_img, cv::Size(img_width, img_height), effect_roi);

  //  imwrite("resize.jpg",resized_img);
  //  mat_print(resized_img);

    if(!bgr.data) {
        printf("cv::imread fail!\n");
        return -1;
    }
    img=resized_img;
    if(img.cols != img_height || img.rows != img_height) {
        printf("resize %d %d to %d %d\n", img.cols, img.rows, img_width, img_height);
        cv::resize(img, img, cv::Size(img_width, img_height), (0, 0), (0, 0), cv::INTER_CUBIC);
    }
 //    cv::cvtColor(img,img,cv::COLOR_BGR2RGB);

    // Get Model Input Output Info
    rknn_input_output_num io_num;
    ret = rknn_query(m_ctx, RKNN_QUERY_IN_OUT_NUM, &io_num, sizeof(io_num));
    if (ret != RKNN_SUCC) {
        printf("rknn_query fail! ret=%d\n", ret);
        return -1;
    }
    printf("model input num: %d, output num: %d\n", io_num.n_input, io_num.n_output);

    printf("input tensors:\n");
    rknn_tensor_attr input_attrs[io_num.n_input];
    memset(input_attrs, 0, sizeof(input_attrs));
    for (int i = 0; i < io_num.n_input; i++) {
        input_attrs[i].index = i;
        ret = rknn_query(m_ctx, RKNN_QUERY_INPUT_ATTR, &(input_attrs[i]), sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            printf("rknn_query fail! ret=%d\n", ret);
            return -1;
        }
        printRKNNTensor(&(input_attrs[i]));
    }

    printf("output tensors:\n");
    rknn_tensor_attr output_attrs[io_num.n_output];
    memset(output_attrs, 0, sizeof(output_attrs));
    for (int i = 0; i < io_num.n_output; i++) {
        output_attrs[i].index = i;
        ret = rknn_query(m_ctx, RKNN_QUERY_OUTPUT_ATTR, &(output_attrs[i]), sizeof(rknn_tensor_attr));
        if (ret != RKNN_SUCC) {
            printf("rknn_query fail! ret=%d\n", ret);
            return -1;
        }
        printRKNNTensor(&(output_attrs[i]));
    }

    // Set Input Data
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].size = img.cols*img.rows*img.channels();
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = img.data;

    ret = rknn_inputs_set(m_ctx, io_num.n_input, inputs);
    if(ret < 0) {
        printf("rknn_input_set fail! ret=%d\n", ret);
        return -1;
    }

    // Run
    printf("rknn_run\n");

    int64 t1=getCurrentLocalTimeStamp();
    ret = rknn_run(m_ctx, nullptr);
    if(ret < 0) {
        printf("rknn_run fail! ret=%d\n", ret);
        return -1;
    }

    // Get Output
    rknn_output outputs[1];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 1;
 //   outputs[1].want_float = 1;
    ret = rknn_outputs_get(m_ctx, io_num.n_output, outputs, NULL);
    if(ret < 0) {
        printf("rknn_outputs_get fail! ret=%d\n", ret);
        return -1;
    }


    std::vector<std::vector<BoxInfo>> results;
    results.resize(this->num_class);

    std::cout<<"reference time:"<<getCurrentLocalTimeStamp()-t1<<std::endl;

    std::vector<CenterPrior> center_priors;
    generate_grid_center_priors(img_size[0], img_size[1], this->strides, center_priors);

    this->decode_infer((float*)outputs[0].buf, center_priors, score_threshold, results);

    std::vector<BoxInfo> dets;


    for (int i = 0; i < (int)results.size(); i++)
    {
        this->nms(results[i], nms_threshold);

        for (auto box : results[i])
        {
            dets.push_back(box);
        }
    }
    std::cout<<"box num:"<<dets.size()<<std::endl;

   // draw_bboxes(bgr, dets, effect_roi);


    int src_w = bgr.cols;
    int src_h = bgr.rows;
    int dst_w = effect_roi.width;
    int dst_h = effect_roi.height;
    float width_ratio = (float)src_w / (float)dst_w;
    float height_ratio = (float)src_h / (float)dst_h;


    for (size_t i = 0; i < dets.size(); i++)
    {
        BoxInfo bbox = dets[i];
        bbox.x1=(bbox.x1 - effect_roi.x) * width_ratio;
        bbox.y1=(bbox.y1 - effect_roi.y) * height_ratio;
        bbox.x2=(bbox.x2 - effect_roi.x) * width_ratio;
        bbox.y2=(bbox.y2 - effect_roi.y) * height_ratio;
        objects.push_back(bbox);

    }
    rknn_outputs_release(m_ctx, 1, outputs);
    return 0;
}



void NanoDet::decode_infer(float* feats, std::vector<CenterPrior>& center_priors, float threshold, std::vector<std::vector<BoxInfo>>& results)
{
    const int num_points = center_priors.size();
    //printf("num_points:%d\n", num_points);

    //cv::Mat debug_heatmap = cv::Mat(feature_h, feature_w, CV_8UC3);
    for (int idx = 0; idx < num_points; idx++)
    {
        const int ct_x = center_priors[idx].x;
        const int ct_y = center_priors[idx].y;
        const int stride = center_priors[idx].stride;

        int index=idx * (this->num_class+32);
        float* scores = feats+index;
        float score = 0;
        int cur_label = 0;
        for (int label = 0; label < this->num_class; label++)
        {
            if (scores[label] > score)
            {
                score = scores[label];
                cur_label = label;
            }
            if(idx==0)
            {
                std::cout<<scores[label]<<std::endl;
            }
        }
        if(idx==0)
        {
            std::cout<<"xxxxxxxx"<<std::endl;

            const float* bbox_pred = feats+index + this->num_class;
            for(int kk=0;kk<8;kk++)
            {
                std::cout<<bbox_pred[kk]<<std::endl;
            }
        }
        if (score > threshold)
        {
            //std::cout << "label:" << cur_label << " score:" << score << std::endl;
            const float* bbox_pred = feats+index + this->num_class;
            results[cur_label].push_back(this->disPred2Bbox(bbox_pred, cur_label, score, ct_x, ct_y, stride));
            //debug_heatmap.at<cv::Vec3b>(row, col)[0] = 255;
            //cv::imshow("debug", debug_heatmap);
        }
    }
}

BoxInfo NanoDet::disPred2Bbox(const float*& dfl_det, int label, float score, int x, int y, int stride)
{
    float ct_x = x * stride;
    float ct_y = y * stride;
    std::vector<float> dis_pred;
    dis_pred.resize(4);
    for (int i = 0; i < 4; i++)
    {
        float dis = 0;
        float* dis_after_sm = new float[this->reg_max + 1];
        activation_function_softmax(dfl_det + i * (this->reg_max + 1), dis_after_sm, this->reg_max + 1);
        for (int j = 0; j < this->reg_max + 1; j++)
        {
            dis += j * dis_after_sm[j];
        }
        dis *= stride;
        //std::cout << "dis:" << dis << std::endl;
        dis_pred[i] = dis;
        delete[] dis_after_sm;
    }
    float xmin = (std::max)(ct_x - dis_pred[0], .0f);
    float ymin = (std::max)(ct_y - dis_pred[1], .0f);
    float xmax = (std::min)(ct_x + dis_pred[2], (float)this->input_size[0]);
    float ymax = (std::min)(ct_y + dis_pred[3], (float)this->input_size[1]);

    //std::cout << xmin << "," << ymin << "," << xmax << "," << xmax << "," << std::endl;
    return BoxInfo { xmin, ymin, xmax, ymax, score, label };
}

void NanoDet::nms(std::vector<BoxInfo>& input_boxes, float nms_thread)
{
    std::sort(input_boxes.begin(), input_boxes.end(), [](BoxInfo a, BoxInfo b) { return a.score > b.score; });
    std::vector<float> vArea(input_boxes.size());
    for (int i = 0; i < int(input_boxes.size()); ++i) {
        vArea[i] = (input_boxes.at(i).x2 - input_boxes.at(i).x1 + 1)
                   * (input_boxes.at(i).y2 - input_boxes.at(i).y1 + 1);
    }
    for (int i = 0; i < int(input_boxes.size()); ++i) {
        for (int j = i + 1; j < int(input_boxes.size());) {
            float xx1 = (std::max)(input_boxes[i].x1, input_boxes[j].x1);
            float yy1 = (std::max)(input_boxes[i].y1, input_boxes[j].y1);
            float xx2 = (std::min)(input_boxes[i].x2, input_boxes[j].x2);
            float yy2 = (std::min)(input_boxes[i].y2, input_boxes[j].y2);
            float w = (std::max)(float(0), xx2 - xx1 + 1);
            float h = (std::max)(float(0), yy2 - yy1 + 1);
            float inter = w * h;
            float ovr = inter / (vArea[i] + vArea[j] - inter);
            if (ovr >= nms_thread) {
                input_boxes.erase(input_boxes.begin() + j);
                vArea.erase(vArea.begin() + j);
            }
            else {
                j++;
            }
        }
    }
}

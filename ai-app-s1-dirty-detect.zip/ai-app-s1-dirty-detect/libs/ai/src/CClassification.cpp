/**********************************************************************************
File name:	  CClassification.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CClassification.h>
#include <everest/base/CTime.h>
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;
/***********************************************************************************
Function:     CClassification
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassification::CClassification()
{
	std::string floor_blanket_model_path = "/userdata/AI/floor_blanket_class_model.rknn";
	m_floor_blanket_net_classication = new CEfficientNetClassification(CLASS_MODLE_TYPE_FLOOR_BLANKET,128,128,floor_blanket_model_path);
}

/***********************************************************************************
Function:     ~CClassification
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CClassification::~CClassification()
{
    
}

/***********************************************************************************
Function:     ~classModelAreOk
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassification::classModelAreOk()
{
    return m_efficient_net_classification.efficientnet_init_success();
}

/***********************************************************************************
Function:     detectObject
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassification::classification(CImage &input_image, TAIObejectDetectData &detect_data)
{   
	base::TTimeStamp class_first_behand_process_data_time = CTime::getCpuTime();
	cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();
	//相机获取到的图片是BRG格式图片，需转换成RGB格式送入分类模型
	//实际测试，图片经过转换后才能识别
	cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);
	// printf("time-statics===ClassBeforeHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(class_first_behand_process_data_time,  CTime::getCpuTime()));
	if(m_efficient_net_classification.runEfficientNetClassifiaction(src_image, detect_data))
	{
		return true;
	}
	else 
	{
		return true;
	}
}


/***********************************************************************************
Function:     classificationFloorBlanket
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CClassification::classificationFloorBlanket(CImage &input_image, TAIObejectDetectData &detect_data)
{   
	base::TTimeStamp class_first_behand_process_data_time = CTime::getCpuTime();
	cv::Mat src_image = cv::Mat();
	src_image = input_image.getImage().clone();
	//相机获取到的图片是BRG格式图片，需转换成RGB格式送入分类模型
	//实际测试，图片经过转换后才能识别
	cv::cvtColor(src_image, src_image, cv::COLOR_BGR2RGB);
	// printf("time-statics===ClassBeforeHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(class_first_behand_process_data_time,  CTime::getCpuTime()));
	if(m_floor_blanket_net_classication->runEfficientNetClassifiaction(src_image, detect_data))
	{
		return true;
	}
	else 
	{
		return true;
	}
}

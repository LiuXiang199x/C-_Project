/**********************************************************************************
File name:	  CTofParameters.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CTofParameters.h>
#include <stdlib.h>

/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;

/***********************************************************************************
Function:     CTofParameters
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTofParameters::CTofParameters():
                m_tof_camera_width(224.0),
                m_tof_camera_height(172.0)
{
	
}

/***********************************************************************************
Function:     CTofParameters
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTofParameters::~CTofParameters()
{
    
}

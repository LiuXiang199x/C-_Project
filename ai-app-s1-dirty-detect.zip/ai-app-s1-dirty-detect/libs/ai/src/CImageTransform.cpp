/**********************************************************************************
File name:	  CImageTransform.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CImageTransform.h>


/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;

/***********************************************************************************
Function:     CImageTransform
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImageTransform::CImageTransform():
				 m_resize_ratio(0.166)
{
	
}

/***********************************************************************************
Function:     CImageTransform
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CImageTransform::~CImageTransform()
{
    
}

/***********************************************************************************
Function:     fishRemap
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
cv::Mat CImageTransform::fishRemap(cv::Mat &origin_image)
{
	cv::Mat dest_mat = origin_image.clone();
	cv::remap(origin_image, dest_mat, m_camera_params.getMapX(), 
					   m_camera_params.getMapY(), cv::INTER_LINEAR);

	return dest_mat;
}

/***********************************************************************************
Function:     resizeImage
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
cv::Mat CImageTransform::resizeImage(cv::Mat &origin_image)
{
	if (origin_image.empty())
	{
		return origin_image;
	}

	int src_width = origin_image.cols;
	int src_height = origin_image.rows;

	int deta_w = src_width * m_resize_ratio;
	int deta_h = src_height * m_resize_ratio;

	int dest_w = src_width - 2 * deta_w;
	int dest_h = src_height - 2 * deta_h;

	return origin_image(cv::Rect(deta_w, deta_h, dest_w, dest_h));
}

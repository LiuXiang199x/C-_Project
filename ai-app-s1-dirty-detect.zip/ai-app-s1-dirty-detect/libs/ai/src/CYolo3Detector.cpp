/**********************************************************************************
File name:	  CYolo3Detector.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CYolo3Detector.h>

#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <fstream>
#include <iostream>
#include <everest/base/CTime.h>
#include <everest/base/CLog.h>
#include <everest/base/CLogUtitls.h>
#include<sys/time.h>
#include <unistd.h>
#include<chrono>
#include<fstream>





#include <sys/stat.h>

/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;




static int64_t getCurrentLocalTimeStamp()
{
	std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> tp = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
	auto tmp = std::chrono::duration_cast<std::chrono::milliseconds>(tp.time_since_epoch());
	return tmp.count();

	// return std::chrono::duration_cast(std::chrono::system_clock::now().time_since_epoch()).count();
}




int FileExist(const char* fname)
{
    return access(fname,0);
}

/***********************************************************************************
Function:     CYolo3Detector
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CYolo3Detector::CYolo3Detector():
				m_model_yolo3(NULL),
                m_network_input_width(320),
                m_network_input_height(320)
{
	m_yolo3_model_init_success = initYoloDector();

}

/***********************************************************************************
Function:     ~CYolo3Detector
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CYolo3Detector::~CYolo3Detector()
{
    if(m_ctx_yolo3 >= 0) 
	{
        rknn_destroy(m_ctx_yolo3);
    }
    if(m_model_yolo3) 
	{
        free(m_model_yolo3);
    }
}

/***********************************************************************************
Function:     loadModel
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
unsigned char *CYolo3Detector::loadModel(const char *filename, int *model_size)
{
    FILE *fp = fopen(filename, "rb");
    if(fp == nullptr) 
	{
        printf("fopen %s fail!\n", filename);
        return NULL;
    }

    fseek(fp, 0, SEEK_END);
    
	int model_len = ftell(fp);
    unsigned char *model = (unsigned char*)malloc(model_len);

    fseek(fp, 0, SEEK_SET);

    if(model_len != fread(model, 1, model_len, fp)) 
	{
        printf("fread %s fail!\n", filename);
        free(model);
        return NULL;
    }

    *model_size = model_len;

    if(fp) 
	{
        fclose(fp);
    }

    return model;
}

/***********************************************************************************
Function:     ~CYolo3Detector
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CYolo3Detector::printRKNNTensor(rknn_tensor_attr *attr) 
{
    printf("index=%d name=%s n_dims=%d dims=[%d %d %d %d] n_elems=%d size=%d fmt=%d \
			type=%d qnt_type=%d fl=%d zp=%d scale=%f\n", 
            attr->index, attr->name, attr->n_dims, attr->dims[3], attr->dims[2], attr->dims[1], attr->dims[0], 
            attr->n_elems, attr->size, 0, attr->type, attr->qnt_type, attr->fl, attr->zp, attr->scale);
}

/***********************************************************************************
Function:     ~CYolo3Detector
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CYolo3Detector::initYoloDector()
{
	char *yolo_model_path = "/userdata/AI/yolo4_tiny.rknn";
	int model_len_yolo3 = 0;

    // Load RKNN model_yolo3
	m_model_yolo3 = loadModel(yolo_model_path, &model_len_yolo3);
    if(m_model_yolo3 == NULL) 
	{
        CLog::log(LogKimbo, LogNormal, "[CRobotAi] yolo model load failed!\n");
        printf("yolo model load failed\n");
        return false;
    }

	int ret_yolo3 = rknn_init(&m_ctx_yolo3, m_model_yolo3, model_len_yolo3, 0);
    if(ret_yolo3 < 0) 
	{
        CLog::log(LogKimbo, LogNormal, "[CRobotAi] rknn_init fail!!\n");
        printf("rknn_init fail! ret_yolo3= %d\n", ret_yolo3);
        return false;
    }

    // Get model_yolo3 Input Output Info
    ret_yolo3 = rknn_query(m_ctx_yolo3, RKNN_QUERY_IN_OUT_NUM, &m_io_num_yolo3, sizeof(m_io_num_yolo3));
    if (ret_yolo3 != RKNN_SUCC) 
	{
            CLog::log(LogKimbo, LogNormal, "[CRobotAi] rknn_query fail!!\n");
        printf("rknn_query fail! ret_yolo3=%d\n", ret_yolo3);
        return false;
    }

    printf("model_yolo3 input num: %d, output num: %d\n", m_io_num_yolo3.n_input, m_io_num_yolo3.n_output);
    
    printf("input tensors:\n");
    memset(m_input_attrs_yolo3, 0, sizeof(m_input_attrs_yolo3));
    for (int i = 0; i < m_io_num_yolo3.n_input; i++) 
	{
        m_input_attrs_yolo3[i].index = i;
        ret_yolo3 = rknn_query(m_ctx_yolo3, RKNN_QUERY_INPUT_ATTR, &(m_input_attrs_yolo3[i]), sizeof(rknn_tensor_attr));
        if (ret_yolo3 != RKNN_SUCC) 
		{
               CLog::log(LogKimbo, LogNormal, "[CRobotAi] rknn_query fail! fail!!\n");
            printf("rknn_query fail! ret_yolo3=%d\n", ret_yolo3);
            return false;
        }
        printRKNNTensor(&(m_input_attrs_yolo3[i]));
    }

    printf("output tensors:\n");
    memset(m_output_attrs_yolo3, 0, sizeof(m_output_attrs_yolo3));
    for (int i = 0; i < m_io_num_yolo3.n_output; i++) 
	{
        m_output_attrs_yolo3[i].index = i;
        ret_yolo3 = rknn_query(m_ctx_yolo3, RKNN_QUERY_OUTPUT_ATTR, &(m_output_attrs_yolo3[i]), sizeof(rknn_tensor_attr));
        if (ret_yolo3 != RKNN_SUCC) 
		{
            CLog::log(LogKimbo, LogNormal, "[CRobotAi] rknn_query fail! fail! fail!! 333\n");
            printf("rknn_query fail! ret_yolo3=%d\n", ret_yolo3);
            return false;
        }
        printRKNNTensor(&(m_output_attrs_yolo3[i]));
    }

    printf("initial yolo3 successfully!!!\n");

	return true;
}

/***********************************************************************************
Function:     intersectionArea
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
float CYolo3Detector::mySigmoid(float x)
{
	return 1/(1 +exp(-x));
}

/***********************************************************************************
Function:     intersectionArea
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
float CYolo3Detector::intersectionArea(const TObject *a, const TObject *b)
{
	float left_ = a->rect.left > b->rect.left ? a->rect.left:b->rect.left;
	float top_ = a->rect.top > b->rect.top ? a->rect.top:b->rect.top;
	float right_ = a->rect.right < b->rect.right ? a->rect.right:b->rect.right;
	float bottom_ = a->rect.bottom < b->rect.bottom ? a->rect.bottom:b->rect.bottom;
	float width = right_ -left_ > 0 ? right_ -left_ : 0;
	float height = bottom_ -top_ > 0 ? bottom_ -top_ : 0;

    return height*width;
}

/***********************************************************************************
Function:     nmsSortedBboxes
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CYolo3Detector::nmsSortedBboxes(TObject * objects, int obj_num, int *picked, float nms_threshold)
{
    const int n = obj_num;

	std::vector<float> areas(n);
    for (int i = 0; i < n; i++)
    {
		areas[i] = (objects[i].rect.bottom - objects[i].rect.top) * (objects[i].rect.right - objects[i].rect.left);
    }

    int picked_size = 0;

    for (int i = 0; i < n; i++)
    {
        const TObject a = objects[i];

        int keep = 1;
        for (int j = 0; j < picked_size; j++)
		{
            const TObject b = objects[picked[j]];

            // intersection over union
            float inter_area = intersectionArea(&a, &b);
            float union_area = areas[i] + areas[picked[j]] - inter_area;
            if (inter_area / union_area > nms_threshold)
                keep = 0;
        }

        if (keep) {
            picked[picked_size++] = i;
        }
    }

    return picked_size;
}

/***********************************************************************************
Function:     processFeats0
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CYolo3Detector::processFeats0(float output[1][GRID0][GRID0][SPAN][LISTSIZE], int anchors[SPAN][2], float obj_threshold, 
								   float* boxes, int* box_class, float* box_score, int* num_candida)
{
	int num = 0;
	for (int i = 0; i < GRID0; i++)
	{
		for (int j = 0; j < GRID0; j++)
		{
			for (int k = 0; k < SPAN; k++)
			{
				float* data = &output[0][i][j][k][0];
				float confidence = mySigmoid(data[4]);
				int seq_maxscore = std::max_element(&data[5], &data[5] + NUM_CLS) -&data[5];
				float maxscore = mySigmoid(data[5 +seq_maxscore]) *confidence;
                if(maxscore < obj_threshold)
                    continue;
				float x = mySigmoid(data[0]);
				float y = mySigmoid(data[1]);
				float w = exp(data[2]) *anchors[k][0] /m_network_input_width;
				float h = exp(data[3]) *anchors[k][1] /m_network_input_width;
				x = (x +j)/GRID0 -w/2;
				y = (y +i)/GRID0 -h/2;
				boxes[num*4 +0] = x;
				boxes[num*4 +1] = y;
				boxes[num*4 +2] = w;
				boxes[num*4 +3] = h;
				box_class[num] = seq_maxscore;
				box_score[num] = maxscore;

				num++;
			}
		}
	}
	*num_candida = num;
}

/***********************************************************************************
Function:     processFeats1
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CYolo3Detector::processFeats1(float output[1][GRID1][GRID1][SPAN][LISTSIZE], int anchors[SPAN][2], float obj_threshold,
								   float* boxes, int* box_class, float* box_score, int* num_candida)
{
	int num = 0;
	for (int i = 0; i < GRID1; i++)
	{
		for (int j = 0; j < GRID1; j++)
		{
			for (int k = 0; k < SPAN; k++)
			{
				float* data = &output[0][i][j][k][0];
				float confidence = mySigmoid(data[4]);
				int seq_maxscore = std::max_element(&data[5], &data[5] + NUM_CLS) -&data[5];
				float maxscore = mySigmoid(data[5 +seq_maxscore]) *confidence;
				if(maxscore < obj_threshold)
					continue;
				float x = mySigmoid(data[0]);
				float y = mySigmoid(data[1]);
				float w = exp(data[2]) *anchors[k][0] /m_network_input_width;
				float h = exp(data[3]) *anchors[k][1] /m_network_input_width;
				x = (x +j)/GRID1 -w/2;
				y = (y +i)/GRID1 -h/2;
				boxes[num*4 +0] = x;
				boxes[num*4 +1] = y;
				boxes[num*4 +2] = w;
				boxes[num*4 +3] = h;
				box_class[num] = seq_maxscore;
				box_score[num] = maxscore;
				num++;
			}
		}
	}
	*num_candida = num;
}

/***********************************************************************************
Function:     qsortDescentInplace
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CYolo3Detector::qsortDescentInplace(TObject* objects, int left, int right)
{
    int i = left;
    int j = right;
    float p = objects[(left + right) / 2].prob;

    while (i <= j)
    {
        while (objects[i].prob > p)
            i++;

        while (objects[j].prob < p)
            j--;

        if (i <= j)
        {
            // swap
            std::swap(objects[i], objects[j]);

            i++;
            j--;
        }
    }

    if (left < j) qsortDescentInplace(objects, left, j);
    if (i < right) qsortDescentInplace(objects, i, right);   
}

/***********************************************************************************
Function:     qsortDescentInplace
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CYolo3Detector::qsortDescentInplace(TObject* objects, int size)
{
    if (size == 0)
        return;

    qsortDescentInplace(objects, 0, size - 1);
}

/***********************************************************************************
Function:     yolov3PostProcess
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CYolo3Detector::process(float output0[1][GRID0][GRID0][SPAN][LISTSIZE], 
							float output1[1][GRID1][GRID1][SPAN][LISTSIZE], 
						    float* out_pos, float* out_prop, int* out_label)
{
    //yolov3
	// int anchors0[SPAN][2] = {{47,39},  {69,29},  {84,47}};
	// int anchors1[SPAN][2] = {{32,24},  {45,23},  {47,39}};
    
    int anchors0[SPAN][2] = {{55,42},  {62,27},  {91,49}};
	int anchors1[SPAN][2] = {{31,20},  {40,30},  {55,42}};

    //K-MEAN ANCHOR
    // int anchors0[SPAN][2] = {{86,181},  {92,43},  {174,204}};
    // int anchors1[SPAN][2] = {{23,17},   {30,45},  {44,100}};

    float result_buffer[63882];

	//three result
	float* boxes = &result_buffer[0];
	int* box_class = (int*)&result_buffer[42588];
	float* box_score = &result_buffer[53235];

	int num_candida0 = 0;
	processFeats0(output0, anchors0, OBJ_THRESH, boxes, box_class, box_score, &num_candida0);
	int num_candida1 = 0;
	processFeats1(output1, anchors1, OBJ_THRESH, &boxes[4 *num_candida0], 
				   &box_class[num_candida0], &box_score[num_candida0], &num_candida1);

	int num_candida = num_candida0 +num_candida1;

	if (num_candida == 0)
	{
		return 0;
	}
	
	if(num_candida > MAX_BOX)
	{
		num_candida = MAX_BOX;
	}
	
	int out_num = 0;

	TObject *allcandidates = (TObject*) malloc(num_candida * sizeof(TObject));
	
	for (int i = 0; i < num_candida; i++){
		allcandidates[i].rect.left =  boxes[4*i +0];
		allcandidates[i].rect.top =  boxes[4*i +1];
		allcandidates[i].rect.right =  allcandidates[i].rect.left +boxes[4*i +2];
		allcandidates[i].rect.bottom =  allcandidates[i].rect.top +boxes[4*i +3];
		allcandidates[i].prob = box_score[i];
		allcandidates[i].label = box_class[i];
		
	}

	qsortDescentInplace(allcandidates, num_candida);
	
	TObject *cla_candidates = (TObject*) malloc(num_candida * sizeof(TObject));
	
	for (int cla = 0; cla < NUM_CLS; cla++) 
	{	
		int cla_candidate_num = 0;
		for (int i = 0; i < num_candida; i++)
		{
			if(allcandidates[i].label == cla)
			{
				cla_candidates[cla_candidate_num++] = allcandidates[i];
			}
		}

		if(cla_candidate_num == 0)
			continue;
		
		
		int picked[MAX_BOX];
		memset(picked, -1, MAX_BOX);
		int picked_size = nmsSortedBboxes(cla_candidates, cla_candidate_num, picked, NMS_THRESH);
		
		for (int j = 0; j < picked_size; j++)
		{
			int z = picked[j];
			if(z < 0)
				printf("post_process_nms_error\n");
			out_pos[out_num * 4 + 0] = cla_candidates[z].rect.left;
			out_pos[out_num * 4 + 1] = cla_candidates[z].rect.top;
			out_pos[out_num * 4 + 2] = cla_candidates[z].rect.right;
			out_pos[out_num * 4 + 3] = cla_candidates[z].rect.bottom;
			out_prop[out_num] = cla_candidates[z].prob;
			out_label[out_num] = cla_candidates[z].label;
			out_num++;
			
		}
		
	}

	free(cla_candidates);
	free(allcandidates);

	return out_num;
}

/***********************************************************************************
Function:     yolov3PostProcess
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CYolo3Detector::yolov3PostProcess(float* input0, float* input1, float* out_pos, float* out_prop, int* out_label)
{
    float buffer[LISTSIZE *SPAN *(GRID0 *GRID0 + GRID1 *GRID1 + GRID2 *GRID2)];
    
	float(&output0)[1][GRID0][GRID0][SPAN][LISTSIZE] = *((float(*)[1][GRID0][GRID0][SPAN][LISTSIZE])buffer);
	float(&output1)[1][GRID1][GRID1][SPAN][LISTSIZE] = *((float(*)[1][GRID1][GRID1][SPAN][LISTSIZE])(buffer + LISTSIZE *SPAN *GRID0 *GRID0));

	for (int i = 0; i < SPAN; i++){
		for (int j = 0; j < LISTSIZE; j++){

			int bias0 = i*LISTSIZE*GRID0*GRID0+ j*GRID0*GRID0;
			for (int k = 0; k < GRID0; k++){
				int bias_k = bias0 + k*GRID0;
				for (int l = 0; l < GRID0; l++){
					output0[0][k][l][i][j] = input0[(bias_k+l)];
				}
			}

			int bias1 = i*LISTSIZE*GRID1*GRID1+ j*GRID1*GRID1;
			for (int k = 0; k < GRID1; k++){
				int bias_k = bias1 + k*GRID1;
				for (int l = 0; l < GRID1; l++){
					output1[0][k][l][i][j] = input1[bias_k+l];
				}
			}

		}
	}

	int object_num = process(output0, output1, out_pos, out_prop, out_label);
	return object_num;
}

/***********************************************************************************
Function:     runYoloDector
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/


bool CYolo3Detector::runYoloDector(cv::Mat src_img, std::vector<TAIObejectDetectData> &detect_results)
{

        struct timeval  tv;
        gettimeofday(&tv, NULL);
        double time_in_mill = (tv.tv_sec) * 1000 + (tv.tv_usec) / 1000 ;
  
    
        std::string path=  std::to_string(time_in_mill)+"_src.jpg";
   //     cv::imwrite(path, src_img);





    base::TTimeStamp yolo_second_behand_process_data_time = CTime::getCpuTime();
    if(src_img.empty() || src_img.cols == 0 || src_img.rows == 0)
    {
        return false;
    }

    if(!m_yolo3_model_init_success){
        return false;
    }
    



    cv::Mat orig_img = src_img.clone();
    cv::Mat img = orig_img.clone();
    
    if(orig_img.cols != m_network_input_width || 
	   orig_img.rows != m_network_input_height) 
	{
        cv::resize(orig_img, img, cv::Size(m_network_input_width, 
				   m_network_input_height), (0, 0), (0, 0), cv::INTER_LINEAR);
    }
//    cv::cvtColor(img,img,cv::COLOR_BGR2RGB);
    
    // Set Input Data
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].size = img.cols*img.rows*img.channels();
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = img.data;

    int ret_yolo3 = rknn_inputs_set(m_ctx_yolo3, m_io_num_yolo3.n_input, inputs);
    if(ret_yolo3 < 0) 
	{
        printf("rknn_input_set fail! ret_yolo3=%d\n", ret_yolo3);
        return false;
    }
    // printf("time-statics===YoloBeforeHandData2===cost-time:%f ms\n",1000 * CTime::timeDifference(yolo_second_behand_process_data_time,  CTime::getCpuTime()));
    // Run
    base::TTimeStamp start_run_yolo_time = CTime::getCpuTime();
    ret_yolo3 = rknn_run(m_ctx_yolo3, nullptr);
    base::TTimeStamp end_run_yolo_time = CTime::getCpuTime();
    // printf("time-statics===RunYoloTime===cost-time:%f ms\n",1000 * CTime::timeDifference(start_run_yolo_time,  end_run_yolo_time));

    if(ret_yolo3 < 0) 
	{
        printf("rknn_run fail! ret_yolo3=%d\n", ret_yolo3);
        return false;
    }
    base::TTimeStamp yolo_second_after_process_data_time = CTime::getCpuTime();
    // Get Output
    rknn_output outputs[2];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 1;
    outputs[1].want_float = 1;
    ret_yolo3 = rknn_outputs_get(m_ctx_yolo3, m_io_num_yolo3.n_output, outputs, NULL);
    if(ret_yolo3 < 0) 
	{
        printf("rknn_outputs_get fail! ret_yolo3=%d\n", ret_yolo3);
        return false;
    }

    float out_pos[500*4];
    float out_prop[500];
    int out_label[500];
    int obj_num = 0;

    // Post Process
    obj_num = yolov3PostProcess((float *)(outputs[0].buf), (float *)(outputs[1].buf), out_pos, out_prop, out_label);
    
    // Release rknn_outputs
    rknn_outputs_release(m_ctx_yolo3, 2, outputs);

    std::vector<TAIObejectDetectData> results;
    const float src_frame_x_to_tof_scale = orig_img.cols / m_tof_params.getTofCameraWidth();
    const float src_frame_y_to_tof_scale = orig_img.rows / m_tof_params.getTofCameraHeight();

    // Draw Objects
    const std::string class_name_yolo3[] = {"liquid","powder","hair"};

    for (int i = 0; i < obj_num; i++) 
    {
        printf("%s @ (%f %f %f %f) %f\n", class_name_yolo3[out_label[i]].c_str(), 
                out_pos[4*i+0], out_pos[4*i+1], out_pos[4*i+2], out_pos[4*i+3], out_prop[i]);

        int x1 = out_pos[4*i+0] * orig_img.cols;
        int y1 = out_pos[4*i+1] * orig_img.rows;
        int x2 = out_pos[4*i+2] * orig_img.cols;
        int y2 = out_pos[4*i+3] * orig_img.rows; 

        if (x1 < 1) x1 = 1;
        if (y1 < 1) y1 = 1;
        
        if (x2 >= orig_img.cols) x2 = orig_img.cols - 1;
        if (y2 >= orig_img.rows) y2 = orig_img.rows - 1;
        
        int tof_rgb_x1 = x1 / src_frame_x_to_tof_scale;
        int tof_rgb_y1 = y1 / src_frame_y_to_tof_scale;

        int tof_rgb_x2 = x2 / src_frame_x_to_tof_scale;
        int tof_rgb_y2 = y2 / src_frame_y_to_tof_scale;

        int index1 = tof_rgb_y1 * m_tof_params.getTofCameraWidth() + tof_rgb_x1;
        int index2 = tof_rgb_y2 * m_tof_params.getTofCameraHeight() + tof_rgb_x2;

        TAIObejectDetectData object_detect_result;
        object_detect_result.object_detect_score = out_prop[i];
        object_detect_result.tof_rgb_x1 = tof_rgb_x1;
        object_detect_result.tof_rgb_y1 = tof_rgb_y1;
        object_detect_result.tof_rgb_x2 = tof_rgb_x2;
        object_detect_result.tof_rgb_y2 = tof_rgb_y2;

        object_detect_result.detect_x1 = x1;
        object_detect_result.detect_y1 = y1;
        object_detect_result.detect_x2 = x2;
        object_detect_result.detect_y2 = y2;

        object_detect_result.dirty_class=(TAIObjectClass)(1039+out_label[i]);
        results.push_back(object_detect_result);

        float area = (y2 - y1)*(x2 - x1);
        float rate = area/(orig_img.rows * orig_img.cols);
      
        
        // printf("(%d %d %d %d)\n",x1,y1,x2,y2);
        CLog::log(LogKimbo, LogNormal, "[yolo] (%d %d %d %d %f %d )\n", x1,y1,x2,y2,out_prop[i],out_label[i]);


        rectangle(orig_img, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(255, 0, 0, 255), 3);
        putText(orig_img, class_name_yolo3[out_label[i]].c_str() + std::to_string(out_prop[i])  , cv::Point(x1, y1 - 12), 1, 2, cv::Scalar(0, 255, 0, 255));
        std::string path=  std::to_string(time_in_mill)+"_detect.jpg";
    //    cv::imwrite(path, orig_img);


    }
    // printf("time-statics===YoloAfterHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(yolo_second_after_process_data_time,  CTime::getCpuTime()));
    detect_results = results;

    std::cout<<"xxxxxxxx:"<<getCurrentLocalTimeStamp()<<std::endl;
    
  //  if(!FileExist())







    // if(g_saveIndex>g_maxSaveNumber)
    // {
    //     std::string strCMD="rm /userdata/*.jpg";
    //     shell_call(strCMD);


    //     g_saveIndex=0;
    // }
    // else
    // {
    //     std::string strPath="/userdata/"+std::to_string(g_saveIndex)+".jpg";
    //     cv::imwrite(strPath,orig_img);
        


    //     g_saveIndex++;
    // }



    if(obj_num > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
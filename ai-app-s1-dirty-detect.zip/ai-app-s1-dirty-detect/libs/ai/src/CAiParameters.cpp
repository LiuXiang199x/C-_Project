/**********************************************************************************
File name:	  CAiParameters.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CAiParameters.h>
#include <everest/base/CConfigFile.h>
#include <everest/base/CFilePath.h>
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;

/***********************************************************************************
Function:     CAiParameters
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CAiParameters::CAiParameters()
{
    m_ai_object_socks               = 0.84;
    m_ai_object_shoe                = 0.83;
    m_ai_object_wire                = 0.85;
    m_ai_object_chair_base          = 0.89;
    m_ai_object_blanket             = 0.82;
    m_ai_object_dog                 = 0.85;
    m_ai_object_cat                 = 0.85;
    m_ai_object_animal_food         = 0.82;
    m_ai_object_potato_chips        = 0.82;
    m_ai_object_seed_shell          = 0.82;
    m_ai_object_droppings           = 0.72;
    m_ai_object_slipper             = 0.82;
    m_ai_object_foot                = 0.82;
    m_ai_object_people              = 0.82;
    m_ai_object_people_laid         = 0.82;
    m_ai_object_door_threshold      = 0.82;
    m_ai_object_door                = 0.82;
    m_ai_object_dirt                = 0.55;
    m_ai_object_weight_scale        = 0.70;
    m_ai_object_metal_chair_foot    = 0.70;
    m_ai_object_charger             = 0.70;

    m_ai_object_furniture           = 0.82;
    m_ai_object_dining_table        = 0.82;
    m_ai_object_sofa                = 0.82;
    m_ai_object_bed                 = 0.82;
    m_ai_object_closestool          = 0.75;
    m_ai_object_cupboard            = 0.82;
    m_ai_object_refrigerator        = 0.82;
    m_ai_object_washstand           = 0.82;
    m_ai_object_cabinet_tv          = 0.82;
    m_ai_object_cabinet_tea_table   = 0.82;
    m_ai_object_cabinet_bed         = 0.88;
    m_ai_object_washing_machine     = 0.82;

    m_ai_object_bed1                = 0.82;
    m_ai_object_sofa1               = 0.82;
    m_ai_object_refrigerator1       = 0.82;

    m_ai_floor_concrete             = 0.82;
    m_ai_floor_title                = 0.87;
    m_ai_floor_wood                 = 0.82;
    m_ai_floor_unknow               = 0.85;

    m_ai_object_wire_detect         = 0.55;
    m_ai_object_chair_base_detect   = 0.4528;
    m_ai_object_shoe_detect         = 0.4528;
    m_ai_object_socks_detect        = 0.4528;
    m_ai_object_weight_scale_detect = 0.4528;
    m_ai_object_detect              = 0.4528;
    m_ai_scene_detect               = 0.25;

    m_ai_unknown_object_class_min_score = 0.10;
    m_ai_unknown_object_detect_min_score = 0.10;
    
    
    m_image_upload_server_frequt    = 5;
    m_image_upload_server_floor_frequt = 3;
    m_image_upload_server_object_frequt = 1;
    m_object_detect_num_limit       = 1;
    m_image_upload_difference_limit_count = 5;
    
    memset(m_all_class_min_scores, 0.4528, MIN_SCORE_CLASS_COUNT);

    m_local_ai_mode             = base::AI_MODE_OUT_FAMILY_TEST;
    m_ai_mode_number            = 2;
    loadAllClassMinScores();
    loadAIConfig();

}

/***********************************************************************************
Function:     ~CAiParameters
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CAiParameters::~CAiParameters()
{
    
}

/***********************************************************************************
Function:     ~CAiParameters
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CAiParameters::getAiObjectClassSorceThreshold(TAIObjectClass object_class)
{
    switch (object_class)
    {
        case everest::ai::AI_OBJECT_SOCKS: return m_ai_object_socks;
        case everest::ai::AI_OBJECT_SHOE: return m_ai_object_shoe;
        case everest::ai::AI_OBJECT_WIRE: return m_ai_object_wire;
        case everest::ai::AI_OBJECT_CHAIR_BASE: return m_ai_object_chair_base;
        case everest::ai::AI_OBJECT_BLANKET: return m_ai_object_blanket;
        case everest::ai::AI_OBJECT_DOG: return m_ai_object_dog;
        case everest::ai::AI_OBJECT_CAT: return m_ai_object_cat;
        case everest::ai::AI_OBJECT_ANIMAL_FOOD: return m_ai_object_animal_food;
        case everest::ai::AI_OBJECT_POTATO_CHIPS: return m_ai_object_potato_chips;
        case everest::ai::AI_OBJECT_SEED_SHELL: return m_ai_object_seed_shell;
        case everest::ai::AI_OBJECT_DROPPINGS: return m_ai_object_droppings;
        case everest::ai::AI_OBJECT_WEIGHT_SCALE: return m_ai_object_weight_scale;
        case everest::ai::AI_OBJECT_CHARGER: return m_ai_object_charger;
        case everest::ai::AI_OBJECT_METAL_CHAIR_FOOT: return m_ai_object_metal_chair_foot;
        case everest::ai::AI_OBJECT_SLIPPER: return m_ai_object_slipper;
        case everest::ai::AI_OBJECT_FOOT: return m_ai_object_foot;
        case everest::ai::AI_OBJECT_DIRT: return m_ai_object_dirt;
        case everest::ai::AI_OBJECT_PEOPLE: return m_ai_object_people;
        case everest::ai::AI_OBJECT_PEOPLE_LAID: return m_ai_object_people_laid;
        case everest::ai::AI_OBJECT_DOOR_THRESHOLD: return m_ai_object_door_threshold;
        case everest::ai::AI_OBJECT_DOOR: return m_ai_object_door;
        case everest::ai::AI_OBJECT_FURNITURE: return m_ai_object_furniture;
        case everest::ai::AI_OBJECT_DINING_TABLE: return m_ai_object_dining_table;
        case everest::ai::AI_OBJECT_SOFA: return m_ai_object_sofa;
        case everest::ai::AI_OBJECT_BED: return m_ai_object_bed;
        case everest::ai::AI_OBJECT_WASHING_MACHINE: return m_ai_object_washing_machine;
        case everest::ai::AI_OBJECT_CLOSESTOOL: return m_ai_object_closestool;
        case everest::ai::AI_OBJECT_CUPBOARD: return m_ai_object_cupboard;
        case everest::ai::AI_OBJECT_REFRIGERATOR: return m_ai_object_refrigerator;
        case everest::ai::AI_OBJECT_WASHSTAND: return m_ai_object_washstand;
        case everest::ai::AI_OBJECT_CABINET_TV: return m_ai_object_cabinet_tv;
        case everest::ai::AI_OBJECT_CABINET_TEA_TABLE: return m_ai_object_cabinet_tea_table;
        case everest::ai::AI_OBJECT_CABINET_BED: return m_ai_object_cabinet_bed;
        case everest::ai::AI_FLOOR_CONCRETE: return m_ai_floor_concrete;
        case everest::ai::AI_FLOOR_TITLE: return m_ai_floor_title;
        case everest::ai::AI_FLOOR_WOOD: return m_ai_floor_wood;
        case everest::ai::AI_FLOOR_UNKNOW: return m_ai_floor_unknow;
        //weight
        case everest::ai::AI_OBJECT_SOFA1: return m_ai_object_sofa1;
        case everest::ai::AI_OBJECT_BED1: return m_ai_object_bed1;
        // case everest::ai::AI_OBJECT_DINING_TABLE1: return m_ai_object_dining_table1;
        case everest::ai::AI_OBJECT_REFRIGERATOR1: return m_ai_object_refrigerator1;
        // case everest::ai::AI_OBJECT_CLOSESTOOL1: return m_ai_object_closestool1;
        // case everest::ai::AI_OBJECT_WASHING_MACHINE1: return m_ai_object_washing_machine1;
        // case everest::ai::AI_OBJECT_CUPBOARD1: return m_ai_object_cupboard1;
        // case everest::ai::AI_OBJECT_CABINET_TV1: return m_ai_object_cabinet_tv1;
        // case everest::ai::AI_OBJECT_CABINET_BED1: return m_ai_object_cabinet_bed1;
        // case everest::ai::AI_OBJECT_CABINET_TEA_TABLE1: return m_ai_object_cabinet_tea_table1;
        default: return 0.6;
    }
}


/***********************************************************************************
Function:     ~CAiParameters
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CAiParameters::getAiObjectDetectSorceThreshold(TAIObjectClass object_class)
{
    switch (object_class)
    {
        case everest::ai::AI_OBJECT_CHAIR_BASE: return m_ai_object_chair_base_detect;
        case everest::ai::AI_OBJECT_WEIGHT_SCALE: return m_ai_object_weight_scale_detect;
        case everest::ai::AI_OBJECT_SHOE: return m_ai_object_shoe_detect;
        case everest::ai::AI_OBJECT_WIRE: return m_ai_object_wire_detect;
        case everest::ai::AI_OBJECT_SOCKS: return m_ai_object_socks_detect;
        default: return 0.4528;
    }
}

/***********************************************************************************
Function:     ~getWireObjectDetectThreshold
Description:  getWireObjectDetectThreshold
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CAiParameters::getWireObjectDetectThreshold()
{
    return m_ai_object_wire_detect;
}

/***********************************************************************************
Function:     ~getObjectDetectThreshold
Description:  getObjectDetectThreshold
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CAiParameters::getObjectDetectThreshold()
{
    return m_ai_object_detect;
}

/***********************************************************************************
Function:     ~getSceceDetectThreshold
Description:  getSceceDetectThreshold
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
double CAiParameters::getSceceDetectThreshold()
{
    return m_ai_scene_detect;
}

/***********************************************************************************
Function:     ~split_str
Description:  split_str
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::vector<std::string> CAiParameters::splitStr(const std::string &s, const std::string &seperator) {
	std::vector<std::string> result;
	typedef std::string::size_type string_size;
	string_size i = 0;

	while (i != s.size()) {
		//找到字符串中首个不等于分隔符的字母；
		int flag = 0;
		while (i != s.size() && flag == 0) {
			flag = 1;
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[i] == seperator[x]) {
					++i;
					flag = 0;
					break;
				}
		}

		//找到又一个分隔符，将两个分隔符之间的字符串取出；
		flag = 0;
		string_size j = i;
		while (j != s.size() && flag == 0) {
			for (string_size x = 0; x < seperator.size(); ++x)
				if (s[j] == seperator[x]) {
					flag = 1;
					break;
				}
			if (flag == 0)
				++j;
		}
		if (i != j) {
			result.push_back(s.substr(i, j - i));
			i = j;
		}
	}
	return result;
}
/***********************************************************************************
Function:     ~loadFileParams
Description:  loadFileParams
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CAiParameters::loadFileParams(std::string config_file_name,std::string seprate_s,float *params) {
	std::ifstream fin(config_file_name);
	if (!fin.is_open()){
        std::cout << config_file_name << "  not exit "<< std::endl;
		return false;
	}
	std::string line;
	int lineNum = 0;
	// std::cout << config_file_name << " file param: "<< std::endl;
	while(getline(fin, line))
	{
		// std::cout << line << std::endl;
		std::vector<std::string> str_ = splitStr(line,seprate_s);
		params[lineNum] = atof(str_[1].c_str());
		lineNum++;
	}

	return lineNum > 0;
}

/***********************************************************************************
Function:     ~loadAllClassMinScores
Description:  loadAllClassMinScores
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CAiParameters::loadAllClassMinScores()
{
    if (!loadFileParams("/userdata/AI/class_min_score.txt",":",m_all_class_min_scores)){
		return;
	}

    m_ai_object_socks           = m_all_class_min_scores[0];
    m_ai_object_shoe            = m_all_class_min_scores[1];
    m_ai_object_wire            = m_all_class_min_scores[2];
    m_ai_object_chair_base      = m_all_class_min_scores[3];
    m_ai_object_blanket         = m_all_class_min_scores[4];
    m_ai_object_dog             = m_all_class_min_scores[5];
    m_ai_object_cat             = m_all_class_min_scores[6];
    m_ai_object_animal_food     = m_all_class_min_scores[7];
    m_ai_object_potato_chips    = m_all_class_min_scores[8];
    m_ai_object_seed_shell      = m_all_class_min_scores[9];
    m_ai_object_droppings       = m_all_class_min_scores[10];
    m_ai_object_slipper         = m_all_class_min_scores[11];
    m_ai_object_foot            = m_all_class_min_scores[12];
    m_ai_object_people          = m_all_class_min_scores[13];
    m_ai_object_people_laid     = m_all_class_min_scores[14];
    m_ai_object_door_threshold  = m_all_class_min_scores[15];
    m_ai_object_door            = m_all_class_min_scores[16];

    m_ai_object_furniture       = m_all_class_min_scores[17];
    m_ai_object_dining_table    = m_all_class_min_scores[18];
    m_ai_object_sofa            = m_all_class_min_scores[19];
    m_ai_object_bed             = m_all_class_min_scores[20];
    m_ai_object_closestool      = m_all_class_min_scores[21];
    m_ai_object_cupboard        = m_all_class_min_scores[22];
    m_ai_object_refrigerator    = m_all_class_min_scores[23];
    m_ai_object_washstand       = m_all_class_min_scores[24];
    m_ai_object_cabinet_tv      = m_all_class_min_scores[25];
    m_ai_object_cabinet_tea_table = m_all_class_min_scores[26];
    m_ai_object_cabinet_bed     = m_all_class_min_scores[27];
    

    m_ai_floor_concrete         = m_all_class_min_scores[28];
    m_ai_floor_title            = m_all_class_min_scores[29];
    m_ai_floor_wood             = m_all_class_min_scores[30];
    m_ai_floor_unknow           = m_all_class_min_scores[31];
    m_ai_object_wire_detect     = m_all_class_min_scores[32];
    m_ai_object_dirt            = m_all_class_min_scores[33];
    m_ai_object_washing_machine = m_all_class_min_scores[34];
    m_ai_object_detect          = m_all_class_min_scores[35];
    m_ai_scene_detect           = m_all_class_min_scores[36];
    m_ai_object_weight_scale    = m_all_class_min_scores[37];
    m_ai_object_metal_chair_foot    = m_all_class_min_scores[38];
    m_ai_object_charger         = m_all_class_min_scores[39];
    m_ai_object_chair_base_detect     = m_all_class_min_scores[40];
    m_ai_object_shoe_detect     = m_all_class_min_scores[41];
    
    m_ai_object_sofa1                   = m_all_class_min_scores[42];
    m_ai_object_bed1                    = m_all_class_min_scores[43];
    m_ai_object_refrigerator1           = m_all_class_min_scores[44];
    m_ai_object_socks_detect            = m_all_class_min_scores[45];
    m_ai_object_weight_scale_detect     = m_all_class_min_scores[46];

    m_ai_unknown_object_class_min_score   = m_all_class_min_scores[47];
    m_ai_unknown_object_detect_min_score = m_all_class_min_scores[48];

    

    std::cout << "m_ai_object_detect : " << m_ai_object_detect<< std::endl;
    std::cout << "m_ai_scene_detect : " << m_ai_scene_detect<< std::endl;
}                                                                                                                                                                          

/***********************************************************************************
Function:     loadAIConfig
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CAiParameters::loadAIConfig()
{
    if (!loadFileParams("/userdata/AI/ai_config.txt",":",m_ai_config)){
		return;
	}

    m_ai_mode_number                        = (int)m_ai_config[0];
    m_image_upload_server_frequt            = (int)m_ai_config[1];
    m_object_detect_num_limit               = (int)m_ai_config[2];
    m_image_upload_server_floor_frequt      = (int)m_ai_config[3];
    m_image_upload_server_object_frequt     = (int)m_ai_config[4];
    m_image_upload_difference_limit_count   = (int)m_ai_config[5];
}

/***********************************************************************************
Function:     getConfigAIModeNumber
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getServerDataCollectionFrequt()
{
   return m_image_upload_server_frequt;    
}

/***********************************************************************************
Function:     getServerDataCollectionFloorFrequt
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getServerDataCollectionFloorFrequt()
{
    return m_image_upload_server_floor_frequt;
}

/***********************************************************************************
Function:     getServerDataCollectionObjectFrequt
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getServerDataCollectionObjectFrequt()
{

    return m_image_upload_server_object_frequt;
}

double CAiParameters::getUnownObjectClassminScore()
{

    return m_ai_unknown_object_class_min_score;
}

double CAiParameters::getUnownObjectDetectminScore()
{
    return m_ai_unknown_object_detect_min_score;
}

/***********************************************************************************
Function:     getImageUploadDifferenceLimitCount
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getImageUploadDifferenceLimitCount()
{
    return m_image_upload_difference_limit_count;
}

/***********************************************************************************
Function:     getConfigAIModeNumber
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getConfigAIModeNumber()
{
    return m_ai_mode_number;
}

/***********************************************************************************
Function:     getObjDetectNumLimit
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
int CAiParameters::getObjDetectNumLimit()
{
    return m_object_detect_num_limit;
}

/***********************************************************************************
Function:     getLocalAIMode
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
base::TAiMode CAiParameters::getLocalAIMode()
{
    switch (m_ai_mode_number)
    {
    case 0:
        return base::AI_MODE_IDLE;
        break;
    case 1:
        return base::AI_MODE_DETECTION;
        break;
    case 2:
        return base::AI_MODE_OUT_FAMILY_TEST;
        break;
    case 3:
        return base::AI_MODE_LOCAL_DATA_COLLECTION;
        break;
    case 4:
        return base::AI_MODE_SERVER_DATA_COLLECTION;
        break;
    case 5:
        return base::AI_MODE_CAMERA_CALIBRATION;
        break;
    default:
        break;
    }
    return base::AI_MODE_OUT_FAMILY_TEST;
}

/***********************************************************************************
Function:     saveFromConfigFile
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CAiParameters::saveFromConfigFile()
{
	std::string path = everest::base::CFilePath::getClassMinScoreConfigFilePath();
	std::cout << " saveFromConfigFile  " << path << std::endl;
	everest::base::CConfigFile config_file;
	
	config_file.addContext(m_ai_object_socks, "m_ai_object_socks");
	config_file.addContext(m_ai_object_shoe, "m_ai_object_shoe");
	config_file.addContext(m_ai_object_wire, "m_ai_object_wire");
	config_file.addContext(m_ai_object_chair_base, "m_ai_object_chair_base");
	config_file.addContext(m_ai_object_blanket,  "m_ai_object_blanket");
	config_file.addContext(m_ai_object_dog,  "m_ai_object_dog");
	config_file.addContext(m_ai_object_cat,  "m_ai_object_cat");
	config_file.addContext(m_ai_object_animal_food,  "m_ai_object_animal_food");
	config_file.addContext(m_ai_object_potato_chips, "m_ai_object_potato_chips");
	config_file.addContext(m_ai_object_seed_shell, "m_ai_object_seed_shell");
	config_file.addContext(m_ai_object_droppings, "m_ai_object_droppings");
	config_file.addContext(m_ai_object_slipper,  "m_ai_object_slipper");
	config_file.addContext(m_ai_object_foot, "m_ai_object_foot");
	config_file.addContext(m_ai_object_people, "m_ai_object_people");
	config_file.addContext(m_ai_object_people_laid, "m_ai_object_people_laid");
    config_file.addContext(m_ai_object_door_threshold, "m_ai_object_door_threshold");
	config_file.addContext(m_ai_object_door,  "m_ai_object_door");
	config_file.addContext(m_ai_object_furniture, "m_ai_object_furniture");
	config_file.addContext(m_ai_object_dining_table, "m_ai_object_dining_table");
	config_file.addContext(m_ai_object_sofa, "m_ai_object_sofa");
    config_file.addContext(m_ai_object_bed, "m_ai_object_bed");
	config_file.addContext(m_ai_object_closestool,  "m_ai_object_closestool");
	config_file.addContext(m_ai_object_cupboard, "m_ai_object_cupboard");
	config_file.addContext(m_ai_object_refrigerator, "m_ai_object_refrigerator");
	config_file.addContext(m_ai_object_washstand, "m_ai_object_washstand");
    config_file.addContext(m_ai_object_cabinet_tv, "m_ai_object_cabinet_tv");
	config_file.addContext(m_ai_object_cabinet_tea_table,  "m_ai_object_cabinet_tea_table");
	config_file.addContext(m_ai_object_cabinet_bed, "m_ai_object_cabinet_bed");
	config_file.addContext(m_ai_floor_concrete, "m_ai_floor_concrete");
	config_file.addContext(m_ai_floor_title, "m_ai_floor_title");
    config_file.addContext(m_ai_floor_wood, "m_ai_floor_wood");
    config_file.addContext(m_ai_floor_unknow, "m_ai_floor_unknow");
    config_file.addContext(m_ai_object_wire_detect, "m_ai_object_wire_detect");
    config_file.addContext(m_ai_object_dirt, "m_ai_object_dirt");
    config_file.addContext(m_ai_object_dirt, "m_ai_object_washing_machine");

	if(!config_file.saveFileContext(path))
	{
		std::cout << " not  " << path << " fail!!" << std::endl;
	}
}

/***********************************************************************************
Function:     loadFromConfigFile
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CAiParameters::loadFromConfigFile()
{
	std::string path = everest::base::CFilePath::getClassMinScoreConfigFilePath();
	everest::base::CConfigFile config_file;
	std::cout << " loadFromConfigFile  " << path << std::endl;
	std::cout << " ------------------start----------------------  " << std::endl;
	if(config_file.readFileContext(path))
	{
		bool ret = true;
        ret &= config_file.loadConfigValueDouble(m_ai_object_socks, "m_ai_object_socks");
        ret &= config_file.loadConfigValueDouble(m_ai_object_shoe, "m_ai_object_shoe");
        ret &= config_file.loadConfigValueDouble(m_ai_object_wire, "m_ai_object_wire");
        ret &= config_file.loadConfigValueDouble(m_ai_object_chair_base, "m_ai_object_chair_base");
        ret &= config_file.loadConfigValueDouble(m_ai_object_blanket,  "m_ai_object_blanket");
        ret &= config_file.loadConfigValueDouble(m_ai_object_dog,  "m_ai_object_dog");
        ret &= config_file.loadConfigValueDouble(m_ai_object_cat,  "m_ai_object_cat");
        ret &= config_file.loadConfigValueDouble(m_ai_object_animal_food,  "m_ai_object_animal_food");
        ret &= config_file.loadConfigValueDouble(m_ai_object_potato_chips, "m_ai_object_potato_chips");
        ret &= config_file.loadConfigValueDouble(m_ai_object_seed_shell, "m_ai_object_seed_shell");
        ret &= config_file.loadConfigValueDouble(m_ai_object_droppings, "m_ai_object_droppings");
        ret &= config_file.loadConfigValueDouble(m_ai_object_slipper,  "m_ai_object_slipper");
        ret &= config_file.loadConfigValueDouble(m_ai_object_foot, "m_ai_object_foot");
        ret &= config_file.loadConfigValueDouble(m_ai_object_people, "m_ai_object_people");
        ret &= config_file.loadConfigValueDouble(m_ai_object_people_laid, "m_ai_object_people_laid");
        ret &= config_file.loadConfigValueDouble(m_ai_object_door_threshold, "m_ai_object_door_threshold");
        ret &= config_file.loadConfigValueDouble(m_ai_object_door,  "m_ai_object_door");
        ret &= config_file.loadConfigValueDouble(m_ai_object_furniture, "m_ai_object_furniture");
        ret &= config_file.loadConfigValueDouble(m_ai_object_dining_table, "m_ai_object_dining_table");
        ret &= config_file.loadConfigValueDouble(m_ai_object_sofa, "m_ai_object_sofa");
        ret &= config_file.loadConfigValueDouble(m_ai_object_bed, "m_ai_object_bed");
        ret &= config_file.loadConfigValueDouble(m_ai_object_closestool,  "m_ai_object_closestool");
        ret &= config_file.loadConfigValueDouble(m_ai_object_cupboard, "m_ai_object_cupboard");
        ret &= config_file.loadConfigValueDouble(m_ai_object_refrigerator, "m_ai_object_refrigerator");
        ret &= config_file.loadConfigValueDouble(m_ai_object_washstand, "m_ai_object_washstand");
        ret &= config_file.loadConfigValueDouble(m_ai_object_cabinet_tv, "m_ai_object_cabinet_tv");
        ret &= config_file.loadConfigValueDouble(m_ai_object_cabinet_tea_table,  "m_ai_object_cabinet_tea_table");
        ret &= config_file.loadConfigValueDouble(m_ai_object_cabinet_bed, "m_ai_object_cabinet_bed");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_concrete, "m_ai_floor_concrete");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_title, "m_ai_floor_title");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_wood, "m_ai_floor_wood");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_unknow, "m_ai_floor_unknow");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_wood, "m_ai_object_dirt");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_unknow, "m_ai_object_dirt");
        ret &= config_file.loadConfigValueDouble(m_ai_floor_unknow, "m_ai_object_washing_machine");

        std::cout << "m_ai_object_dog : " << m_ai_object_dog<< std::endl;
        std::cout << "m_ai_floor_title : " << m_ai_floor_title<< std::endl;
        std::cout << "m_ai_floor_wood : " << m_ai_floor_wood<< std::endl;
		std::cout << " ------------------end----------------------  " << std::endl;
		return ret;
	}
	else
	{
		saveFromConfigFile();
	}
	
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
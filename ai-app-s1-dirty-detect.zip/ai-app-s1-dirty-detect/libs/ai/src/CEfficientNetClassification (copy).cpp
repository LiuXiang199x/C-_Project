/**********************************************************************************
File name:	  CEfficientNetClassification.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CEfficientNetClassification.h>
#include <everest/ai/CTypeTransform.h>
#include <everest/base/CTime.h>

#define HAS_SOFT_MAX 1
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;
using namespace everest::base;

/***********************************************************************************
Function:     CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CEfficientNetClassification::CEfficientNetClassification():
                             m_model_efficient_net(NULL),
                             m_network_input_width(320),
                             m_network_input_height(320),
                             m_top_n_result(2),
                             m_min_score(0.01),
                             m_model_path("/userdata/AI/all_class_model.rknn"),
                             m_class_model_type(CLASS_MODLE_TYPE_ALL)
{
    // m_model_path = "/userdata/AI/all_class_model.rknn";
    // m_class_model_type = CLASS_MODLE_TYPE_ALL;
	m_efficientnet_init_success = initEfficientNet();
}

/***********************************************************************************
Function:     CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CEfficientNetClassification::CEfficientNetClassification(CLASS_MODLE_TYPE type,
                                                        int network_input_width, 
                                                        int network_input_height, 
                                                        std::string model_path):
                                                        m_model_efficient_net(NULL),
                                                        m_top_n_result(2),
                                                        m_min_score(0.01)
{
    m_class_model_type = type;
    m_network_input_width = network_input_width;
    m_network_input_height = network_input_height;
    m_model_path = model_path;
	m_efficientnet_init_success = initEfficientNet();
}

/***********************************************************************************
Function:     ~CEfficientNetClassification
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CEfficientNetClassification::~CEfficientNetClassification()
{
    if(m_ctx_efficient_net >= 0) 
    {
        rknn_destroy(m_ctx_efficient_net);
    }

    if(m_model_efficient_net) 
    {
        free(m_model_efficient_net);
    }  
}

/***********************************************************************************
Function:     loadModel
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
unsigned char *CEfficientNetClassification::loadModel(const char *filename, int *model_size)
{
    FILE *fp = fopen(filename, "rb");
    if(fp == nullptr) 
	{
        printf("fopen %s fail!\n", filename);
        return NULL;
    }

    fseek(fp, 0, SEEK_END);
    
	int model_len = ftell(fp);
    unsigned char *model = (unsigned char*)malloc(model_len);

    fseek(fp, 0, SEEK_SET);

    if(model_len != fread(model, 1, model_len, fp)) 
	{
        printf("fread %s fail!\n", filename);
        free(model);
        return NULL;
    }

    *model_size = model_len;

    if(fp) 
	{
        fclose(fp);
    }

    return model;
}

/***********************************************************************************
Function:     printRKNNTensor
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CEfficientNetClassification::printRKNNTensor(rknn_tensor_attr *attr) 
{
    printf("index=%d name=%s n_dims=%d dims=[%d %d %d %d] n_elems=%d size=%d fmt=%d \
			type=%d qnt_type=%d fl=%d zp=%d scale=%f\n", 
            attr->index, attr->name, attr->n_dims, attr->dims[3], attr->dims[2], attr->dims[1], attr->dims[0], 
            attr->n_elems, attr->size, 0, attr->type, attr->qnt_type, attr->fl, attr->zp, attr->scale);
}

/***********************************************************************************
Function:     initEfficientNet
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CEfficientNetClassification::initEfficientNet()
{
    // char *efficient_net_model_path = "/userdata/AI/all_class_model.rknn";
    const char *efficient_net_model_path = m_model_path.c_str();
	int model_len_efficient_net = 0;

    m_model_efficient_net = loadModel(efficient_net_model_path, &model_len_efficient_net);

    if(m_model_efficient_net == NULL) 
	{
        printf("efficient_net model load failed\n");
        return false;
    }else
    {
        printf("load model %s successed\n",efficient_net_model_path);
    }
    
    int ret_efficient_net = rknn_init(&m_ctx_efficient_net, m_model_efficient_net, model_len_efficient_net, 0);

    if(ret_efficient_net < 0) 
    {
        printf("rknn_init fail! ret_efficient_net=%d\n", ret_efficient_net);
        return false;
    }

    ret_efficient_net = rknn_query(m_ctx_efficient_net, RKNN_QUERY_IN_OUT_NUM, 
                        &m_io_num_efficient_net, sizeof(m_io_num_efficient_net));
    
    if (ret_efficient_net != RKNN_SUCC) 
    {
        printf("rknn_query fail! ret_efficient_net=%d\n", ret_efficient_net);
        return false;
    }
    
    printf("model_cls input num: %d, output num: %d\n", \
            m_io_num_efficient_net.n_input, m_io_num_efficient_net.n_output);
    
    printf("input tensors:\n");

    memset(m_input_attrs_efficient_net, 0, sizeof(m_input_attrs_efficient_net));

    for (int i = 0; i < m_io_num_efficient_net.n_input; i++) 
    {
        m_input_attrs_efficient_net[i].index = i;
        ret_efficient_net = rknn_query(m_ctx_efficient_net, RKNN_QUERY_INPUT_ATTR, 
                            &(m_input_attrs_efficient_net[i]), sizeof(rknn_tensor_attr));
        
        if (ret_efficient_net != RKNN_SUCC) 
        {
            printf("rknn_query fail! ret_efficient_net=%d\n", ret_efficient_net);
            return false;
        }
        printRKNNTensor(&(m_input_attrs_efficient_net[i]));
    }

    memset(m_output_attrs_efficient_net, 0, sizeof(m_output_attrs_efficient_net));
    for (int i = 0; i < m_io_num_efficient_net.n_output; i++) 
    {
        m_output_attrs_efficient_net[i].index = i;
        ret_efficient_net = rknn_query(m_ctx_efficient_net, RKNN_QUERY_OUTPUT_ATTR, 
                                       &(m_output_attrs_efficient_net[i]), sizeof(rknn_tensor_attr));
        
        if (ret_efficient_net != RKNN_SUCC) 
        {
            printf("rknn_query fail! ret_efficient_net=%d\n", ret_efficient_net);
            return false;
        }
        printRKNNTensor(&(m_output_attrs_efficient_net[i]));
    }

    printf("initial efficient-net successfully!!!\n");

    return true;
}

/***********************************************************************************
Function:     getTopN
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CEfficientNetClassification::getTopN(float* prediction, int prediction_size, size_t num_results,
                                          float threshold, std::vector<std::pair<float, int>>* top_results,
                                          bool input_floating) 
{
    // Will contain top N results in ascending order.
    std::priority_queue<std::pair<float, int>, std::vector<std::pair<float, int>>,
                        std::greater<std::pair<float, int>>> top_result_pq;

    const long count = prediction_size;
   
    for (int i = 0; i < count; ++i) 
    {
        // std::cout << " i is " << i << " prediction is " << prediction[i] << std::endl;
        float value;
        if (input_floating)
        {
            value = prediction[i];
        }
        else
        {
            value = prediction[i] / 255.0;
        }   
      
        // Only add it if it beats the threshold and has a chance at being in
        // the top N.
        // if (value < m_ai_parameter.getAiObjectClassSorceThreshold(CTypeTransform::aiLable2AiObjectClass((AIAllClassLabel)i)))
        if (value < threshold)
        {
            continue;
        }

        top_result_pq.push(std::pair<float, int>(value, i));

        // If at capacity, kick the smallest value out.
        if (top_result_pq.size() > num_results) 
        {
            top_result_pq.pop();
        }
    }
 
    // Copy to output vector and reverse into descending order.
    while (!top_result_pq.empty()) 
    {
        top_results->push_back(top_result_pq.top());
        top_result_pq.pop();
    }

    std::reverse(top_results->begin(), top_results->end());
}

/***********************************************************************************
Function:     activation_function_softmax
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CEfficientNetClassification::activation_function_softmax(float* src, float* dst, int length)
{
	float max = *std::max_element(src, src + length);
	float sum=0;
 
	for (int i = 0; i < length; ++i) {
		dst[i] = std::exp(src[i] - max);
		sum += dst[i];
	}
 
	for (int i = 0; i < length; ++i) {
		dst[i] /= sum;
        // printf("src = %.2f, dest = %.2f\n", src[i],dst[i]);
	}
}


/***********************************************************************************
Function:     runEfficientNetClassifiaction
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CEfficientNetClassification::runEfficientNetClassifiaction(cv::Mat &src_img, 
                                                    TAIObejectDetectData &result)
{
    base::TTimeStamp class_second_behand_process_data_time = CTime::getCpuTime();
    if(src_img.empty() || src_img.cols == 0 || src_img.rows == 0)
    {
        return false;
    }

    if(!m_efficientnet_init_success)
    {
        return false;
    }
        
    cv::Mat orig_img = src_img;
    cv::Mat img = orig_img.clone();
    
    if(orig_img.cols != m_network_input_width || 
       orig_img.rows != m_network_input_height) 
    {
        cv::resize(orig_img, img, cv::Size(m_network_input_width, 
                   m_network_input_height), (0, 0), (0, 0), cv::INTER_LINEAR);

        // std::string origin_image_path = "/tmp/AI/test/" + CTime::getTimeString() + "_origin.jpg";
        // std::string detect_image_path = "/tmp/AI/test/" + CTime::getTimeString() + "_detect.jpg";
        // cv::imwrite(origin_image_path, orig_img);
        // cv::imwrite(detect_image_path, img);
    }

    // Set Input Data
    rknn_input inputs[1];
    memset(inputs, 0, sizeof(inputs));
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;//图片数据类型
    inputs[0].size = img.cols*img.rows*img.channels();
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].buf = img.data;
    // printf("rknn_inputs_set\n");
    int ret_efficient_net = rknn_inputs_set(m_ctx_efficient_net, m_io_num_efficient_net.n_input, inputs);
    if(ret_efficient_net < 0) 
    {
        printf("rknn_input_set fail! ret_efficient_net=%d\n", ret_efficient_net);
        return false;
    }
    // printf("time-statics===ClassBeforeHandData2===cost-time:%f ms\n",1000 * CTime::timeDifference(class_second_behand_process_data_time,  CTime::getCpuTime()));
    // Run
    // printf("rknn_run\n");
    base::TTimeStamp start_run_class_time = CTime::getCpuTime();
    ret_efficient_net = rknn_run(m_ctx_efficient_net, nullptr);
    base::TTimeStamp end_run_class_time = CTime::getCpuTime();
    // printf("time-statics===RunClassTime===cost-time:%f ms\n",1000 * CTime::timeDifference(start_run_class_time,  end_run_class_time));
    if(ret_efficient_net < 0) 
    {
        printf("rknn_run fail! ret_efficient_net=%d\n", ret_efficient_net);
        return false;
    }
    base::TTimeStamp class_second_after_process_data_time = CTime::getCpuTime();
    // Get Output
    rknn_output outputs[1];
    memset(outputs, 0, sizeof(outputs));
    outputs[0].want_float = 1;
    // printf("rknn_outputs_get\n");
    ret_efficient_net = rknn_outputs_get(m_ctx_efficient_net, 1, outputs, NULL);
    if(ret_efficient_net < 0) 
    {
        printf("rknn_outputs_get fail! ret_efficient_net=%d\n", ret_efficient_net);
        return false;
    }

    std::vector<std::pair<float, int>> top_results;
    std::vector<std::pair<float, int>> top_results_ori;

    getTopN((float *)(outputs[0].buf), m_output_attrs_efficient_net[0].n_elems,
                  m_top_n_result, m_min_score, &top_results_ori,outputs[0].want_float);
   
    //softmaxs
    float *src_prediction = (float *)(outputs[0].buf);

    #if HAS_SOFT_MAX
    float *dest_prediction = new float[m_output_attrs_efficient_net[0].n_elems];
    memset(dest_prediction, 0, m_output_attrs_efficient_net[0].n_elems);
    activation_function_softmax(src_prediction,dest_prediction,m_output_attrs_efficient_net[0].n_elems);
    getTopN(dest_prediction, m_output_attrs_efficient_net[0].n_elems,
                  m_top_n_result, m_min_score, &top_results, outputs[0].want_float);
    delete []dest_prediction;
   
    #else
    getTopN(src_prediction, m_output_attrs_efficient_net[0].n_elems,
                  m_top_n_result, m_min_score, &top_results, outputs[0].want_float);
    #endif
    
    rknn_outputs_release(m_ctx_efficient_net, 1, outputs);

    if(top_results.empty())
    {
        printf("detected nothing \n");
        result.obj_class = AI_OBJECT_NOTHING;
        return false;
    }
    else 
    {
        
        if (m_class_model_type == CLASS_MODLE_TYPE_ALL)
        {
            result.obj_class = CTypeTransform::aiLable2AiObjectClass((AIAllClassLabel)(top_results[0].second));
            result.ori_all_class = (AIAllClassLabel)top_results[0].second;

        }else
        {
            result.obj_class = CTypeTransform::aiFloorBlanketLable2AiObjectClass((AIFloorBlanketClassLabel)(top_results[0].second));
            result.ori_floor_class = (AIFloorBlanketClassLabel)top_results[0].second;
        }
        // printf("ori top 1 num is %d score is %.4f\n",top_results_ori[0].second,top_results_ori[0].first);
        // printf("softmax top 1 num is %d score is %.4f\n",top_results[0].second,top_results[0].first);
        result.classify_score = top_results[0].first;
        // printf("time-statics===ClassAfterHandData1===cost-time:%f ms\n",1000 * CTime::timeDifference(class_second_after_process_data_time,  CTime::getCpuTime()));

        //define unknown class
        //define unknown class
        if (result.obj_class > AI_OBJECT && result.obj_class < AI_OBJECT_FURNITURE)
        {
            //
            if (
                result.obj_class == AI_OBJECT_SOCKS 
                ||
                result.obj_class == AI_OBJECT_CHAIR_BASE
                ||
                result.obj_class == AI_OBJECT_WEIGHT_SCALE 
                ||
                result.obj_class == AI_OBJECT_METAL_CHAIR_FOOT
                ||
                result.obj_class == AI_OBJECT_SHOE
                ||
                result.obj_class == AI_OBJECT_WIRE
                )
            {
                double obj_class_score_max= m_ai_parameter.getAiObjectClassSorceThreshold(result.obj_class);
                double obj_detect_score_max = m_ai_parameter.getAiObjectDetectSorceThreshold(result.obj_class);
                double obj_unknown_class_min_score = m_ai_parameter.getUnownObjectClassminScore();
                double obj_unknown_detect_min_score = m_ai_parameter.getUnownObjectDetectminScore();
                bool class_is_low_score = false;
                bool detect_is_low_score = false;
                if (result.classify_score < obj_class_score_max && result.classify_score > obj_unknown_class_min_score)
                {  
                    class_is_low_score = true;
                }

                if (result.object_detect_score < obj_detect_score_max && result.object_detect_score > obj_unknown_detect_min_score)
                {  
                    detect_is_low_score = true;
                }

                if (class_is_low_score || detect_is_low_score)
                {
                    result.obj_ori_class = result.obj_class;
                    if (result.obj_class == AI_OBJECT_SOCKS)
                    {
                        result.obj_class = AI_OBJECT_UKNOWN_SOCKS;

                    }else if (result.obj_class == AI_OBJECT_CHAIR_BASE)
                    {
                        // result.obj_class = AI_OBJECT_UKNOWN_CHAIR_BASE;

                    }else if (result.obj_class == AI_OBJECT_WEIGHT_SCALE)
                    {
                        // result.obj_class = AI_OBJECT_UKNOWN_WEIGHT_SCALE;

                    }else if (result.obj_class == AI_OBJECT_METAL_CHAIR_FOOT)
                    {
                        // result.obj_class = AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT;

                    }else if (result.obj_class == AI_OBJECT_SHOE)
                    {
                        // result.obj_class = AI_OBJECT_UKNOWN_SHOE;

                    }else if (result.obj_class == AI_OBJECT_WIRE)
                    {
                        // result.obj_class = AI_OBJECT_UKNOWN_WIRE;

                    }
        
                    
                    // result.obj_class = AI_OBJECT;
                }
                
            }
        }

        return true;
    }
}
/**********************************************************************************
File name:	  CTypeTransform.cpp
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/ai/CTypeTransform.h>
#include <stdlib.h>
#include <everest/base/CLog.h>
/*********************************** Name space ***********************************/
using namespace everest;
using namespace everest::ai;

/***********************************************************************************
Function:     CTypeTransform
Description:  The constructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTypeTransform::CTypeTransform()
{
	
}

/***********************************************************************************
Function:     ~aiFloorBlanketLable2String
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CTypeTransform::aiFloorBlanketLable2String(AIFloorBlanketClassLabel lable)
{
    switch (lable)
    {
        case FloorBlanketClass_blanket: return "carpet";
        case FloorBlanketClass_title_floor: return "tile_floor";
        case FloorBlanketClass_wood_floor: return "wood_floor";
        case FloorBlanketClass_unknown: return "unknown";
        default: return "NULL";
    }
}

/***********************************************************************************
Function:     ~CTypeTransform
Description:  The destructor of Ai parameters
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CTypeTransform::~CTypeTransform()
{
    
}

/***********************************************************************************
Function:     aiLable2String
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CTypeTransform::aiLable2String(AIAllClassLabel lable)
{
    switch (lable)
    {
        // case allClass_cabinet1: return "cabinet1";
        // case allClass_TV_stand1: return "TV_stand1";
        // case allClass_tea_table1: return "tea_table1";
        case allClass_bed1: return "bed1";
        // case allClass_dining_table1: return "dining_table1";
        case allClass_cupboard1: return "cupboard1";
        case allClass_refrigerator1: return "refrigerator1";
        // case allClass_toilet1: return "toilet1";
        case allClass_sofa1: return "sofa1";
        case allClass_washing_machine1: return "washing_machine1";
        case allClass_bed: return "bed";
        case allClass_carpet: return "carpet";
        case allClass_cabinet: return "cabinet";
        case allClass_TV_stand: return "TV_stand";
        case allClass_tea_table: return "tea_table";
        // case allClass_cat: return "cat";
        case allClass_chair_base: return "chair_base";
        case allClass_charger: return "charger";
        case allClass_cupboard: return "cupboard";
        case allClass_dining_table: return "dining_table";
        case allClass_dirt: return "dirt";
        case allClass_dog: return "dog";
        case allClass_door: return "door_anno";
        // case allClass_door_sill: return "door_sill";
        case allClass_invalid: return "invalid";
        case allClass_metal_chair_foot: return "metal_chair_foot";
        // case allClass_person: return "person";
        case allClass_pet_feces: return "pet_feces";
        case allClass_refrigerator: return "refrigerator";
        case allClass_shoe: return "shoe";
        case allClass_socks: return "socks";
        case allClass_sofa: return "sofa";
        // case allClass_sweeping_machine: return "sweeping_machine";
        case allClass_tile_floor: return "tile_floor";
        case allClass_toilet: return "toilet";
        case allClass_unknown: return "unknown";
        case allClass_washing_machine: return "washing_machine";
        case allClass_weight_scale: return "allClass_weight_scale";
        case allClass_wire: return "wire";
        case allClass_wood_floor: return "wood_floor";
        default: return "NULL";
    }
}


/***********************************************************************************
Function:     string2AiLable
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
AIAllClassLabel CTypeTransform::string2AiLable(std::string lable_string)
{
    
}


/***********************************************************************************
Function:     aiObjectClass2String
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
std::string CTypeTransform::aiObjectClass2String(TAIObjectClass object_class)
{
    switch(object_class)
    {
        case everest::ai::AI_OBJECT_CLOSESTOOL1: return "AI_OBJECT_CLOSESTOOL1";
        case everest::ai::AI_OBJECT_BED1: return "AI_OBJECT_BED1";
        case everest::ai::AI_OBJECT_SOFA1: return "AI_OBJECT_SOFA1";
        case everest::ai::AI_OBJECT_CUPBOARD1: return "AI_OBJECT_CUPBOARD1";
        case everest::ai::AI_OBJECT_WASHING_MACHINE1: return "AI_OBJECT_WASHING_MACHINE1";
        case everest::ai::AI_OBJECT_REFRIGERATOR1: return "AI_OBJECT_REFRIGERATOR1";
        case everest::ai::AI_OBJECT_DINING_TABLE1: return "AI_OBJECT_DINING_TABLE1";
        case everest::ai::AI_OBJECT_CABINET_TV1: return "AI_OBJECT_CABINET_TV1";
        case everest::ai::AI_OBJECT_CABINET_TEA_TABLE1: return "AI_OBJECT_CABINET_TEA_TABLE1";
        case everest::ai::AI_OBJECT_CABINET_BED1: return "AI_OBJECT_CABINET_BED1";

        case everest::ai::AI_OBJECT_NOTHING: return "AI_OBJECT_NOTHING";
        case everest::ai::AI_OBJECT: return "AI_OBJECT";
        case everest::ai::AI_OBJECT_SOCKS: return "AI_OBJECT_SOCKS";
        case everest::ai::AI_OBJECT_SHOE: return "AI_OBJECT_SHOE";
        case everest::ai::AI_OBJECT_WIRE: return "AI_OBJECT_WIRE";
        case everest::ai::AI_OBJECT_WEIGHT_SCALE: return "AI_OBJECT_WEIGHT_SCALE";
        case everest::ai::AI_OBJECT_METAL_CHAIR_FOOT: return "AI_OBJECT_METAL_CHAIR_FOOT";
        case everest::ai::AI_OBJECT_CHAIR_BASE: return "AI_OBJECT_CHAIR_BASE";
        case everest::ai::AI_OBJECT_CHARGER: return "AI_OBJECT_CHARGER";
        case everest::ai::AI_OBJECT_BLANKET: return "AI_OBJECT_BLANKET";
        case everest::ai::AI_OBJECT_DOG: return "AI_OBJECT_DOG";
        case everest::ai::AI_OBJECT_CAT: return "AI_OBJECT_CAT";
        case everest::ai::AI_OBJECT_DIRT: return "AI_OBJECT_DIRT";
        case everest::ai::AI_OBJECT_ANIMAL_FOOD: return "AI_OBJECT_ANIMAL_FOOD";
        case everest::ai::AI_OBJECT_POTATO_CHIPS: return "AI_OBJECT_POTATO_CHIPS";
        case everest::ai::AI_OBJECT_SEED_SHELL: return "AI_OBJECT_SEED_SHELL";
        case everest::ai::AI_OBJECT_DROPPINGS: return "AI_OBJECT_DROPPINGS";
        case everest::ai::AI_OBJECT_SLIPPER: return "AI_OBJECT_SLIPPER";
        case everest::ai::AI_OBJECT_FOOT: return "AI_OBJECT_FOOT";
        case everest::ai::AI_OBJECT_PEOPLE: return "AI_OBJECT_PEOPLE";
        case everest::ai::AI_OBJECT_PEOPLE_LAID: return "AI_OBJECT_PEOPLE_LAID";
        case everest::ai::AI_OBJECT_DOOR_THRESHOLD: return "AI_OBJECT_DOOR_THRESHOLD";
        case everest::ai::AI_OBJECT_DOOR: return "AI_OBJECT_DOOR";
        case everest::ai::AI_OBJECT_FURNITURE: return "AI_OBJECT_FURNITURE";
        case everest::ai::AI_OBJECT_DINING_TABLE: return "AI_OBJECT_DINING_TABLE";
        case everest::ai::AI_OBJECT_SOFA: return "AI_OBJECT_SOFA";
        case everest::ai::AI_OBJECT_BED: return "AI_OBJECT_BED";
        case everest::ai::AI_OBJECT_CLOSESTOOL: return "AI_OBJECT_CLOSESTOOL";
        case everest::ai::AI_OBJECT_CUPBOARD: return "AI_OBJECT_CUPBOARD";
        case everest::ai::AI_OBJECT_REFRIGERATOR: return "AI_OBJECT_REFRIGERATOR";
        case everest::ai::AI_OBJECT_WASHSTAND: return "AI_OBJECT_WASHSTAND";
        case everest::ai::AI_OBJECT_CABINET_TV: return "AI_OBJECT_CABINET_TV";
        case everest::ai::AI_OBJECT_CABINET_TEA_TABLE: return "AI_OBJECT_CABINET_TEA_TABLE";
        case everest::ai::AI_OBJECT_CABINET_BED: return "AI_OBJECT_CABINET_BED";
        case everest::ai::AI_OBJECT_WASHING_MACHINE: return "AI_OBJECT_WASHING_MACHINE";
        case everest::ai::AI_ROOM: return "AI_ROOM";
        case everest::ai::AI_ROOM_BEDROOM: return "AI_ROOM_BEDROOM";
        case everest::ai::AI_ROOM_RESTAURANT: return "AI_ROOM_RESTAURANT";
        case everest::ai::AI_ROOM_TOILET: return "AI_ROOM_TOILET";
        case everest::ai::AI_ROOM_CORRIDOR: return "AI_ROOM_CORRIDOR";
        case everest::ai::AI_ROOM_KITCHEN: return "AI_ROOM_KITCHEN";
        case everest::ai::AI_ROOM_LIVING_ROOM: return "AI_ROOM_LIVING_ROOM";
        case everest::ai::AI_ROOM_BALCONY: return "AI_ROOM_BALCONY";
        case everest::ai::AI_ROOM_OTHERS: return "AI_ROOM_OTHERS";
        case everest::ai::AI_FLOOR: return "AI_FLOOR";
        case everest::ai::AI_FLOOR_CONCRETE: return "AI_FLOOR_CONCRETE";
        case everest::ai::AI_FLOOR_TITLE: return "AI_FLOOR_TITLE";
        case everest::ai::AI_FLOOR_WOOD: return "AI_FLOOR_WOOD";
        case everest::ai::AI_FLOOR_UNKNOW: return "AI_FLOOR_UNKNOW";
        case everest::ai::AI_OBJECT_UKNOWN_SOCKS: return "AI_OBJECT_UKNOWN_SOCKS";
        case everest::ai::AI_OBJECT_UKNOWN_WIRE: return "AI_OBJECT_UKNOWN_WIRE";
        case everest::ai::AI_OBJECT_UKNOWN_SHOE: return "AI_OBJECT_UKNOWN_SHOE";
        case everest::ai::AI_OBJECT_UKNOWN_WEIGHT_SCALE: return "AI_OBJECT_UKNOWN_WEIGHT_SCALE";
        case everest::ai::AI_OBJECT_UKNOWN_CHAIR_BASE: return "AI_OBJECT_UKNOWN_CHAIR_BASE";
        case everest::ai::AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT: return "AI_OBJECT_UKNOWN_METAL_CHAIR_FOOT";
        default: return "AI_FLOOR_UNKNOW";
    }
}

/***********************************************************************************
Function:     aiObjectClass2String
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
TAIObjectClass CTypeTransform::string2AiObjectClass(std::string object_string)
{
    
}

/***********************************************************************************
Function:     isWeightClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CTypeTransform::isWeightClass(TAIObjectClass obj_class)
{
    switch (obj_class)
    {
    case AI_OBJECT_SOFA:
        return true;
        break;
    case AI_OBJECT_BED:
        return true;
        break;
    case AI_OBJECT_REFRIGERATOR:
        return true;
        break;
    // case AI_OBJECT_DINING_TABLE:
    //     return true;
    //     break;
    // case AI_OBJECT_WASHING_MACHINE:
    //     return true;
    //     break;
    // case AI_OBJECT_CLOSESTOOL:
    //     return true;
    //     break;
    // case AI_OBJECT_CUPBOARD:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_TV:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_TEA_TABLE:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_BED:
    //     return true;
    //     break;
    default:
        break;
    }
    return false;
}

/***********************************************************************************
Function:     isLowWeightClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CTypeTransform::isLowWeightClass(TAIObjectClass obj_class)
{
    switch (obj_class)
    {
    case AI_OBJECT_SOFA1:
        return true;
        break;
    case AI_OBJECT_BED1:
        return true;
        break;
    case AI_OBJECT_REFRIGERATOR1:
        return true;
        break;
    // case AI_OBJECT_DINING_TABLE1:
    //     return true;
    //     break;
    // case AI_OBJECT_WASHING_MACHINE1:
    //     return true;
    //     break;
    // case AI_OBJECT_CLOSESTOOL1:
    //     return true;
    //     break;
    // case AI_OBJECT_CUPBOARD1:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_TV1:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_TEA_TABLE1:
    //     return true;
    //     break;
    // case AI_OBJECT_CABINET_BED1:
    //     return true;
    //     break;
    default:
        break;
    }
    return false;
}

/***********************************************************************************
Function:     transferWeightData
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CTypeTransform::transferWeightData(TAIObjectClass &obj_class, double &obj_score)
{
    TAIObjectClass dest_obj_class;
    double dest_obj_score;
    bool obj_class_is_low_weight = false;
    dest_obj_class = obj_class;
    dest_obj_score = obj_score;

    switch (obj_class)
    {
    case AI_OBJECT_SOFA1:
        dest_obj_class = AI_OBJECT_SOFA;
        obj_class_is_low_weight = true;
        break;
    case AI_OBJECT_BED1:
        dest_obj_class = AI_OBJECT_BED;
        obj_class_is_low_weight = true;
        break;
    case AI_OBJECT_REFRIGERATOR1:
        dest_obj_class = AI_OBJECT_REFRIGERATOR;
        obj_class_is_low_weight = true;
        break;
    // case AI_OBJECT_DINING_TABLE1:
    //     dest_obj_class = AI_OBJECT_DINING_TABLE;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_WASHING_MACHINE1:
    //     dest_obj_class = AI_OBJECT_WASHING_MACHINE;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_CLOSESTOOL1:
    //     dest_obj_class = AI_OBJECT_CLOSESTOOL;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_CUPBOARD1:
    //     dest_obj_class = AI_OBJECT_CUPBOARD;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_CABINET_TV1:
    //     dest_obj_class = AI_OBJECT_CABINET_TV;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_CABINET_TEA_TABLE1:
    //     dest_obj_class = AI_OBJECT_CABINET_TEA_TABLE;
    //     obj_class_is_low_weight = true;
    //     break;
    // case AI_OBJECT_CABINET_BED1:
    //     dest_obj_class = AI_OBJECT_CABINET_BED;
    //     obj_class_is_low_weight = true;
    //     break;
    default:
        break;
    }
    
    if (isWeightClass(dest_obj_class))
    {
        if (obj_class_is_low_weight)
        {
            dest_obj_score = obj_score + 1.0;
        }else
        {
            dest_obj_score = obj_score;
        }
        CLog::log(LogKimbo, LogNormal, "set weight ori class type %d class score %.2f!\n",obj_class,obj_score);
        obj_class = dest_obj_class;
        obj_score = dest_obj_score;
        CLog::log(LogKimbo, LogNormal, "set weight class type %d class score %.2f!\n",obj_class,obj_score);
    }
}

/***********************************************************************************
Function:     aiFloorBlanketLable2AiObjectClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
TAIObjectClass CTypeTransform::aiFloorBlanketLable2AiObjectClass(AIFloorBlanketClassLabel lable)
{
    switch (lable)
    {
        case FloorBlanketClass_blanket: return everest::ai::AI_OBJECT_BLANKET;
        case FloorBlanketClass_title_floor: return everest::ai::AI_FLOOR_TITLE;
        case FloorBlanketClass_wood_floor: return everest::ai::AI_FLOOR_WOOD;
        default: return AI_OBJECT_NOTHING;
    }
}



// TAIObjectClass CTypeTransform::aiDirtyLable2AiObjectClass(AIDirtyClassLabeL lable)
// {
//     switch (lable)
//     {
//         case AIDirtyClassLabeL_Water: return everest::ai::AI_OBJECT_DIRTY_WATER;
//         case AIDirtyClassLabeL_Powder: return everest::ai::AI_OBJECT_DIRTY_POWDER;
//         case AIDirtyClassLabeL_Hair: return everest::ai::AI_OBJECT_DIRTY_HAIRE;
//         default: return AI_OBJECT_NOTHING;
//     }
// }







/***********************************************************************************
Function:     aiLable2AiObjectClass
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
TAIObjectClass CTypeTransform::aiLable2AiObjectClass(AIAllClassLabel lable)
{
    switch (lable)
    {
        case allClass_socks: return everest::ai::AI_OBJECT_SOCKS;
        case allClass_shoe: return everest::ai::AI_OBJECT_SHOE;
        case allClass_wire: return everest::ai::AI_OBJECT_WIRE;
        case allClass_weight_scale: return everest::ai::AI_OBJECT_WEIGHT_SCALE;
        case allClass_metal_chair_foot: return everest::ai::AI_OBJECT_METAL_CHAIR_FOOT;
        case allClass_charger: return everest::ai::AI_OBJECT_CHARGER;
        // case allClass_metal_chair_foot: return everest::ai::AI_OBJECT_METAL_CHAIR_FOOT;
        case allClass_chair_base: return everest::ai::AI_OBJECT_CHAIR_BASE;
        case allClass_carpet: return everest::ai::AI_OBJECT_BLANKET;
        case allClass_dog: return everest::ai::AI_OBJECT_DOG;
        // case allClass_cat: return everest::ai::AI_OBJECT_CAT;
        case allClass_pet_feces: return everest::ai::AI_OBJECT_DROPPINGS;
        case allClass_refrigerator: return everest::ai::AI_OBJECT_REFRIGERATOR;
        // case allClass_person: return everest::ai::AI_OBJECT_PEOPLE;
        case allClass_door: return everest::ai::AI_OBJECT_DOOR;
        case allClass_dining_table: return everest::ai::AI_OBJECT_DINING_TABLE;
        case allClass_sofa: return everest::ai::AI_OBJECT_SOFA;
        case allClass_bed: return everest::ai::AI_OBJECT_BED;
        case allClass_cupboard: return everest::ai::AI_OBJECT_CUPBOARD;
        case allClass_cabinet: return everest::ai::AI_OBJECT_CABINET_BED;
        case allClass_toilet: return everest::ai::AI_OBJECT_CLOSESTOOL;
        case allClass_TV_stand: return everest::ai::AI_OBJECT_CABINET_TV;
        case allClass_tea_table: return everest::ai::AI_OBJECT_CABINET_TEA_TABLE;
        case allClass_washing_machine: return everest::ai::AI_OBJECT_WASHING_MACHINE;
        case allClass_tile_floor: return everest::ai::AI_FLOOR_TITLE;
        case allClass_wood_floor: return everest::ai::AI_FLOOR_WOOD;
        case allClass_dirt: return everest::ai::AI_OBJECT_DIRT;
        //weight
        case allClass_refrigerator1: return everest::ai::AI_OBJECT_REFRIGERATOR;
        case allClass_bed1: return everest::ai::AI_OBJECT_BED;
        case allClass_sofa1: return everest::ai::AI_OBJECT_SOFA;
        // case allClass_washing_machine1: return everest::ai::AI_OBJECT_WASHING_MACHINE1;
        // case allClass_cupboard1: return everest::ai::AI_OBJECT_CUPBOARD1;
        // case allClass_dining_table1: return everest::ai::AI_OBJECT_DINING_TABLE1;
        // case allClass_toilet1: return everest::ai::AI_OBJECT_CLOSESTOOL1;
        // case allClass_cabinet1: return everest::ai::AI_OBJECT_CABINET_BED1;
        // case allClass_TV_stand1: return everest::ai::AI_OBJECT_CABINET_TV1;
        // case allClass_tea_table1: return everest::ai::AI_OBJECT_CABINET_TEA_TABLE1;
        default: return AI_OBJECT_NOTHING;
    }
}

/***********************************************************************************
Function:     aiObjectClass2aiLable
Description:  None
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
AIAllClassLabel CTypeTransform::aiObjectClass2aiLable(TAIObjectClass object_class)
{
    switch(object_class)
    {
        case everest::ai::AI_OBJECT_NOTHING: return allClass_invalid;
        case everest::ai::AI_OBJECT: return allClass_invalid;
        case everest::ai::AI_OBJECT_SOCKS: return allClass_socks;
        case everest::ai::AI_OBJECT_SHOE: return allClass_shoe;
        case everest::ai::AI_OBJECT_WIRE: return allClass_wire;
        case everest::ai::AI_OBJECT_WEIGHT_SCALE: return allClass_weight_scale;
        case everest::ai::AI_OBJECT_CHARGER: return allClass_charger;
        case everest::ai::AI_OBJECT_METAL_CHAIR_FOOT: return allClass_metal_chair_foot;
        case everest::ai::AI_OBJECT_CHAIR_BASE: return allClass_chair_base;
        case everest::ai::AI_OBJECT_BLANKET: return allClass_carpet;
        case everest::ai::AI_OBJECT_DOG: return allClass_dog;
        // case everest::ai::AI_OBJECT_CAT: return allClass_cat;
        case everest::ai::AI_OBJECT_DIRT: return allClass_dirt;
        case everest::ai::AI_OBJECT_ANIMAL_FOOD: return allClass_invalid;
        case everest::ai::AI_OBJECT_POTATO_CHIPS: return allClass_invalid;
        case everest::ai::AI_OBJECT_SEED_SHELL: return allClass_invalid;
        case everest::ai::AI_OBJECT_DROPPINGS: return allClass_pet_feces;
        case everest::ai::AI_OBJECT_FOOT: return allClass_invalid;
        // case everest::ai::AI_OBJECT_PEOPLE: return allClass_person;
        case everest::ai::AI_OBJECT_PEOPLE_LAID: return allClass_invalid;
        case everest::ai::AI_OBJECT_DOOR_THRESHOLD: return allClass_invalid;
        case everest::ai::AI_OBJECT_DOOR: return allClass_door;
        case everest::ai::AI_OBJECT_FURNITURE: return allClass_invalid;
        case everest::ai::AI_OBJECT_DINING_TABLE: return allClass_dining_table;
        case everest::ai::AI_OBJECT_SOFA: return allClass_sofa;
        case everest::ai::AI_OBJECT_BED: return allClass_bed;
        case everest::ai::AI_OBJECT_CLOSESTOOL: return allClass_toilet;
        case everest::ai::AI_OBJECT_CUPBOARD: return allClass_cupboard;
        case everest::ai::AI_OBJECT_REFRIGERATOR: return allClass_refrigerator;
        case everest::ai::AI_OBJECT_WASHING_MACHINE: return allClass_washing_machine;
        case everest::ai::AI_OBJECT_WASHSTAND: return allClass_invalid;
        case everest::ai::AI_OBJECT_CABINET_TV: return allClass_TV_stand;
        case everest::ai::AI_OBJECT_CABINET_TEA_TABLE: return allClass_tea_table;
        case everest::ai::AI_OBJECT_CABINET_BED: return allClass_cabinet;
        case everest::ai::AI_ROOM_CORRIDOR: return allClass_invalid;
        case everest::ai::AI_ROOM_KITCHEN: return allClass_invalid;
        case everest::ai::AI_ROOM_LIVING_ROOM: return allClass_invalid;
        case everest::ai::AI_ROOM_BALCONY: return allClass_invalid;
        case everest::ai::AI_ROOM_OTHERS: return allClass_invalid;
        case everest::ai::AI_FLOOR: return allClass_invalid;
        case everest::ai::AI_FLOOR_CONCRETE: return allClass_invalid;
        case everest::ai::AI_FLOOR_TITLE: return allClass_tile_floor;
        case everest::ai::AI_FLOOR_WOOD: return allClass_wood_floor;
        case everest::ai::AI_FLOOR_UNKNOW: return allClass_unknown;
        
        case everest::ai::AI_OBJECT_SOFA1: return allClass_sofa1;
        case everest::ai::AI_OBJECT_BED1: return allClass_bed1;
        case everest::ai::AI_OBJECT_REFRIGERATOR1: return allClass_refrigerator1;
        case everest::ai::AI_OBJECT_WASHING_MACHINE1: return allClass_washing_machine1;
        case everest::ai::AI_OBJECT_CUPBOARD1: return allClass_cupboard1;
        // case everest::ai::AI_OBJECT_DINING_TABLE1: return allClass_dining_table1;
        // case everest::ai::AI_OBJECT_CLOSESTOOL1: return allClass_toilet1;
        // case everest::ai::AI_OBJECT_CABINET_TV1: return allClass_TV_stand1;
        // case everest::ai::AI_OBJECT_CABINET_TEA_TABLE1: return allClass_tea_table1;
        // case everest::ai::AI_OBJECT_CABINET_BED1: return allClass_cabinet1;
        default: return allClass_invalid;
    }
}
/**********************************************************************************
File name:	  CImageLog.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/ 

#ifndef EVEREST_AI_CIMAGELOG_H
#define EVEREST_AI_CIMAGELOG_H

#include "opencv2/opencv.hpp"
#include <everest/ai.h>
#include <string>

namespace everest
{
    namespace ai
    {
        class CImageLog
        {
            public:
                CImageLog();
                ~CImageLog();
            
            public:
                void saveRawImage(cv::Mat &image);
                void saveCalibrationImage(cv::Mat &calibration_image);
                void saveDetectObjectImage(TAIObejectDetectData debug_obj, 
                                           cv::Mat      &detect_image_roi,  
                                           cv::Mat      &origin_image);
                bool readDebugImage(std::string &name, cv::Mat &image);
                void saveOnlyDetectImage(TAIObejectDetectData debug_obj, 
                                      cv::Mat &origin_image);
                void saveAiDetectIuputImage(cv::Mat &aiDetectIuputImage);
                void saveDetectClassOriResultImage(std::vector<TAIObejectDetectData> result_objects, 
                                          cv::Mat &big_image);
                void saveDetectInfoString(std::string &detect_info_file_name,std::string &detect_info_str);
                void saveFloorBlanketImage(TAIObejectDetectData debug_obj, 
                                          cv::Mat &floor_image);
                bool classNeedSaveDebugInfo(TAIObjectClass object_class);

            private:
                std::string subreplace(std::string resource_str, std::string sub_str, std::string new_str);
                long                m_calib_img_count = 0;       
        };
    }
}




#endif

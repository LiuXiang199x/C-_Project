/**********************************************************************************
File name:	  CAiParameters.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CAIPARAMETERS_H_
#define EVEREST_AI_CAIPARAMETERS_H_
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <everest/ai.h>
#include <string.h>
#include <everest/base/CEntityProtocol.h>

#define MIN_SCORE_CLASS_COUNT 80
#define AI_CONFIG_ITEM_COUNT 5

namespace everest
{
    namespace ai
    {
        class CAiParameters
        {
            public:
                CAiParameters();
                ~CAiParameters();

            double getAiObjectClassSorceThreshold(TAIObjectClass object_class);
            double getAiObjectDetectSorceThreshold(TAIObjectClass object_class);
            double getUnownObjectClassminScore();
            double getUnownObjectDetectminScore();
            double getWireObjectDetectThreshold();
            double getObjectDetectThreshold();
            double getSceceDetectThreshold();
            int    getServerDataCollectionFrequt();
            int    getServerDataCollectionFloorFrequt();
            int    getServerDataCollectionObjectFrequt();
            int    getObjDetectNumLimit();
            int    getImageUploadDifferenceLimitCount();
            int    getConfigAIModeNumber();
            base::TAiMode    getLocalAIMode();
            private:
                double         m_ai_object_socks;
                double         m_ai_object_shoe;
                double         m_ai_object_wire;
                double         m_ai_object_chair_base;
                double         m_ai_object_blanket;
                double         m_ai_object_dog;
                double         m_ai_object_cat;
                double         m_ai_object_animal_food;
                double         m_ai_object_potato_chips;
                double         m_ai_object_seed_shell;
                double         m_ai_object_droppings;
                double         m_ai_object_slipper;
                double         m_ai_object_foot;
                double         m_ai_object_people;
                double         m_ai_object_people_laid;
                double         m_ai_object_door_threshold;
                double         m_ai_object_door;
                double         m_ai_object_dirt;

                double         m_ai_object_furniture;
                double         m_ai_object_dining_table;
                double         m_ai_object_sofa;
                double         m_ai_object_bed;
                double         m_ai_object_closestool;
                double         m_ai_object_cupboard;
                double         m_ai_object_refrigerator;
                double         m_ai_object_washstand;
                double         m_ai_object_cabinet_tv;
                double         m_ai_object_cabinet_tea_table;
                double         m_ai_object_cabinet_bed;
                double         m_ai_object_washing_machine;
                double         m_ai_object_weight_scale;
                double         m_ai_object_metal_chair_foot;
                double         m_ai_object_charger;

                double         m_ai_floor_concrete;
                double         m_ai_floor_title;
                double         m_ai_floor_wood;
                double         m_ai_floor_unknow;
                double         m_ai_object_wire_detect;
                double         m_ai_object_chair_base_detect;
                double         m_ai_object_shoe_detect;
                double         m_ai_object_socks_detect;
                double         m_ai_object_weight_scale_detect;
                double         m_ai_object_detect;
                double         m_ai_scene_detect;
                double         m_ai_unknown_object_class_min_score;
                double         m_ai_unknown_object_detect_min_score;
               
                double         m_ai_object_sofa1;
                double         m_ai_object_bed1;
                double         m_ai_object_closestool1;
                double         m_ai_object_refrigerator1;
                double         m_ai_object_washing_machine1;
                double         m_ai_object_cupboard1;
                double         m_ai_object_cabinet_tv1;
                double         m_ai_object_dining_table1;
                double         m_ai_object_cabinet_tea_table1;
                double         m_ai_object_cabinet_bed1;
                

                int            m_ai_mode_number;
                int            m_image_upload_server_frequt;
                int            m_image_upload_server_floor_frequt;
                int            m_image_upload_server_object_frequt;
                int            m_object_detect_num_limit;
                int            m_image_upload_difference_limit_count;

                float          m_all_class_min_scores[MIN_SCORE_CLASS_COUNT];
                float          m_ai_config[AI_CONFIG_ITEM_COUNT];
                base::TAiMode  m_local_ai_mode; 
            private:
                void   loadAllClassMinScores();
                void   loadAIConfig();
                bool loadFileParams(std::string config_file_name,std::string seprate_s,float *params);
                bool saveFromConfigFile();
                bool loadFromConfigFile();
                std::vector<std::string> splitStr(const std::string &s, const std::string &seperator); 

        };
    }
}


#endif


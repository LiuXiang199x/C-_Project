/**********************************************************************************
File name:	  CObjectDetector.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_COBJECTDETECTOR_H_
#define EVEREST_AI_COBJECTDETECTOR_H_

#include <everest/ai/CImage.h>
#include <everest/ai/CYolo3Detector.h>
#include <everest/ai/NanoDet.h>

namespace everest
{
    namespace ai
    {
        class CObjectDetector
        {
            public:
                CObjectDetector();
                ~CObjectDetector();
            
                bool detectObject(CImage &input_image, std::vector<TAIObejectDetectData> &object);
                bool detectObject_Nano(CImage &input_image, std::vector<TAIObejectDetectData> &object);
                bool detectModelAreOk();
                bool detectNanoOk();
            private:
             // CYolo3Detector       m_yolo3_detector;
                NanoDet              m_nanoDet;
        };
    }
}


#endif


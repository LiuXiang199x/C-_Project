/**********************************************************************************
File name:	  CClassification.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CCLASSIFICATION_H_
#define EVEREST_AI_CCLASSIFICATION_H_

#include <everest/ai/CImage.h>
#include <everest/ai/CEfficientNetClassification.h>

namespace everest
{
    namespace ai
    {
        class CClassification
        {
            public:
                CClassification();
                ~CClassification();
            
                bool classification(CImage &input_image, TAIObejectDetectData &detect_data);
                bool classificationFloorBlanket(CImage &input_image, TAIObejectDetectData &detect_data);
                bool classModelAreOk();
            private:
                CEfficientNetClassification      m_efficient_net_classification;
                CEfficientNetClassification      *m_floor_blanket_net_classication;
        };
    }
}

#endif


/**********************************************************************************
File name:	  CClassification.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CCLASSIFICATION_H_
#define EVEREST_AI_CCLASSIFICATION_H_

#include <everest/ai/CImage.h>
#include <everest/ai/CEfficientNetClassification.h>
#include   <everest/ai/mobilenetv2.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <everest/ai.h>
#include <string.h>
#define NUM_CLASS_MAX  100
#define CLASS_MODEL_NEED_BD 0
#define CLASS_MODEL_INT8 0

namespace everest
{
    namespace ai
    {
        class CClassiModelFusion
        {
            public:
                CClassiModelFusion();
                ~CClassiModelFusion();
            
                bool classification(CImage &input_image, TAIObejectDetectData &detect_data);
                bool classificationFloat(CImage &input_image, TAIObejectDetectData &detect_data);
                bool classificationFloorBlanket(CImage &input_image, TAIObejectDetectData &detect_data);
                bool confusionClassification(CImage &input_image, TAIObejectDetectData &detect_data);
                bool classModelAreOk();
            private:
                bool initFloatModels();
                bool initInt8Models();
                bool loadALLClassModelPrecisionInfo(std::string config_file_name,
														std::string seprate_s,
														float *model1,
														float *model2,
														float *model3);
                std::vector<std::string> splitStr(const std::string &s, const std::string &seperator);
                TAIObejectDetectData constractDetectData(TAIObejectDetectData &detect_data);
                double maxThree(double n1,double n2,double n3);
                bool isRecallMostImportantClass(TAIObjectClass object_class);
                bool isPrecisionMostImportantClass(TAIObjectClass object_class);
                bool isNeedBdClass(TAIObjectClass object_class);
                bool classificationBD(cv::Mat &input_image, TAIObejectDetectData &detect_data);
            private:
                // CEfficientNetClassification      m_efficient_net_classification;
                CEfficientNetClassification      *m_all_class_classification1;
                CEfficientNetClassification      *m_all_class_classification2;
                CEfficientNetClassification      *m_all_class_classification3;
                CEfficientNetClassification      *m_floor_blanket_net_classication;
                CEfficientNetClassification      *m_all_class_classification_bd;
                CEfficientNetClassification      *m_all_class_classification;
                float                             m_all_class_model1_precsion[NUM_CLASS_MAX];
                float                             m_all_class_model2_precsion[NUM_CLASS_MAX];
                float                             m_all_class_model3_precsion[NUM_CLASS_MAX];
        };
    }
}

#endif


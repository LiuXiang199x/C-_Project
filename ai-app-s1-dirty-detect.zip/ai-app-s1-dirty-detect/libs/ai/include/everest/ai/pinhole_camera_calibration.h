#pragma once
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
// using namespace cv;

enum CROSSPOINTTYPE
{
	ORIGINX = 1,
	ORIGINY = 2,
	WIDTH = 4,
	HEIGHT = 8
};

struct ImageCalibration{
	int calibration_code;
	cv::Mat image_src;
	cv::Mat image_res;
	string calibratiton_result;
};

class PinholeIntrinsicCalib {
public:
	PinholeIntrinsicCalib();
	~PinholeIntrinsicCalib();

	bool addImage(const cv::Mat& image);
	ImageCalibration getCalibrationParam(cv::Mat& image);

private:
	void dpForOctagon(const std::vector<cv::Point2f>& points, std::vector<cv::Point2f>& pointsSorted, std::vector<bool>& bVisited);
	bool computeCrossPoint(const cv::Point2f& errorPoint, cv::Point2f& curCrossPoint,
		const cv::Size& imageSize, const cv::Point2f& imageCenterPoint, CROSSPOINTTYPE& crossType);
	bool calibIntrinsicHelper(const vector<cv::Mat>& vecImageRaw);
	cv::Mat testIntrinsicByDistortedPicture(const cv::Mat& distort_img);

	int m_NumCheckerBoard;
	int m_AnchorNum;
	int m_WidthCircleNum, mHeightCircleNum;

	int m_CircleSize;
	float m_OffsetAngle;
	float m_ScaleAnchor;
	float m_ScaleAnchorNarrow;

	double m_MeanProejctErrorTh;

	bool m_ClockRotation;

	// cv::Matx33d intrinsic_matrix;
	// cv::Vec4d distortion_coeff;
	cv::Mat intrinsic_matrix = cv::Mat::eye(3, 3, CV_64F);
	cv::Mat distortion_coeff = cv::Mat::zeros(5, 1, CV_64F);
	cv::Size image_size;

	cv::Mat m_CurImg;
	cv::Mat m_MaskImg;

	ImageCalibration m_calibration_param;
};
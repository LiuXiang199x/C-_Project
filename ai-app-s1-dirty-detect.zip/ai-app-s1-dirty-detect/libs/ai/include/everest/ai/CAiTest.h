/*********************************************************************************
File name:	  CCameraSensor.h
Author:       Kimbo
Version:      V1.7.1
Date:	 	  2017-02-03
Description:  3irobotics lidar sdk
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CAiTest_H
#define EVEREST_AI_CAiTest_H

/******************************* Current libs includes ****************************/


/******************************* System libs includes *****************************/
#include <vector>

/******************************* Other libs includes ******************************/

namespace everest
{
	namespace ai
	{

		class CAiTest
		{
            public:


                /* Constructor */
                CAiTest();

                /* Destructor */
                ~CAiTest();

                /* Set device connect */
                bool initilize();


		};
	}
}

#endif



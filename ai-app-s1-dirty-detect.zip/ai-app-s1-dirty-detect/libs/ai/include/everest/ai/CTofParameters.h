/**********************************************************************************
File name:	  CTofParameters.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CTOFPARAMETERS_H_
#define EVEREST_AI_CTOFPARAMETERS_H_

#include <everest/ai.h>

namespace everest
{
    namespace ai
    {
        class CTofParameters
        {
            public:
                CTofParameters();
                ~CTofParameters();

                float getTofCameraWidth() {return m_tof_camera_width;}
                float getTofCameraHeight() {return m_tof_camera_height;}
        
            private:
                const float     m_tof_camera_width;
                const float     m_tof_camera_height;
        };
    }
}


#endif


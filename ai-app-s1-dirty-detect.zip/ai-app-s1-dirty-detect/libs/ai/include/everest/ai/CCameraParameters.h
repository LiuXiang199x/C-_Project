/**********************************************************************************
File name:	  CCameraParameters.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CCAMERAPARAMETERS_H_
#define EVEREST_AI_CCAMERAPARAMETERS_H_

#include "opencv2/opencv.hpp"

namespace everest
{
    namespace ai
    {
        class CCameraParameters
        {
            public:
                CCameraParameters();
                ~CCameraParameters();

                cv::Mat getMapX() {return m_mapx;}
                cv::Mat getMapY() {return m_mapy;}

            private:
                bool loadCameraParams();
            private:
                bool saveFromConfigFile();
                bool loadFromConfigFile();
            
            private:
                double     m_f_x;
                double     m_f_y;
                double     m_c_x;
                double     m_c_y;
                double     m_k1;
                double     m_k2;
                double     m_p1;
                double     m_p2;

                cv::Mat    m_mapx; 
                cv::Mat    m_mapy;

                int        m_origin_width;
                int        m_origin_height;

                int        m_croped_width;
                int        m_croped_heigt;
        };
    }
}


#endif
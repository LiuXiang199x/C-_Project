/**********************************************************************************
File name:	  CYolo3Dector.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CYOLO3DETECTOR_H_
#define EVEREST_AI_CYOLO3DETECTOR_H_

#include "rknn_api.h"
#include "opencv2/opencv.hpp"

#include <everest/ai/CTofParameters.h>
#include <everest/ai.h>

/*********************************** Define ***************************************/
#define GRID0 10
#define GRID1 20
// #define GRID0 13
// #define GRID1 26
#define GRID2 0 
#define SPAN 3
#define LISTSIZE 8

#define OBJ_THRESH  0.35
#define NMS_THRESH  0.5
#define NUM_CLS 3
#define MAX_BOX 100

namespace everest
{
    namespace ai
    {
        class CYolo3Detector
        {
            public:
                struct TRECT 
                {
                    float left;
                    float top;
                    float right;
                    float bottom;
                } ;

                struct TObject
                {
                    TRECT rect;
                    int label;
                    float prob;
                };

            public:
                CYolo3Detector();
                ~CYolo3Detector();
                bool runYoloDector(cv::Mat src_img, std::vector<TAIObejectDetectData> &detect_results);
                bool yoloModelInitOk(){ return m_yolo3_model_init_success;}

            private:
                bool initYoloDector();
                unsigned char *loadModel(const char *filename, int *model_size);
                void printRKNNTensor(rknn_tensor_attr *attr);
                int yolov3PostProcess(float* input0, float* input1, float* out_pos, float* out_prop, int* out_label);

                int process(float output0[1][GRID0][GRID0][SPAN][LISTSIZE], 
							float output1[1][GRID1][GRID1][SPAN][LISTSIZE], 
						    float* out_pos, float* out_prop, int* out_label);

                int nmsSortedBboxes(TObject * objects, int obj_num, int *picked, float nms_threshold);
                float intersectionArea(const TObject *a, const TObject *b);
                void processFeats0(float output[1][GRID0][GRID0][SPAN][LISTSIZE], int anchors[SPAN][2], 
                                   float obj_threshold, float* boxes, int* box_class, float* box_score, int* num_candida);

                void processFeats1(float output[1][GRID1][GRID1][SPAN][LISTSIZE], int anchors[SPAN][2], 
                                   float obj_threshold, float* boxes, int* box_class, float* box_score, int* num_candida);

                float mySigmoid(float x);
                void qsortDescentInplace(TObject* objects, int size);
                void qsortDescentInplace(TObject* objects, int left, int right);

            private:
                unsigned char          *m_model_yolo3;
                rknn_context            m_ctx_yolo3;
                rknn_input_output_num   m_io_num_yolo3;

                rknn_tensor_attr        m_input_attrs_yolo3[1];
	            rknn_tensor_attr        m_output_attrs_yolo3[2];

                CTofParameters          m_tof_params;
                const float             m_network_input_width;
                const float             m_network_input_height;
                bool                    m_yolo3_model_init_success = true;                
        };
    }
}


#endif

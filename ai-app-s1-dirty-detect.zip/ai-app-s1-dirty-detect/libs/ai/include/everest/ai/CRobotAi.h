/*********************************************************************************
File name:	  CRobotAi.h
Author:       luozj
Version:      V
Date:	 	  2019-11-30
Description:  ai module main class
Others:       None.
**********************************************************************************/

#ifndef EVEREST_AI_CROBOTAI_H_
#define EVEREST_AI_CROBOTAI_H_

#include <everest/ai/CImage.h>
#include <everest/ai/CObjectDetector.h>
// #include <everest/ai/CClassification.h>
#include <everest/ai/CClassiModelFusion.h>
#include <everest/ai/CImageLog.h>
#include <everest/base/CEntityProtocol.h>
#include <everest/hwdrivers/CCameraSensor.h>
#include <everest/ai/mobilenetv2.h>

#if CAMERA_200W
#include <calibration/fisheye_camera_calibration.h>
#else
#include <calibration/pinhole_camera_calibration.h>
#endif

#include <everest/ai/CClassificationFilter.h>
#include <list>
namespace everest
{
    namespace ai
    {
        class CRobotAi
        {
            enum TDetectType
            {
                DETECT_TYPE_OBJECT = 0,
                DETECT_TYPE_FLOOR,
                DETECT_TYPE_SCENE,
                DETECT_TYPE_AUTO_TEST,
                DETECT_TYPE_AUTO_CLASS_DETECT_TEST,
            };
            struct bbox
            {
                int m_left;
                int m_top;
                int m_width;
                int m_height;
            
                bbox() {}
                bbox(int left, int top, int width, int height) 
                {
                    m_left = left;
                    m_top = top;
                    m_width = width;
                    m_height = height;
                }
            };
            public:
                CRobotAi();
                ~CRobotAi();

            bool update(CImage &image);

            void setRobotAIMode(base::TAiMode mode);
            base::TAiMode getRobotAiMode(){return m_current_ai_mode;}
            bool needUploadDetectImg() const {return m_need_upload_detect_imgage;}
            bool isCameraCovered() const {return m_is_camera_covered;}
            std::vector<TAIObejectDetectData> getDetectResult() const {return m_result_object;}
            TCameraCalibresult getCalibResult() const {return m_camera_calib_result;}
            CImage getUploadServerImage() {return m_upload_server_image;}
            void clearDetectResult() {m_result_object.clear();}
            void clearUploadServerImage() {cv::Mat em;m_upload_server_image.setOriginImage(em);}
            void clearCalibResult() {m_camera_calib_result.calib_flag=0;}
            void clearCameraCoveredStatus() {m_is_camera_covered = false;}
            private:
                void registerInitializeFunction();
                void registerUpdateFunction();

                void processIdleModeInitialize();
                void processDataCollectionModeInitialize();
                void processDetectionModeInitialize();
                void processOutFamilyTestModeInitialize();
                void processCameraCalibModeInitialize();
                void processServerDataCollectionModeInitialize();

                bool processIdleModeUpdate();
                bool processDataCollectionModeUpdate();
                bool processServerDataCollectionModeUpdate();
                bool processCameraCalibModeUpdate();
                bool processDetectionModeUpdate();
                bool processOutFamilyTestModeUpdate();
                float IOU_cv(const bbox& b1, const bbox& b2, bool base_b1, bool base_b2);
                bool concactOridetectBoxAndCropDetectBox(std::vector<TAIObejectDetectData> &object_ori,
                                   std::vector<TAIObejectDetectData> &object_crop,std::vector<TAIObejectDetectData> &object_concat);
                bool hasSecne(TAIObjectClass object);
                bool setUploadServerImage();
                bool processUploadDetectImgLogic();
                CImage getCurDetectExternImage();
                TDetectType processObjectDetect();
                TDetectType processFloorDetect();
                TDetectType processSceneDetect();
                TDetectType processAutoTestModel();
                TDetectType processAutoTestClassDetectModel();
                bool readDirFileList(const char *directory, std::vector<std::string> &files_list,std::vector<std::string> &files_name_list, bool recursion);

            private:
                bool createObjectClassficationImage(ai::TAIObejectDetectData &object, ai::CImage &image);
                bool createExternObjectClassficationImage(ai::TAIObejectDetectData &object, ai::CImage &image);
                bool createFloorClassficationImage(ai::CImage &image);
            private:
                void invalidImageTest();
                bool imgIsValid(cv::Mat origin_img);
                bool isTwoFrameNearlySame(cv::Mat frame1, cv::Mat frame2);
                bool isTwoDetectInfoNearlySame(TAIObejectDetectData obj_info1, TAIObejectDetectData obj_info2);
                bool initDataCollectionFrequent();
                bool isTheSameWithLatestUploadImages(cv::Mat frame);
                bool isTheSameWithLatestUploadDetectImages(TAIObejectDetectData detect_obj,bool is_floor);
                bool processTheCurrentUploadImage(cv::Mat frame);
                bool processTheCurrentUploadDetectImage();
                void processImgCoverLogic(cv::Mat current_mat);
                bool setBlanketFloorLocationInfo(ai::TAIObejectDetectData &blanket_floor_object);
                bool isDetectObjectsInserInFloorArea(std::vector<TAIObejectDetectData> &result_objects);
                bool isDetectObjectsHasBlanketAndInserInFloorArea(std::vector<TAIObejectDetectData> &result_objects);
                bool avoidBoxInhibitionSceneBox(std::vector<TAIObejectDetectData> &object_ori);
                
                                          
                cv::Mat coverRectMat(cv::Mat img);
            private:
                void (CRobotAi::*mode_initialize_process[base::AI_MODE_NUM])();   	           
                bool (CRobotAi::*mode_update_process[base::AI_MODE_NUM])();

             private:
                CImage              m_current_image;
                CImage              m_upload_server_image;
                cv::Mat             m_last_upload_image;
                cv::Mat             m_last_upload_detect_image;
                TAIObejectDetectData m_last_upload_detect_image_info;
                cv::Mat             m_last_calibration_image;
                cv::Mat             m_last_cover_detect_image;
                TAIObjectClass      m_last_upload_detect_obj_class;
                base::TAiMode       m_current_ai_mode;
                base::TAiMode       m_last_ai_mode;
                TDetectType         m_current_detect_type;

                base::TTimeStamp    m_last_image_time_stamp;
                base::TTimeStamp    m_last_upload_image_time_stamp;

                const double        m_floor_widht_aspatia;
                const double        m_floor_height_aspatia;
                CClassificationFilter classify_filter;

                mobilenetv2  m_mobilev2;
                CObjectDetector     m_object_detector;
                // CClassification     m_classification;
                CClassiModelFusion     m_classification; 
                TCameraCalibresult  m_camera_calib_result;
                std::vector<TAIObejectDetectData> m_result_object;
                std::list<cv::Mat> m_last_upload_images;
                std::list<TAIObejectDetectData> m_last_upload_detect_images;
                long                 m_obj_detect_i;
                long                 m_obj_detect_one_index;
                long                 m_obj_detect_two_index;
                long                 m_obj_detect_one_total_time;
                long                 m_obj_detect_two_total_time;
                long                 m_obj_detect_total_time;
                long long            m_total_detect_count;
                long long            m_object_detect_count;
                long long            m_floor_detect_count; 
                long                 m_calib_img_count;  
                long                 m_upload_server_image_frequent;
                long                 m_detect_obj_num_limit; 
                bool                 m_need_upload_detect_imgage;
                long                 m_upload_detect_floor_count_limit;  
                long                 m_upload_image_different_count_limit;  
                long                 m_upload_detect_image_different_count_limit;         
                long                 m_upload_detect_floor_count;
                long                 m_upload_detect_obj_count;
                long                 m_upload_detect_obj_count_limit;
                bool                 m_is_camera_covered;
                long                 m_camera_cover_frame_count;
                long                 m_serias_detect_obj_count;
                std::string          m_detect_ori_imgage_debug_name;
                long                 m_total_detect_box_count;
                long                 m_check_camera_cover_count;
                base::TTimeStamp     m_last_detect_object_blanket_time;

            private:
                CImageLog               *m_image_log;
               

        };
    }
}

#endif

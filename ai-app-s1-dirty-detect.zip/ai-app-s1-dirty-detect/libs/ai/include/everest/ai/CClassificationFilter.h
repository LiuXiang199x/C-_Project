/**********************************************************************************
File name:	  CClassificationFilter.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CCLASSIFICATIONFILTER_H_
#define EVEREST_AI_CCLASSIFICATIONFILTER_H_

#include <everest/ai.h>
#include <everest/ai/CAiParameters.h>
#include <everest/base/CEntityProtocol.h>

#define TOILET_WIGHT_HEIGHT_ASPATIA_MAX 2.5997  
#define TOILET_WIGHT_HEIGHT_ASPATIA_MIN 0.2962
#define REFRIGERATOR_WIGHT_HEIGHT_ASPATIA_MAX 2.3300  
#define REFRIGERATOR_WIGHT_HEIGHT_ASPATIA_MIN 0.1602
#define WASHING_MACHINE_WIGHT_HEIGHT_ASPATIA_MAX 2.3924  
#define WASHING_MACHINE_WIGHT_HEIGHT_ASPATIA_MIN 0.2269

namespace everest
{
    namespace ai
    {
        class CClassificationFilter
        {
            public:
                CClassificationFilter();
                ~CClassificationFilter();

                bool filter(TAIObejectDetectData &classify_data);
                bool filterFloor(TAIObejectDetectData &classify_data);
                bool filterNotInInterestAreaDetectData(TAIObejectDetectData &classify_data);
                bool filterUnknownObjectData(TAIObejectDetectData &classify_data);
                bool filterObject(TAIObejectDetectData &classify_data,base::TAiMode ai_mode);
                bool filterScene(TAIObejectDetectData &classify_data);
                bool boxCenterPointIsInAvoidInterestArea(TAIObejectDetectData &classify_data);
                bool boxWholeIsInAvoidInterestArea(TAIObejectDetectData &classify_data);
                bool boxNeedToBeInhibitedByAvoidBox(TAIObejectDetectData &classify_data);
                
            private:
                bool filterByScore(TAIObejectDetectData &classify_data);
                void get_detect_box_center(TAIObejectDetectData obj_roi_class_result,int &x_center, int &y_center);
                bool detectBoxLocationImageBottom(TAIObejectDetectData obj_roi_class_result);
                bool detectBoxLocationImageMiddle(TAIObejectDetectData obj_roi_class_result);
                bool detectBoxLocationImageTop(TAIObejectDetectData obj_roi_class_result);

            private:
                CAiParameters m_ai_parameter;
        };
    }
}


#endif

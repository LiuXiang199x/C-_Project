/**********************************************************************************
File name:	  CImageTransform.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CIMAGETRANSFORM_H_
#define EVEREST_AI_CIMAGETRANSFORM_H_

#include <everest/ai/CCameraParameters.h>

namespace everest
{
    namespace ai
    {
        class CImageTransform
        {
            public:
                CImageTransform();
                ~CImageTransform();

                cv::Mat fishRemap(cv::Mat &origin_image);
                cv::Mat resizeImage(cv::Mat &origin_image);

            private:
                CCameraParameters   m_camera_params;

                double              m_resize_ratio;
        };
    }
}


#endif
#ifndef LIQUID_H
#define LIQUID_H
//#include "commdef.h"
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include <everest/ai.h>
#include "rknn_api.h"
#include <everest/ai/CTofParameters.h>

#include <vector>
#include <string>
#include <math.h>



namespace everest
{
    namespace ai
    {
            struct BoundingBox
            {
                float x1;
                float y1;
                float x2;
                float y2;
                int label;
                float score;
            };

            typedef struct {
                cv::Rect2f box;
                float confidence;
                int index;
            }BBOX;

            struct Object
            {
                cv::Rect_<float> rect;
                int label;
                float prob;
            };

            typedef struct HeadInfo
            {
                std::string cls_layer;
                std::string dis_layer;
                int stride;
            };

            struct CenterPrior
            {
                int x;
                int y;
                int stride;
            };

            typedef struct BoxInfo
            {
                float x1;
                float y1;
                float x2;
                float y2;
                float score;
                int label;
            } BoxInfo;



        class NanoDet
        {
            public:

                int input_size[2] = {416, 416}; // input height and width
                int num_class = 3; // number of classes. 80 for COCO
                int reg_max = 7; // `reg_max` set in the training config. Default: 7.
                int m_init_success=0;
                std::vector<int> strides = { 8, 16, 32, 64 }; // strides of the multi-level feature.
            public:
                NanoDet();
                ~NanoDet();
                rknn_context m_ctx;
                unsigned char *m_model;

                bool NanoInitOk(){ return m_init_success>=0;}
            public:
                int ini();
                void printRKNNTensor(rknn_tensor_attr *attr);
                unsigned char *load_model(const char *filename, int *model_size);
                int nano_det(const cv::Mat& bgr, std::vector<BoxInfo>& objects, float score_threshold, float nms_threshold);


                void nms(std::vector<BoxInfo>& input_boxes, float nms_thread);
                BoxInfo disPred2Bbox(const float*& dfl_det, int label, float score, int x, int y, int stride);
                void decode_infer(float* feats, std::vector<CenterPrior>& center_priors, float threshold, std::vector<std::vector<BoxInfo>>& results);
                bool runNanoDector(cv::Mat src_img, std::vector<TAIObejectDetectData> &detect_results);

                CTofParameters   m_tof_params;
        };
    }
}
#endif // LIQUID_H

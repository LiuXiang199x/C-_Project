/**********************************************************************************
File name:	  CTypeTransform.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef EVEREST_AI_CTYPETRANSFORM_H
#define EVEREST_AI_CTYPETRANSFORM_H

#include <everest/ai.h>
#include <string>

namespace everest
{
    namespace ai
    {
        class CTypeTransform
        {
            public:
                CTypeTransform();
                ~CTypeTransform();

                static std::string aiLable2String(AIAllClassLabel lable);
                static AIAllClassLabel string2AiLable(std::string lable_string);
                static std::string aiFloorBlanketLable2String(AIFloorBlanketClassLabel lable);

                static std::string aiObjectClass2String(TAIObjectClass object_class);
                static TAIObjectClass string2AiObjectClass(std::string object_string);
                static TAIObjectClass aiFloorBlanketLable2AiObjectClass(AIFloorBlanketClassLabel lable);
           //     static AIAllClassLabel  aiDirtyLable2AiObjectClass(AIDirtyClassLabeL lable);

                static TAIObjectClass aiLable2AiObjectClass(AIAllClassLabel lable);
                static AIAllClassLabel aiObjectClass2aiLable(TAIObjectClass object_class);

                static void transferWeightData(TAIObjectClass &obj_class, double &obj_score);
                static bool isWeightClass(TAIObjectClass obj_class);
                static bool isLowWeightClass(TAIObjectClass obj_class);
        }; 
    }
}


#endif


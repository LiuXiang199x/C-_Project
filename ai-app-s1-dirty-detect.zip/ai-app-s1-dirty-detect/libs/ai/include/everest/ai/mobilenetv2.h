/**********************************************************************************
File name:	  CEfficientNetClassification.h
Author:       Kimbo
Version:      V1.6.2
Date:	 	  2016-10-27
Description:  None
Others:       None

History:
	1. Date:
	Author: Kimbo
	Modification:
***********************************************************************************/

#ifndef MOBILE_H_
#define MOBILE_H_

#include <everest/ai/CAiParameters.h>

#include "rknn_api.h"
#include "opencv2/opencv.hpp"

#include <everest/ai.h>

namespace everest
{
    namespace ai
    {
        // enum CLASS_MODLE_TYPE
        // {
        //     CLASS_MODLE_TYPE_ALL = 0,
        //     CLASS_MODLE_TYPE_FLOOR_BLANKET = 1
        // };
        class mobilenetv2
        {
            public:
                mobilenetv2();
                mobilenetv2(int network_input_width, int network_input_height, std::string model_path);
                ~mobilenetv2();


            int rknn_GetTop(float *pfProb,
                float *pfMaxProb,
                uint32_t *pMaxClass,
                uint32_t outputCount,
                uint32_t topNum
                );
                bool runmobilenetv2Classifiaction(cv::Mat &src_img, TAIObejectDetectData &result);
                bool init_success(){return m_init_success;}
            private:
                std::vector<int> get_bdbox(float min_x, float min_y, float max_x,float  max_y);
                bool initmobilenetv2(); 
                unsigned char *loadModel(const char *filename, int *model_size);
                void printRKNNTensor(rknn_tensor_attr *attr);

                void getTopN(float* prediction, int prediction_size, size_t num_results,
                             float threshold, std::vector<std::pair<float, int>>* top_results,
                             bool input_floating); 
                void activation_function_softmax(float* src, float* dst, int length);
            private:
                unsigned char          *m_model;         
                rknn_context            m_ctx;
                rknn_input_output_num   m_io_num;

                rknn_tensor_attr        m_input_attrs[100];
	            rknn_tensor_attr        m_output_attrs[100];

                int                     m_top_n_result;
                double                  m_min_score;

                // const int               m_network_input_width;
                // const int               m_network_input_height;
                int                     m_network_input_width;
                int                     m_network_input_height;
            //    CLASS_MODLE_TYPE        m_class_model_type;
                std::string             m_model_path;
                bool                    m_init_success = true;
                CAiParameters           m_ai_parameter;
        };  
    }
}





#endif

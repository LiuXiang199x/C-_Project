/**********************************************************************************
File name:	  CRobotPacketReceiver.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is used to receive robot packet
Others:       None

History:
	1. Date: 2015-09-15
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/
#ifndef EVEREST_HWDRIVERS_CROBOTPACKETRECEIVER_H
#define EVEREST_HWDRIVERS_CROBOTPACKETRECEIVER_H

/********************************** Current libs includes *************************/
#include <everest/hwdrivers/CRobotPacket.h>
#include <deque>

#define ROBOT_PACKET_DEBUG 0
namespace everest
{
	namespace hwdrivers
	{
		class CDeviceConnection;

		/* Given a device connection it receives packets from the robot through it */
		class CRobotPacketReceiver
		{
			public:
				enum TState
				{
					STATE_SYNC1 = 0,
					STATE_SYNC2,
					STATE_LENGTH,
					STATE_ACQUIRE_DATA
				};

				/* Constructor without an already assigned device connection */
				CRobotPacketReceiver();

				/* Constructor with assignment of a device connection */
				CRobotPacketReceiver(CDeviceConnection *device_connection);

				/* Destructor */
				virtual ~CRobotPacketReceiver();

				/* Receives a packet from the robot if there is one available */
				bool receivePacket(CRobotPacket *packet, unsigned int ms_wait = 1000);

				/* Sets the device this instance receives packets from */
				void setDeviceConnection(CDeviceConnection *device_connection);

				/* Gets the device this instance receives packets from */
				CDeviceConnection *getDeviceConnection(void);

				/* Get lost count */
                int getLostCount() {return m_lost_count;}

                /* Reset lost count */
                void resetLostCount() {m_lost_count = 0;}

                /* Enable log when receive time overs */
                void enableLogWhenReceiveTimeOvers(bool enable) {m_log_receive_time_out = enable;}

                void setReceiveID(int id) { m_id = id;}
			private:
				/* Read serial packet, if it return ture, it means read complete packet */
				bool readSerialPacket(CRobotPacket *packet, u8 ch);

				/* process state sync1 */
				void processStateSYNC1(CRobotPacket *packet, u8 ch);

				/* Process state sync2 */
				void processStateSYNC2(CRobotPacket *packet, u8 ch);

				/* Process state length */
				void processStateLength(CRobotPacket *packet, u8 ch);

				/* Process state acquire data */
				bool processStateAcquireData(CRobotPacket *packet, u8 ch);

                /* Reset serial read */
                void resetSerialRead();

			protected:
				CDeviceConnection 	*m_device_conn;
				CRobotPacket 		m_packet;
				int                 m_serial_data_count;
				int                 m_actual_data_count;
				TState				m_state;
                int                 m_lost_count;
                bool                m_log_receive_time_out;
                int                 m_id;
				std::deque<char>	m_buffer;
            #if ROBOT_PACKET_DEBUG
				FILE                *m_fp;
            #endif
		};
	}
}
#endif

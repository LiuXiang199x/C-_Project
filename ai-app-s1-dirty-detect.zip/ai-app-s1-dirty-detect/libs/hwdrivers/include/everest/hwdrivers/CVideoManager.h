/*************************************************************************
	> File Name: CVideoManager.h
	> Author:
	> Mail:
	> Created Time: 2020年05月09日 星期六 21时52分52秒
 ************************************************************************/

#ifndef _CVIDEOMANAGER_H
#define _CVIDEOMANAGER_H
#include <string>
#include <sys/select.h>

#include "rkisp_api.h"
#include "Thread.h"

typedef void (*videoCallback)(char * data,int length);

class CVideoManager:public Thread
{

public:
    CVideoManager();
    ~CVideoManager();
    void Init(const char *device,int width,int heigth,int fcc,videoCallback callback);
    bool Start();
    bool Stop();
    void run();

protected:
    int WaitFrames();
    bool GetFrames();
    void PutFrames();
private:

    const struct rkisp_api_ctx  *m_api;
    const struct rkisp_api_buf  *m_cur_frame;
    int m_width;
    int m_height;
    int m_fcc;
    std::string m_device;
    fd_set m_fds;
    videoCallback m_callback;
    bool m_running;
};
#endif

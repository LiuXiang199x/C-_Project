/*************************************************************************
	> File Name: CThread.h
	> Author:
	> Mail:
	> Created Time: 2016年03月05日 星期六 09时47分58秒
 ************************************************************************/

#ifndef _CTHREAD_H
#define _CTHREAD_H

#include <pthread.h>

class Thread
{
public:
	Thread();
	virtual ~Thread();


private:
    pthread_t pid;
   static void * start_thread(void *arg);
public:
    int start();
    void stop();
    virtual void run() = 0;
    bool m_bool;
    int ThreadGetID(void);
};

#endif

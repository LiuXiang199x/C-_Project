/*********************************************************************************
File name:	  CCameraSensor.h
Author:       Kimbo
Version:      V1.7.1
Date:	 	  2017-02-03
Description:  3irobotics lidar sdk
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

#ifndef EVEREST_LIDAR_CCameraSensor_H
#define EVEREST_LIDAR_CCameraSensor_H

/******************************* Current libs includes ****************************/
#include <everest/hwdrivers/CVideoRgaManager.h>

/******************************* System libs includes *****************************/
#include <vector>

#define CAMERA_200W  1
/******************************* Other libs includes ******************************/

namespace everest
{
	namespace hwdrivers
	{
        

        #if CAMERA_200W 
            #define SC_CAMERA_CROPED_WIDTH  642
            #define SC_CAMERA_CROPED_HEIGHT 362 

            #define SC_CAMERA_SRC_WIDTH     960
            #define SC_CAMERA_SRC_HEIGHT    540

            #define SC_CAMERA_DEST_WIDTH    960
            #define SC_CAMERA_DESTH_HEIGHT  540

        #else //100W
            #define SC_CAMERA_CROPED_WIDTH  640
            #define SC_CAMERA_CROPED_HEIGHT 360 

            #define SC_CAMERA_SRC_WIDTH     640
            #define SC_CAMERA_SRC_HEIGHT    360

            #define SC_CAMERA_DEST_WIDTH    640
            #define SC_CAMERA_DESTH_HEIGHT  360
        #endif
        

		class CCameraSensor
		{
            public:

                /* Constructor */
                CCameraSensor();

                /* Destructor */
                ~CCameraSensor();

                /* Set device connect */
                bool initilize(rgaCallback callback);
                bool start();
                bool stop();
                bool open();
                bool close();

                #define FILE_PATH_LEN  64
                struct video_ctx 
                {
                    char dev_name[FILE_PATH_LEN];
                    int width;
                    int height;
                    int fcc;

                    int dst_width;
                    int dst_height;
                    int dst_fcc;

                    FILE *save_fp;
                    int count;
                };
            private:
                video_ctx           *g_video_ctx;
                CVideoRgaManager    rga_camera;

		};
	}
}

#endif



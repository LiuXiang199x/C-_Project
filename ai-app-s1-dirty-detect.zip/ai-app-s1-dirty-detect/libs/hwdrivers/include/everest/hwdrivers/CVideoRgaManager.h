/*************************************************************************
	> File Name: CVideoRgaManager.h
	> Author:
	> Mail:
	> Created Time: 2020年05月15日 星期五 13时39分09秒
 ************************************************************************/

#ifndef _CVIDEORGAMANAGER_H
#define _CVIDEORGAMANAGER_H

#include <string>
#include "RockchipRga.h"
#include "rkisp_api.h"
#include "Thread.h"
#include <functional>



typedef  std::function<void(char * data, int length)> rgaCallback;


class CVideoRgaManager:public Thread
{
public:
    CVideoRgaManager();
    ~CVideoRgaManager();
    void Init(const char *device,int s_width,int s_heigth,int s_fcc,int d_width,int d_heigth,int d_fcc,rgaCallback m_callback);
    bool Start();
    bool Stop();
    void run();

protected:
    int WaitFrames();
        bool GetFrames();
    void PutFrames();
    RockchipRga m_rga;
private:

    const struct rkisp_api_ctx  *m_api;
    const struct rkisp_api_buf  *m_cur_frame;
    int m_width;
    int m_height;
    int m_fcc;

    int m_rga_width;
    int m_rga_height;
    int m_rga_fcc;

	rga_info_t m_rga_src;
    rga_info_t m_rga_dst;
	bo_t m_bo_dst;

    std::string m_device;
    fd_set m_fds;
    rgaCallback m_callback;
    bool m_running;
};
#endif

/**********************************************************************************
File name:	  CRobotPacket.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is the robot packet
Others:       None

History:
	1. Date: 2015-09-20
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/
#ifndef EVEREST_HWDRIVERS_CROBOTPACKET_H_
#define EVEREST_HWDRIVERS_CROBOTPACKET_H_

/********************************** File includes *********************************/
#include <everest/hwdrivers/typedef.h>
#include <everest/base/ferrari_protocol.h>
/********************************** Current libs includes *************************/

/********************************** System includes *******************************/
#include <string>
#include <stdbool.h>

/******************************* Other libs includes ******************************/

namespace everest
{
	namespace hwdrivers
	{
		class CRobotPacket
		{
			public:
				struct TParams
				{
					/* Constructor */
					TParams();

					u8	sync1;
					u8	sync2;
					u8	frame_header_size;
					u8	command_id_size;
					u8	buffer_len_size;
					u8	crc_size;
				};

				/* Constructor */
				CRobotPacket();

                /* Constructor */
                CRobotPacket(u8 cmd_id, void *buf, u8 len);

				/* Destrcutor */
				~CRobotPacket();

				/* Create packet */
				void createPacket(u8 cmd_id, char *buf, u8 len);

				/* Create packet buf */
				void setPacketBuf(char *buf, u8 len);

                /* Set packet buf */
                void setBuf(char *buf, u8 len);

				/* Clear packet */
				void clearPacket();

				/* Get buffer pointer */
				char *getBuf();

				/* Get data length */
				u8 getLength();
				u8 getDataLength();
				u8 getFooterLength();
				u8 getHeaderLength();
				u8 getDataReadLength();

				/* Set/Get packet valid */
				void setPacketValid(bool valid);
				bool isValid();

				/* Set/Get packet ID */
				u8 getPacketID();
				void setPacketID(u8 id);

				/* Set length */
				void setLength(u8 length);

				/* CRC sum calculate */
				u16 calcCheckSum();
				bool verifyCheckSum();

                /* Get read length */
                u16 getReadLength();
                void resetRead();

				/* Read and write capacity realate */
				bool isNextGood(int bytes);
				bool hasWriteCapacity(int bytes);
				void finalizePacket();

				/* Append data to buffer */
				void appendPacket(char *buf, u8 size);
				void byteToBuf(s8 val);
				void byte2ToBuf(s16 val);
				void byte4ToBuf(s32 val);
				void uByteToBuf(u8 val);
				void uByte2ToBuf(u16 val);
				void uByte4ToBuf(u32 val);

				/* Read packet to data */
				bool readPacket(char *data, u8 size);
				s8 bufToByte();
				s16 bufToByte2();
				s32 bufToByte4();
				u8 bufToUByte();
				u16 bufToUByte2();
				u32 bufToUByte4();

                /* Print hex */
                void printHex();

            public:
                TParams		m_params;
			private:
                #define     MAX_BUF_LEN 150
				char 		m_buf[MAX_BUF_LEN];			/* Packet buffer */
				u16			m_read_length;		/* User read length */
				u16			m_length;			/* Buffer length */
				bool		m_valid;
		};
	}
}

#endif

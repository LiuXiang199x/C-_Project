/**********************************************************************************
File name:	  CRobotPacketSender.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is used to receive robot packet
Others:       None

History:
	1. Date: 2015-09-21
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/
#ifndef EVEREST_HWDRIVERS_CROBOTPACKETSENDER_H_
#define EVEREST_HWDRIVERS_CROBOTPACKETSENDER_H_

/********************************** Current libs includes *************************/
#include "CRobotPacket.h"

/******************************* Other libs includes ******************************/

namespace everest
{
	namespace hwdrivers
	{
		class CDeviceConnection;

		/* Given a device connection this sends commands through it to the robot */
		class CRobotPacketSender
		{
			public:
				/* Constructor without an already assigned device connection */
				CRobotPacketSender();

				/* Constructor with assignment of a device connection */
				CRobotPacketSender(CDeviceConnection *deviceConnection);

				/* Destructor */
				virtual ~CRobotPacketSender();

				/* Sends a command to the robot with no arguments */
				bool sendCommand(u8 command);

				/* Sends a command to the robot with an int for argument */
				bool sendByte2(u8 command, s16 argument);

				/* Sends a command to the robot with an int for argument */
				bool send2Byte2(u8 command, s16 first, s16 second);

				/* Sends a command to the robot with two bytes for argument */
				bool send2Byte(u8 command, s8 high, s8 low);

				/* Sends a CRobotPacket */
				bool sendPacket(CRobotPacket *packet);

				/* Sends buffer data */
				bool sendBuf(char *buf, int length);

				/* Sets the device this instance sends commands to */
				void setDeviceConnection(CDeviceConnection *deviceConnection);

				/* Gets the device this instance sends commands to */
				CDeviceConnection *getDeviceConnection(void);

			protected:
				/* Return true, if device conn is connecting */
				bool connValid(void);

			protected:
				CDeviceConnection 		            *m_device_conn;
				pthread_mutex_t                      m_lock;
		};
	}
}

#endif

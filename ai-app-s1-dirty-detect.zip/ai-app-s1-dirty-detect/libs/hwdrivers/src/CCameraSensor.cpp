/*********************************************************************************
File name:	  CCameraSensor.h
Author:       Kimbo
Version:      V1.7.1
Date:	 	  2017-02-03
Description:  3irobotics lidar sdk
Others:       None

History:
	1. Date:
	Author:
	Modification:
***********************************************************************************/

/********************************* File includes **********************************/
#include "everest/hwdrivers/CCameraSensor.h"

/******************************* Current libs includes ****************************/
#include "everest/base/CLog.h"

#include <iostream>
#include <string.h>

/********************************** Name space ************************************/
using namespace everest;
using namespace everest::hwdrivers;



/***********************************************************************************
Function:     CCameraSensor
Description:  The constructor of CCameraSensor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CCameraSensor::CCameraSensor()
{
  
}

/***********************************************************************************
Function:     CCameraSensor
Description:  The destructor of CCameraSensor
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CCameraSensor::~CCameraSensor()
{

}

/***********************************************************************************
Function:     initilize
Description:  Set device connect
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CCameraSensor::initilize(rgaCallback callback)
{
    g_video_ctx = (video_ctx*)malloc(sizeof(struct video_ctx));
    if(g_video_ctx == NULL)
    {
        CLog::log(LogKimbo, LogNormal, "[CCameraSensor] malloc camera memory failed!\n");
        return false;

    }
    strcpy(g_video_ctx->dev_name,"/dev/video1");
    g_video_ctx->width = SC_CAMERA_SRC_WIDTH;
    g_video_ctx->height = SC_CAMERA_SRC_HEIGHT;
    g_video_ctx->fcc = 1;

    g_video_ctx->dst_width = SC_CAMERA_DEST_WIDTH;
    g_video_ctx->dst_height = SC_CAMERA_DESTH_HEIGHT;
    g_video_ctx->dst_fcc = 1;

    rga_camera.Init(g_video_ctx->dev_name,g_video_ctx->width,
                    g_video_ctx->height,g_video_ctx->fcc,
                    g_video_ctx->dst_width,g_video_ctx->dst_height,
                    g_video_ctx->dst_fcc,callback);
    if(rga_camera.Start())
    {
        CLog::log(LogKimbo, LogNormal, "[CCameraSensor] initilize camera sucess!\n");
        sleep(1);
        rga_camera.Stop();
        return true;
    }
    else
    {
        CLog::log(LogKimbo, LogNormal, "[CCameraSensor] initilize camera fail!\n");
        sleep(1);
        rga_camera.Stop();
        return false;
    }
    
    
}

bool CCameraSensor::start()
{
    return rga_camera.Start();
}

bool CCameraSensor::stop()
{
    return rga_camera.Stop();
}
bool CCameraSensor::open()
{
    return rga_camera.Start();
}

bool CCameraSensor::close()
{
    return rga_camera.Stop();
}

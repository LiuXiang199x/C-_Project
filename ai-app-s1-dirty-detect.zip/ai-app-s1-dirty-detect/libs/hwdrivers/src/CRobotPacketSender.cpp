/**********************************************************************************
File name:	  CRobotPacketSender.cpp
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is used to receive robot packet
Others:       None

History:
	1. Date: 2015-09-21
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/hwdrivers/CRobotPacketSender.h>

/********************************** Current libs includes *************************/
#include <everest/hwdrivers/CDeviceConnection.h>

/********************************** Name space ************************************/
using namespace std;
using namespace everest::hwdrivers;

/***********************************************************************************
Function:     CRobotPacketReceiver
Description:  The constructor of CRobotPacketReceiver
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketSender::CRobotPacketSender()
{
	m_device_conn = NULL;
	pthread_mutex_init(&m_lock, NULL);
}

/***********************************************************************************
Function:     CRobotPacketReceiver
Description:  The constructor of CRobotPacketReceiver
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketSender::CRobotPacketSender(CDeviceConnection *device_connection)
{
	m_device_conn = device_connection;
}

/***********************************************************************************
Function:     CRobotPacketReceiver
Description:  The destructor of CRobotPacketReceiver
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketSender::~CRobotPacketSender()
{

}

/***********************************************************************************
Function:     setDeviceConnection
Description:  Set the connection devices
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketSender::setDeviceConnection(CDeviceConnection *device_connection)
{
  m_device_conn = device_connection;
}

/***********************************************************************************
Function:     getDeviceConnection
Description:  Get the connection devices
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CDeviceConnection *CRobotPacketSender::getDeviceConnection(void)
{
  return m_device_conn;
}

/***********************************************************************************
Function:     connValid
Description:  Judge whether if device conn is Valid
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::connValid(void)
{
	if(m_device_conn != NULL &&	m_device_conn->getStatus() == CDeviceConnection::STATUS_OPEN)
	{
		return true;
	}
	else
	{
		printf("[CRobotPacketSender] device is not connecting!\n");
		return false;
	}
}

/***********************************************************************************
Function:     connValid
Description:  Judge whether if device conn is Valid
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::sendCommand(u8 command)
{
	CRobotPacket packet = CRobotPacket(command, NULL, 0);
	return sendPacket(&packet);
}

/***********************************************************************************
Function:     send2Byte2
Description:  Send byte2 to device conn
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::sendByte2(u8 command, s16 data)
{
	CRobotPacket packet = CRobotPacket(command, (char *)&data, 2);
	return sendPacket(&packet);
}

/***********************************************************************************
Function:     send2Byte2
Description:  Send two byte2 to device conn
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::send2Byte2(u8 command, s16 first, s16 second)
{
	s32 data = (first << 8) + (second);
	CRobotPacket packet = CRobotPacket(command, (char *)&data, 4);
	return sendPacket(&packet);
}

/***********************************************************************************
Function:     send2Byte
Description:  Send two bytes to device conn
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::send2Byte(u8 command, s8 high, s8 low)
{
	s16 data = (high & 0xff << 8) + (low & 0xff);
	return sendByte2(command, data);
}

/***********************************************************************************
Function:     sendPacket
Description:  Send buffer to device conn
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::sendPacket(CRobotPacket *packet)
{
	return sendBuf(packet->getBuf(), packet->getLength());
}

/***********************************************************************************
Function:     sendBuf
Description:  Send buffer to device conn
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketSender::sendBuf(char* buf, int length)
{
	if (!connValid())
	{
		return false;
	}

	bool ret = true;
	{
	    pthread_mutex_lock(&m_lock);
		ret = (m_device_conn->write(buf, length) >= 0);
        pthread_mutex_unlock(&m_lock);
	}
	return ret;
}





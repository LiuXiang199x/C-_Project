/**********************************************************************************
File name:	  CRobotPacket.h
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is the robot packet
Others:       None

History:
	1. Date: 2015-09-20
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/

/********************************** File includes *******************((************/
#include <everest/hwdrivers/CRobotPacket.h>

/********************************** Current libs includes *************************/

/********************************** System includes *******************************/
#include <string.h>
#include <stdio.h>
#include <iostream>

/********************************** Name space ************************************/
using namespace std;
using namespace everest;
using namespace everest::hwdrivers;

/***********************************************************************************
Function:     CRobotPacket
Description:  The constructor of CRobotPacket
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacket::CRobotPacket()
{
	clearPacket();
}

/***********************************************************************************
Function:     CRobotPacket
Description:  The constructor of CRobotPacket
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacket::CRobotPacket(u8 cmd_id, void *buf, u8 len)
{
    createPacket(cmd_id, (char*)buf, len);
}

/***********************************************************************************
Function:     CRobotPacket
Description:  The destructor of CRobotPacket
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacket::~CRobotPacket()
{
}

/***********************************************************************************
Function:     createPacket
Description:  create packet
Input:        TCommandID cmd_id,
			  char *buf,
			  u8 len
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::createPacket(u8 cmd_id, char *buf, u8 len)
{
	clearPacket();
	setPacketID(cmd_id);

	if (buf != NULL && len > 0)
	{
		setPacketBuf(buf, len);
	}
	else
	{
		// The packet only has cmd id
	}
	finalizePacket();
}

/***********************************************************************************
Function:     setBuf
Description:  set packet buffer
Input:        char *buf, u8 len
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::setPacketBuf(char *buf, u8 len)
{
	if(hasWriteCapacity(len))
	{
		memcpy(m_buf + getHeaderLength(), buf, len);
		m_length = getHeaderLength() + len;
	}
	else
	{
		// It is out of range
		printf("Buf is out of range!\n");
	}
}

/***********************************************************************************
Function:     Set packet buf
Description:  set packet buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::setBuf(char *buf, u8 len)
{
    clearPacket();
    memcpy(m_buf, buf, len);
    m_length = len;
}

/***********************************************************************************
Function:     getBuf
Description:  get packet buffer
Input:        char *buf, u8 len
Output:       None
Return:       None
Others:       None
***********************************************************************************/
char* CRobotPacket::getBuf()
{
	return m_buf;
}

/***********************************************************************************
Function:     getLength
Description:  get packet length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getLength()
{
	return m_length;
}

/***********************************************************************************
Function:     setLength
Description:  set packet length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::setLength(u8 length)
{
    m_length = length;
}

/***********************************************************************************
Function:     getDataLength
Description:  set data length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getDataLength()
{
	return m_length - getHeaderLength() - getFooterLength();
}

/***********************************************************************************
Function:     getReadLength
Description:  get packet read length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u16 CRobotPacket::getReadLength()
{
	return m_read_length;
}

/***********************************************************************************
Function:     getHeaderLength
Description:  get packet header length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getHeaderLength()
{
	return (m_params.frame_header_size + m_params.command_id_size + m_params.buffer_len_size);
}

/***********************************************************************************
Function:     getFooterLength
Description:  get packet footer length
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getFooterLength()
{
	return m_params.crc_size;
}

/***********************************************************************************
Function:     getDataReadLength
Description:  get packet data readlength
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getDataReadLength()
{
	return m_read_length - getHeaderLength();
}

/***********************************************************************************
Function:     resetRead
Description:  reset read
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::resetRead()
{
	m_read_length = getHeaderLength();
}

/***********************************************************************************
Function:     setPacketValid
Description:  reset valid
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::setPacketValid(bool valid)
{
	m_valid = valid;
}

/***********************************************************************************
Function:     clearPacket
Description:  Clear packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::clearPacket()
{
	m_length = getHeaderLength();
	m_read_length = getHeaderLength();
	m_valid = false;
	memset(m_buf, 0, sizeof(char) * MAX_BUF_LEN);
}

/***********************************************************************************
Function:     appendPacket
Description:  Append buffer to packe
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::appendPacket(char *buf, u8 size)
{
	if(!hasWriteCapacity(size))
	{
		return ;
	}
	memcpy(m_buf + m_length, buf, size);
	m_length += size;
}

/***********************************************************************************
Function:     byteToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::byteToBuf(s8 val)
{
	appendPacket((char*)&val, 1);
}

/***********************************************************************************
Function:     byte2ToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::byte2ToBuf(s16 val)
{
	appendPacket((char*)&val, 2);
}

/***********************************************************************************
Function:     byte4ToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::byte4ToBuf(s32 val)
{
	appendPacket((char*)&val, 4);
}

/***********************************************************************************
Function:     uByteToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::uByteToBuf(u8 val)
{
	appendPacket((char*)&val, 1);
}

/***********************************************************************************
Function:     uByte2ToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::uByte2ToBuf(u16 val)
{
	appendPacket((char*)&val, 2);
}

/***********************************************************************************
Function:     uByte4ToBuf
Description:  val to copy into buffer
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::uByte4ToBuf(u32 val)
{
	appendPacket((char*)&val, 4);
}

/***********************************************************************************
Function:     readPacket
Description:  Copies length bytes from the buffer into data, length is passed
			  in, not read from packet
Input:        char *data: data character array to copy the data into
			  u8 size	: length number of bytes to copy into data
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacket::readPacket(char *data, u8 size)
{
	if (data == NULL)
	{
		return FALSE;
	}
	if (isNextGood(size))
	{
		memcpy(data, m_buf+m_read_length, size);
		m_read_length += size;
        return TRUE;
	}
	else
	{
	    return FALSE;
	}
}

/***********************************************************************************
Function:     bufToByte
Description:  copy s8 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
s8 CRobotPacket::bufToByte()
{
	s8 ret=0;
	readPacket((char*)&ret, 1);
    return ret;
}

/***********************************************************************************
Function:     bufToByte2
Description:  copy s16 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
s16 CRobotPacket::bufToByte2()
{
	s16 ret=0;
	readPacket((char*)&ret, 2);
	return ret;
}

/***********************************************************************************
Function:     bufToByte4
Description:  copy s32 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
s32 CRobotPacket::bufToByte4()
{
    s32 ret=0;
    readPacket((char*)&ret, 4);
	return ret;
}

/***********************************************************************************
Function:     bufToUByte
Description:  copy u8 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::bufToUByte()
{
	u8 ret=0;
    readPacket((char *)&ret, 1);
	return(ret);
}

/***********************************************************************************
Function:     bufToUByte2
Description:  copy u16 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u16 CRobotPacket::bufToUByte2()
{
	u16 ret=0;
    readPacket((char *)&ret, 2);
	return ret;
}

/***********************************************************************************
Function:     bufToUByte4
Description:  copy u32 to packet
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u32 CRobotPacket::bufToUByte4()
{
	u32 ret=0;
    readPacket((char *)&ret, 4);
    return ret;
}

/***********************************************************************************
Function:     isNextGood
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Input:        int bytes: packet the packet to duplicate
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacket::isNextGood(int bytes)
{
	if (bytes <= 0)
        return FALSE;

    // make sure it comes in before the header
	if (m_read_length + bytes <= m_length - getFooterLength())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/***********************************************************************************
Function:     hasWriteCapacity
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Input:        int bytes: packet the packet to duplicate
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacket::hasWriteCapacity(int bytes)
{
	if (bytes < 0)
	{
		return FALSE;
	}

	// Make sure there's enough room in the packet
	if ((m_length + bytes) <= MAX_BUF_LEN)
	{
        return TRUE;
	}
	else
	{
		m_valid = FALSE;
		return FALSE;
	}
}

/***********************************************************************************
Function:     isValid
Description:  A packet is considered "invalid" if an attempt is made to write too much
			  data into the packet, or to read too much data from the packet.  Calls to
			  empty() and resetRead() will restore the valid state.
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacket::isValid()
{
	return m_valid;
}

/***********************************************************************************
Function:     isValid
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u8 CRobotPacket::getPacketID()
{
	if(m_length >= 4)
		return m_buf[3];
	else
		return CMD_END;
}

/***********************************************************************************
Function:     isValid
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::setPacketID(u8 id)
{
	m_buf[3] = id;
}

/***********************************************************************************
Function:     verifyCheckSum
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacket::verifyCheckSum()
{
	unsigned short chksum;
	unsigned char c1, c2;

    if (m_length - 2 < getHeaderLength())
        return FALSE;
    c2 = m_buf[m_length - 2];
    c1 = m_buf[m_length - 1];
    chksum = (c1 & 0xff) | (c2 << 8);

    if (chksum == calcCheckSum())
	{
       return TRUE;
    }
    else
	{
		return FALSE;
	}
}

/***********************************************************************************
Function:     calcCheckSum
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Output:       None
Return:       None
Others:       None
***********************************************************************************/
u16 CRobotPacket::calcCheckSum()
{
	int i;
	unsigned char n;
	unsigned short c = 0;

	i = 3;
	n = m_buf[2] - 2;
	while (n > 1)
	{
		c += ((unsigned char)m_buf[i]<<8) | (unsigned char)m_buf[i+1];
		c = c & 0xffff;
		n -= 2;
		i += 2;
	}
	if (n > 0)
		c = c ^ (unsigned short)((unsigned char) m_buf[i]);
	return c;
}

/***********************************************************************************
Function:     finalizePacket
Description:  Copies the given packets buffer into the buffer of this packet, also
			  sets this length and readlength to what the given packet has
Input:        *packet: packet the packet to duplicate
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::finalizePacket()
{
    s16 check_sum;
    s8 c1,c2;
	m_buf[0] = (u8)(m_params.sync1);
	m_buf[1] = (u8)(m_params.sync2);
	m_buf[2] = (u8)(m_length - getHeaderLength() + m_params.command_id_size + m_params.crc_size);

    check_sum = calcCheckSum();
    c1 = (check_sum >> 8) & 0xff;
    c2 = check_sum;
    byteToBuf(c1);
    byteToBuf(c2);

	setPacketValid(true);
}

/***********************************************************************************
Function:     printHex
Description:  printf packet buf as hex format
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacket::printHex()
{
    printf("[CRobotPacket] valid %d, length %d, read_length %d!\n",
              m_valid, m_length, m_read_length);

    for(size_t i = 0; i < m_length + 5; i++)
    {
        printf("buf[%d] = 0x%x!\n", (int)i, (unsigned char)(m_buf[i]));
    }
}

/***********************************************************************************
Function:     TParams
Description:  The constructor of TParams
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacket::TParams::TParams()
{
	sync1 = 0xfa;
	sync2 = 0xfb;
	frame_header_size = 2;
	command_id_size = 1;
	buffer_len_size = 1;
	crc_size = 2;
}


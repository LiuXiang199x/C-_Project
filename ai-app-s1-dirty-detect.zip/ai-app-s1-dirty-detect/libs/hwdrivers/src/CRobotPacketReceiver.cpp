/**********************************************************************************
File name:	  CRobotPacketReceiver.cpp
Author:       Shizhe
Version:      V1.6.1
Date:	 	  2016-3-2
Description:  The class is used to receive robot packet
Others:       None

History:
	1. Date: 2015-09-15
	Author: Kimbo
	Modification: Refactor this class
***********************************************************************************/

/********************************** File includes *********************************/
#include <everest/hwdrivers/CRobotPacketReceiver.h>

/********************************** Current libs includes *************************/
#include <everest/hwdrivers/CDeviceConnection.h>


/********************************** System libs includes **************************/
#include <iostream>


/********************************** Name space ************************************/
using namespace std;
using namespace everest::hwdrivers;

/***********************************************************************************
Function:     CRobotPacketReceiver
Description:  The constructor of CRobotPacketReceiver
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketReceiver::CRobotPacketReceiver()
{
	resetSerialRead();
	m_device_conn = NULL;
	m_lost_count = 0;
	m_id = 0;
	m_log_receive_time_out = true;
#if ROBOT_PACKET_DEBUG
	m_fp = fopen("/tmp/stm32_serial.txt","a+");
#endif
}

/***********************************************************************************
Function:     CRobotPacketReceiver
Description:  The constructor of CRobotPacketReceiver
Input:        device_connection: the connection which the receiver will use
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketReceiver::CRobotPacketReceiver(CDeviceConnection *device_connection)
{
	resetSerialRead();
	m_device_conn = device_connection;
#if ROBOT_PACKET_DEBUG
    m_fp = fopen("/tmp/stm32_serial.txt", "a+");
#endif
}

/***********************************************************************************
Function:     ~CRobotPacketReceiver
Description:  The destructor of CRobotPacketReceiver
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CRobotPacketReceiver::~CRobotPacketReceiver()
{
#if ROBOT_PACKET_DEBUG
    if(m_fp != NULL)
    {
        fclose(m_fp);
    }
#endif
}

/***********************************************************************************
Function:     setDeviceConnection
Description:  Set device connection
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketReceiver::setDeviceConnection(CDeviceConnection *device_connection)
{
	m_device_conn = device_connection;
}

/***********************************************************************************
Function:     getDeviceConnection
Description:
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
CDeviceConnection* CRobotPacketReceiver::getDeviceConnection(void)
{
	return m_device_conn;
}

/***********************************************************************************
Function:     receivePacket
Description:  receive packet
Input:        ms_wait: how long to block for the start of a packet, nonblocking if 0
Output:       None
Return:       if there are no packets in alloted time, the device connection is closed, or other error.
			  Otherwise a pointer to the packet received is returned. If allocatePackets is true than
			  the caller must delete the packet. If allocatePackets is false then the packet object
			  will be reused in the next call; the caller must not store or use that packet object.
Others:       None
***********************************************************************************/
bool CRobotPacketReceiver::receivePacket(CRobotPacket *packet, unsigned int ms_wait)
{
	/* Judge whether serial is connecting */
	if (packet == NULL || m_device_conn == NULL || m_device_conn->getStatus() != CDeviceConnection::STATUS_OPEN)
	{
		printf("[CRobotPacketReceiver] id %d, receivePacket: connection not open!\n", m_id);
		return false;
	}
	char buffer[255];
	memset(buffer, 0, sizeof(buffer));
	int ret = m_device_conn->read((char *)buffer, sizeof(buffer), 5); 
	
	for(size_t i = 0; i < ret; i++)
	{
		m_buffer.push_back(buffer[i]);
		//printf(" buf[%d] = 0x%x ", (int)i, (unsigned char)(buffer[i]));
	}
	//printf("\n");
	/* Read packet */
	char ch;
	while(m_buffer.size())
	{
			ch = m_buffer[0];
			 m_buffer.pop_front();
            if(readSerialPacket(packet, ch))
            {
                m_lost_count = 0;
                return true;
            }
		
	}
	return false;
}


/***********************************************************************************
Function:     readSerialPacket
Description:  Read serial packet, if it return ture, it means read complete packet
Input:        serial packet, char ch
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketReceiver::readSerialPacket(CRobotPacket *packet, u8 ch)
{
	bool read_sucess = false;

	switch(m_state)
	{
	    case STATE_SYNC1:
	    {
	        if(ch == packet->m_params.sync1)
	        {
				processStateSYNC1(packet, ch);
	        }
	        break;
	    }
	    case STATE_SYNC2:
	    {
	        if(ch == packet->m_params.sync2)
	        {
				processStateSYNC2(packet, ch);
	        }
	        else
	        {
                printf("[CRobotPacketReceiver] id %d, STATE_SYNC2 0x%x not want 0x%x !\n",
                          m_id, ch, packet->m_params.sync2);
	            resetSerialRead();
	        }
	        break;
	    }
	    case STATE_LENGTH:
	    {
			processStateLength(packet, ch);
			break;
	    }
	    case STATE_ACQUIRE_DATA:
	    {
			read_sucess = processStateAcquireData(packet, ch);
			break;
	    }
		default:
		{
			break;
		}
    }

    return read_sucess;
}

/***********************************************************************************
Function:     processStateSYNC1
Description:  Process state sync1
Input:        serial packet, char ch
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketReceiver::processStateSYNC1(CRobotPacket *packet, u8 ch)
{
	packet->clearPacket();
	packet->setLength(0);
	packet->byteToBuf(ch);
	m_state = STATE_SYNC2;
}

/***********************************************************************************
Function:     processStateSYNC2
Description:  Process state sync2
Input:        serial packet, char ch
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketReceiver::processStateSYNC2(CRobotPacket *packet, u8 ch)
{
	packet->byteToBuf(ch);
	m_state = STATE_LENGTH;
}

/***********************************************************************************
Function:     processStateLength
Description:  Process state length
Input:        serial packet, char ch
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketReceiver::processStateLength(CRobotPacket *packet, u8 ch)
{
	m_serial_data_count = ch;
	packet->byteToBuf(ch);
	m_state = STATE_ACQUIRE_DATA;

}

/***********************************************************************************
Function:     processStateAcquireData
Description:  Process state acquire data
Input:        serial packet, char ch
Output:       None
Return:       None
Others:       None
***********************************************************************************/
bool CRobotPacketReceiver::processStateAcquireData(CRobotPacket *packet, u8 ch)
{
	m_actual_data_count++;
	packet->byteToBuf(ch);

	if(m_actual_data_count == m_serial_data_count)
	{
		resetSerialRead();
		if(packet->verifyCheckSum())
		{
			packet->setPacketValid(true);
			return true;
		}
		else
		{
			printf( "[CRobotPacketReceiver] id %d, crc check is wrong !\n", m_id);
			packet->printHex();
			packet->clearPacket();
			return false;
		}
	}
	return false;
}

/***********************************************************************************
Function:     resetSerialRead
Description:  Reset serial read
Input:        None
Output:       None
Return:       None
Others:       None
***********************************************************************************/
void CRobotPacketReceiver::resetSerialRead()
{
	m_state = STATE_SYNC1;
    m_serial_data_count = 0;
    m_actual_data_count = 0;
}


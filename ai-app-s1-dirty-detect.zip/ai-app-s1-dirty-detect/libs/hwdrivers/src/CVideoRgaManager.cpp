/*************************************************************************
	> File Name: CVideoRgaManager.cpp
	> Author:
	> Mail:
	> Created Time: 2020年05月15日 星期五 13时39分01秒
 ************************************************************************/
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <everest/base/CLog.h>
#include "everest/hwdrivers/CVideoRgaManager.h"

CVideoRgaManager::CVideoRgaManager()
{
    m_width  = 640;
    m_height = 480;
    m_fcc    = V4L2_PIX_FMT_NV12;

	memset(&m_rga_src, 0, sizeof(rga_info_t));
	m_rga_src.fd = -1;
	m_rga_src.mmuFlag = 1;

	memset(&m_rga_dst, 0, sizeof(rga_info_t));
	m_rga_dst.fd = -1;
	m_rga_dst.mmuFlag = 1;
	m_running = false;

}

CVideoRgaManager::~CVideoRgaManager()
{
    m_rga.RkRgaFree(&m_bo_dst);
}

void CVideoRgaManager::run()
{
	while(m_bool)
	{
	    if(m_running)
        {
            GetFrames();
            PutFrames();
        }
        else
        {
             sleep(1);
            //  printf("wait start video stream\n");
             CLog::log(LogKimbo, LogNormal, "[CVideoRgaManager] wait start video stream!\n");
        }

	}
}


int CVideoRgaManager::WaitFrames()
{
    int max_fd = 0, timeout_ms = 3000,ret;
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;

    FD_ZERO(&m_fds);

	FD_SET(m_api->fd, &m_fds);
	max_fd = m_api->fd > max_fd ? m_api->fd : max_fd;

    while (timeout_ms > 0) {
        ret = select(max_fd + 1, &m_fds, NULL, NULL, &tv);
        if (ret == -1) {
            if (errno == EINTR) {
                continue;
            } else {
                fprintf(stderr, "select() return error: %s\n", strerror(errno));
                return ret;
            }
        } else if (ret) {
            /* Data ready, FD_ISSET(0, &fds) will be true. */
            if (!FD_ISSET(m_api->fd, &m_fds))
            {
               ret = -1;
            }
            break;
        } else {
            /* timeout */
            fprintf(stderr, "Wait for data frames timeout\n");
        }
    }

    return ret;
}

bool CVideoRgaManager::GetFrames()
{
    if (WaitFrames() <= 0) {
        /* Timeout or error */
        CLog::log(LogKimbo, LogNormal, "[CVideoRgaManager] WaitFrames Timeout!\n");
        return false;
    }
    m_cur_frame = rkisp_get_frame(m_api, 0);
    if (m_cur_frame == NULL)
    {
        fprintf(stderr, "Can not read frame from %s\n", m_device.c_str());
        CLog::log(LogKimbo, LogNormal, "[CVideoRgaManager] Can not read frame!\n");
        return false;
    }

    m_rga_src.fd = m_cur_frame->fd;
    m_rga.RkRgaBlit(&m_rga_src, &m_rga_dst, NULL);
    if(m_callback) m_callback((char *)m_bo_dst.ptr,m_rga_height*m_rga_width*3);

    return true;
}

void CVideoRgaManager::PutFrames()
{
    if (m_cur_frame == NULL)
    {
        fprintf(stderr, "Can not read frame from put %s\n", m_device.c_str());
        return;
    }
    rkisp_put_frame(m_api, m_cur_frame);
}

void CVideoRgaManager::Init(const char *device,int s_width,int s_heigth,int s_fcc,int d_width,int d_heigth,int d_fcc,rgaCallback callback)
{
    m_width = s_width;
    m_height = s_heigth;
    m_device.clear();
    m_device.append(device,strlen(device));

    m_rga_width  = d_width;
    m_rga_height = d_heigth ;
    m_rga_fcc    = d_fcc;

    m_callback = callback;

    m_rga.RkRgaInit();

    m_rga.RkRgaGetAllocBuffer(&m_bo_dst,m_rga_width,m_rga_height, 32);
    m_rga.RkRgaGetMmap(&m_bo_dst);
    m_rga.RkRgaGetBufferFd(&m_bo_dst,&m_rga_dst.fd);
    if(s_fcc == 1)
    {
        m_fcc = V4L2_PIX_FMT_NV12;
        rga_set_rect(&m_rga_src.rect, 0,0,m_width,m_height,m_width,m_height,RK_FORMAT_YCrCb_420_SP);
    }
    else if(s_fcc == 2)
    {
        m_fcc = V4L2_PIX_FMT_H264;
        //rga_set_rect(&m_rga_src.rect, 0,0,m_width,m_height,m_width,m_height,RK_FORMAT_YCrCb_420_SP);
    }

    if(d_fcc == 1)
    {
        rga_set_rect(&m_rga_dst.rect, 0,0,m_rga_width,m_rga_height,m_rga_width,m_rga_height,RK_FORMAT_RGB_888);
    }
    start();
}

bool CVideoRgaManager::Start()
{
    m_api = rkisp_open_device(m_device.c_str(), 0);
	if (m_api == NULL)
    {
        fprintf(stderr, "rkisp_open_device file \n");
        return false;
    }

	rkisp_set_fmt(m_api, m_width, m_height, m_fcc);
  	if (rkisp_start_capture(m_api))
    {
        fprintf(stderr, "rkisp_start_capture file \n");
        return false;
    }
    m_running = true;
    fprintf(stderr, "rkisp_start_sucess!!!!!!!!!!!! \n");
    return true;
}

bool CVideoRgaManager::Stop()
{
    m_running = false;
    sleep(1);
    if(m_api)
    {
       rkisp_stop_capture(m_api);
       rkisp_close_device(m_api);
    }
    m_api = NULL;
    return true;
}




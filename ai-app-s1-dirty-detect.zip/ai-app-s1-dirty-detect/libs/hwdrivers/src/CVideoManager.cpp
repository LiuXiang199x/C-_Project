#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>

#include "everest/hwdrivers/CVideoManager.h"

CVideoManager::CVideoManager()
{
    m_width  = 640;
    m_height = 480;
    m_fcc    = V4L2_PIX_FMT_NV12;
    m_running = false;
}

CVideoManager::~CVideoManager()
{

}


void CVideoManager::run()
{
	while(m_bool)
	{
	    if(m_running)
        {
            GetFrames();
            PutFrames();
        }
        else
        {
             sleep(1);
        }
	}
}

int CVideoManager::WaitFrames()
{
    int max_fd = 0, timeout_ms = 3000,ret;
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;

    FD_ZERO(&m_fds);

	FD_SET(m_api->fd, &m_fds);
	max_fd = m_api->fd > max_fd ? m_api->fd : max_fd;

    while (timeout_ms > 0) {
        ret = select(max_fd + 1, &m_fds, NULL, NULL, &tv);
        if (ret == -1) {
            if (errno == EINTR) {
                continue;
            } else {
                fprintf(stderr, "select() return error: %s\n", strerror(errno));
                return ret;
            }
        } else if (ret) {
            /* Data ready, FD_ISSET(0, &fds) will be true. */
            if (!FD_ISSET(m_api->fd, &m_fds))
            {
               ret = -1;
            }
            break;
        } else {
            /* timeout */
            fprintf(stderr, "Wait for data frames timeout\n");
        }
    }
    return ret;
}

bool CVideoManager::GetFrames( )
{
    if (WaitFrames() <= 0) {
        /* Timeout or error */
        return false;
    }

    m_cur_frame = rkisp_get_frame(m_api, 0);
    if (m_cur_frame == NULL)
    {
        fprintf(stderr, "Can not read frame from %s\n", m_device.c_str());
        return false;
    }

    if(m_callback) m_callback((char *)m_cur_frame->buf,m_cur_frame->size);

    return true;
}

void CVideoManager::PutFrames()
{
    rkisp_put_frame(m_api, m_cur_frame);
}

void CVideoManager::Init(const char *device,int width,int heigth,int fcc,videoCallback callback)
{
    m_width = width;
    m_height = heigth;
    m_callback = callback;
    if(fcc == 1)
    {
        m_fcc    = V4L2_PIX_FMT_NV12;
    }
    else if(fcc == 2)
    {
        m_fcc    = V4L2_PIX_FMT_H264;
    }
    m_device.clear();
    m_device.append(device,strlen(device));
    start();
}

bool CVideoManager::Start()
{
    m_api = rkisp_open_device(m_device.c_str(), 0);
	if (m_api == NULL)
    {
        fprintf(stderr, "rkisp_open_device file \n");
        return false;
    }

	rkisp_set_fmt(m_api, m_width, m_height, m_fcc);

  	if (rkisp_start_capture(m_api))
    {
        fprintf(stderr, "rkisp_start_capture file \n");
        return false;
    }
    return true;
}

bool CVideoManager::Stop()
{
    m_running = false;
    sleep(1);
    if(m_api)
    {
       rkisp_stop_capture(m_api);
       rkisp_close_device(m_api);
    }
    m_api = NULL;
}



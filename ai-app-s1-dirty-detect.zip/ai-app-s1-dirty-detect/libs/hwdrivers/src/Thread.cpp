#include "everest/hwdrivers/Thread.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

Thread::Thread()
{
     m_bool = true;

}

Thread::~Thread()
{
        //dtor
    //
}

int Thread::start()
{
    m_bool =   true;
    if(pthread_create(&pid, NULL, start_thread, (void *)this) != 0)
    {
        printf("pthread_create fail\n");
        return -1;
    }
    pthread_detach(pid);
    return 0;
}


void Thread::stop()
{
    m_bool = false;
}

void *Thread::start_thread(void *arg)
{
        Thread *ptr = (Thread *)arg;
        ptr->run();
        return NULL;
}

int Thread::ThreadGetID(void)
{
	return syscall(__NR_gettid);
}


